package autocode.bases;

import lombok.Getter;

public enum AcSqlEnums {
	TABLE("table"),
	VIEW("view"),
	PACKAGE("package"),
	SEQUENCE("sequence");

	@Getter
	private final String value;

	private AcSqlEnums(final String value) {
		this.value = value;
	}

	public static AcSqlEnums getEnumFrom(String def) {
		switch (def) {
		case "table":
			return TABLE;
		case "view":
			return VIEW;
		case "pkg":
		case "package":
			return PACKAGE;
		case "seq":
		case "sequence":
			return SEQUENCE;
		}
		return null;
	}
}
