package autocode;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.io.FileUtils;

import autocode.bases.AcSqlEnums;
import autocode.models.IgnoredItem;
import lombok.SneakyThrows;
import lombok.val;
import lombok.experimental.UtilityClass;

@UtilityClass
public class AcCommon {

	/**
	 * Commons
	 */
	public static final String CHARSET = "UTF-8";
	public static final String NEWLINE = "\r\n";

	/**
	 * Configs
	 */
	public static String CMD_CONFIG_PACKAGEPREFIX = "jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.autocode2.generated";
	public static final List<IgnoredItem> IGNORED_LIST = new ArrayList<>();

	/**
	 * Misc
	 */
	public static String convertPkg2Folder(String pkg) {
//		return String.format("C:/gp/git/g1keimux/s01ssg/f14hyosho-src-sv.Libs/g1keimux-s01ssg-f14hyosho/src/main/java/", pkg.replace('.', '/'));
		return String.format("src/main/java/%s", pkg.replace('.', '/'));
	}

	@SneakyThrows
	public static void setConfig(String var, String key, String... args) {
		for (val i : args) {
			if (i.contains("=")) {
				val a = i.split("=");
				if (Objects.equals(a[0], key)) {
					val field = AcCommon.class.getDeclaredField(var);
					field.set(null, a[1]);
				}
			}
		}
	}

	@SneakyThrows
	public static void setConfigs() {
		// IGNORED_LIST
		val ignoreFile = new File("src/main/resources/autocode/ignored");
		if (ignoreFile.exists()) {
			val lines = FileUtils.readLines(ignoreFile, CHARSET);
			for (val line : lines) {
				val ignoredItem = new IgnoredItem();
				if (line.contains(":")) {
					val a = line.split(":");
					ignoredItem.setSqlType(AcSqlEnums.getEnumFrom(a[0]));
					ignoredItem.setIgnoredRegex(a[1]);
				} else {
					ignoredItem.setSqlType(null);
					ignoredItem.setIgnoredRegex(line);
				}
				IGNORED_LIST.add(ignoredItem);
			}
		}
	}

	@SneakyThrows
	public static void setupFolder() {
		val folder = new File(convertPkg2Folder(CMD_CONFIG_PACKAGEPREFIX));
		if (folder.exists()) {
			FileUtils.cleanDirectory(folder);
		} else {
			FileUtils.forceMkdir(folder);
		}
	}

	@SneakyThrows
	public static void clearFolder() {
		val folder = new File(convertPkg2Folder(CMD_CONFIG_PACKAGEPREFIX));
		if (folder.exists()) {
			FileUtils.cleanDirectory(folder);
		}
	}

}
