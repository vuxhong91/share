package autocode.jass.oracle.models;

import lombok.Data;

@Data
public class OracleSqlObjectSizeInfo {

	private String NAME;

	private String TYPE;

	private String SOURCE_SIZE;

	private String PARSED_SIZE;

	private String CODE_SIZE;

	private String ERROR_SIZE;

}
