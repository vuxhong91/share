package autocode.models;

import autocode.bases.AcSqlEnums;
import lombok.Data;

@Data
public class IgnoredItem {
	private AcSqlEnums sqlType;
	private String ignoredRegex;
}
