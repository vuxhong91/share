package autocode.bases;

public interface AcBaseSequence extends AcBaseIndex {
}
