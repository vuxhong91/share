package autocode.bases;

public interface AcBaseModel {
	AcModelEnums getModelType();
}
