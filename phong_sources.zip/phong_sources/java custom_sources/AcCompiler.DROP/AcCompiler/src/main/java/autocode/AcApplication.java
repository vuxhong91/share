package autocode;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import autocode.generators.ModelGen;

@SpringBootApplication
public class AcApplication implements CommandLineRunner {

	@Autowired
	private ModelGen modelExecutor;

	public static void main(String[] args) {
		SpringApplication.run(AcApplication.class, args);
	}

	@Override
	@SuppressWarnings("resource")
	public void run(String... args) throws Exception {
		try {
			AcCommon.setConfigs();
			AcCommon.setConfig("CMD_CONFIG_PACKAGEPREFIX", "-package", args);
			AcCommon.setupFolder();
			modelExecutor.genTables();
			modelExecutor.genViews();
		} catch (Exception e) {
			AcCommon.clearFolder();
			System.out.println();
			System.out.println("Error: " + e.getMessage());
			System.in.read();
		}
		System.exit(0);
	}

}
