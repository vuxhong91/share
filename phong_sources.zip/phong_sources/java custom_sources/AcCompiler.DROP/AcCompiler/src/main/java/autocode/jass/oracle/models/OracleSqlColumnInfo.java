package autocode.jass.oracle.models;

import lombok.Data;

@Data
public class OracleSqlColumnInfo {

	private String TABLE_NAME;

	private String COLUMN_NAME;

	private String DATA_TYPE;

	private String DATA_TYPE_MOD;

	private String DATA_TYPE_OWNER;

	private String DATA_LENGTH;

	private String DATA_PRECISION;

	private String DATA_SCALE;

	private String NULLABLE;

	private String COLUMN_ID;

	private String DEFAULT_LENGTH;

	private String DATA_DEFAULT;

	private String NUM_DISTINCT;

	private String LOW_VALUE;

	private String HIGH_VALUE;

	private String DENSITY;

	private String NUM_NULLS;

	private String NUM_BUCKETS;

	private String LAST_ANALYZED;

	private String SAMPLE_SIZE;

	private String CHARACTER_SET_NAME;

	private String CHAR_COL_DECL_LENGTH;

	private String GLOBAL_STATS;

	private String USER_STATS;

	private String AVG_COL_LEN;

	private String CHAR_LENGTH;

	private String CHAR_USED;

	private String V80_FMT_IMAGE;

	private String DATA_UPGRADED;

	private String HIDDEN_COLUMN;

	private String VIRTUAL_COLUMN;

	private String SEGMENT_COLUMN_ID;

	private String INTERNAL_COLUMN_ID;

	private String HISTOGRAM;

	private String QUALIFIED_COL_NAME;

	private String USER_GENERATED;

	private String DEFAULT_ON_NULL;

	private String IDENTITY_COLUMN;

	private String EVALUATION_EDITION;

	private String UNUSABLE_BEFORE;

	private String UNUSABLE_BEGINNING;

	private String COLLATION;

	private String COLLATED_COLUMN_ID;

}
