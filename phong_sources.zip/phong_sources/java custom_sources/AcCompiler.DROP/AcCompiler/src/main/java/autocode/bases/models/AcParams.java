package autocode.bases.models;

import autocode.bases.AcBaseModel;
import autocode.bases.AcModelEnums;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseParams;

//public abstract class AcParams extends AcObject
public abstract class AcParams extends BaseParams implements AcBaseModel {
	@Override
	public AcModelEnums getModelType() {
		return AcModelEnums.OBJECT;
	}
}
