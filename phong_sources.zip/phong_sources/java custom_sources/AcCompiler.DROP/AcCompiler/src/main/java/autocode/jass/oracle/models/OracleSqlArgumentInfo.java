package autocode.jass.oracle.models;

import lombok.Data;

@Data
public class OracleSqlArgumentInfo {

	private String OBJECT_NAME;

	private String PACKAGE_NAME;

	private String OBJECT_ID;

	private String OVERLOAD;

	private String SUBPROGRAM_ID;

	private String ARGUMENT_NAME;

	private String POSITION;

	private String SEQUENCE;

	private String DATA_LEVEL;

	private String DATA_TYPE;

	private String DEFAULTED;

	private String DEFAULT_VALUE;

	private String DEFAULT_LENGTH;

	private String IN_OUT;

	private String DATA_LENGTH;

	private String DATA_PRECISION;

	private String DATA_SCALE;

	private String RADIX;

	private String CHARACTER_SET_NAME;

	private String TYPE_OWNER;

	private String TYPE_NAME;

	private String TYPE_SUBNAME;

	private String TYPE_LINK;

	private String PLS_TYPE;

	private String CHAR_LENGTH;

	private String CHAR_USED;

	private String ORIGIN_CON_ID;

}
