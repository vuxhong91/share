package autocode.bases.models;

import autocode.bases.AcBaseModel;
import autocode.bases.AcModelEnums;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseModel;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseResult;

//public abstract class AcResult extends AcObject
public abstract class AcResult extends BaseModel implements BaseResult, AcBaseModel {
	@Override
	public AcModelEnums getModelType() {
		return AcModelEnums.OBJECT;
	}
}
