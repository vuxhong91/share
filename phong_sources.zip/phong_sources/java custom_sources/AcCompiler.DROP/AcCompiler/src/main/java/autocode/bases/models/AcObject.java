package autocode.bases.models;

import autocode.bases.AcBaseModel;
import autocode.bases.AcModelEnums;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseModel;

//public abstract class AcObject implements AcBaseModel
public abstract class AcObject extends BaseModel implements AcBaseModel {
	@Override
	public AcModelEnums getModelType() {
		return AcModelEnums.OBJECT;
	}
}
