package autocode.jass.oracle;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import autocode.jass.oracle.models.OracleSqlArgumentInfo;
import autocode.jass.oracle.models.OracleSqlColumnInfo;
import autocode.jass.oracle.models.OracleSqlObjectInfo;
import autocode.jass.oracle.models.OracleSqlObjectSizeInfo;

@Mapper
public interface JOracleProvider {

	//==================================================
	// LOCAL
	//==================================================

	@Select("select * "
			+ "from USER_OBJECTS where OBJECT_NAME = #{name} and rownum = 1")
	OracleSqlObjectInfo getDbObject(@Param("name") String name);

	@Select("select * "
			+ "from USER_OBJECTS order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getDbObjects();

	@Select("select * "
			+ "from USER_OBJECTS where OBJECT_TYPE = #{type} order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getDbObjectsOf(@Param("type") String type);

	@Select("select * "
			+ "from USER_OBJECTS where OBJECT_TYPE = 'TABLE' order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getDbTables();

	@Select("select * "
			+ "from USER_OBJECTS where OBJECT_TYPE = 'VIEW' order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getDbViews();

	@Select("select * "
			+ "from USER_OBJECTS where OBJECT_TYPE = 'PACKAGE' order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getDbPackages();

	@Select("select * "
			+ "from USER_OBJECTS where OBJECT_TYPE = 'PACKAGE BODY' order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getDbPackageBodies();

	@Select("select * "
			+ "from USER_OBJECTS where OBJECT_TYPE = 'SEQUENCE' order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getDbSequences();

	@Select("select * "
			+ "from USER_OBJECTS where OBJECT_TYPE = 'SYNONYM' order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getDbSynonyms();

	@Select("select * "
			+ "from USER_OBJECT_SIZE order by TYPE, NAME")
	List<OracleSqlObjectSizeInfo> getDbObjectSizes();

	@Select("select * "
			+ "from USER_OBJECT_SIZE where NAME = #{name}")
	List<OracleSqlObjectSizeInfo> getDbObjectSizeOf(@Param("name") String name);

	@Select("select SUM(ERROR_SIZE) "
			+ "from USER_OBJECT_SIZE where ERROR_SIZE > 0")
	Integer getDbErrorCount();

	@Select("select * "
			+ "from USER_OBJECT_SIZE where ERROR_SIZE > 0 order by TYPE, NAME")
	List<OracleSqlObjectSizeInfo> getDbErrorObjects();

	@Select("select * "
			+ "from USER_TAB_COLS order by TABLE_NAME, COLUMN_ID")
	List<OracleSqlColumnInfo> getColumns();

	@Select("select * "
			+ "from USER_TAB_COLS where TABLE_NAME = #{name} order by COLUMN_ID")
	List<OracleSqlColumnInfo> getColumnsOf(@Param("name") String name);

	@Select("select * "
			+ "from USER_ARGUMENTS where ARGUMENT_NAME is not null and (IN_OUT = 'IN' or IN_OUT = 'IN/OUT') order by PACKAGE_NAME, OBJECT_NAME, POSITION")
	List<OracleSqlArgumentInfo> getParameters();

	@Select("select * "
			+ "from USER_ARGUMENTS where ARGUMENT_NAME is not null and (IN_OUT = 'IN' or IN_OUT = 'IN/OUT') and OBJECT_NAME = #{name} order by PACKAGE_NAME, OBJECT_NAME, POSITION")
	List<OracleSqlArgumentInfo> getParametersOf(@Param("name") String name);

	@Select("select * "
			+ "from USER_ARGUMENTS where ARGUMENT_NAME is not null and IN_OUT = 'OUT' order by PACKAGE_NAME, OBJECT_NAME, POSITION")
	List<OracleSqlArgumentInfo> getArgs();

	@Select("select * "
			+ "from USER_ARGUMENTS where ARGUMENT_NAME is not null and IN_OUT = 'OUT' and OBJECT_NAME = #{name} order by PACKAGE_NAME, OBJECT_NAME, POSITION")
	List<OracleSqlArgumentInfo> getArgsOf(@Param("name") String name);

	@Select("select * "
			+ "from USER_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE <> 'PL/SQL RECORD' and DATA_TYPE <> 'TABLE' and OBJECT_NAME = #{name}")
	List<OracleSqlArgumentInfo> checkArg(@Param("name") String name);

	@Select("select * "
			+ "from USER_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'TABLE' order by PACKAGE_NAME, OBJECT_NAME, POSITION")
	List<OracleSqlArgumentInfo> getTableArgs();

	@Select("select * "
			+ "from USER_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'TABLE' and TYPE_SUBNAME = #{name}")
	List<OracleSqlArgumentInfo> getTableArgsOf(@Param("name") String name);

	@Select("select * "
			+ "from USER_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'PL/SQL RECORD' order by PACKAGE_NAME, OBJECT_NAME, POSITION")
	List<OracleSqlArgumentInfo> getRecordArgs();

	@Select("select * "
			+ "from USER_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'PL/SQL RECORD' and TYPE_SUBNAME = #{name}")
	List<OracleSqlArgumentInfo> getRecordArgsOf(@Param("name") String name);

	@Select("select distinct TYPE_SUBNAME "
			+ "from USER_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'TABLE' order by TYPE_SUBNAME")
	List<String> getTables();

	@Select("select distinct TYPE_SUBNAME "
			+ "from USER_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'TABLE' and PACKAGE_NAME = #{name}")
	List<String> getTableOf(@Param("name") String name);

	@Select("select distinct TYPE_SUBNAME "
			+ "from USER_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'PL/SQL RECORD' order by TYPE_SUBNAME")
	List<String> getRecords();

	@Select("select distinct TYPE_SUBNAME "
			+ "from USER_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'PL/SQL RECORD' and PACKAGE_NAME = #{name}")
	List<String> getRecordOf(@Param("name") String name);

	//==================================================
	// GLOBAL
	//==================================================

	@Select("select * "
			+ "from ALL_OBJECTS where OBJECT_NAME = #{name} and rownum = 1")
	OracleSqlObjectInfo getGDbObject(@Param("name") String name);

	@Select("select * "
			+ "from ALL_OBJECTS order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getGDbObjects();

	@Select("select * "
			+ "from ALL_OBJECTS where OBJECT_TYPE = #{type} order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getGDbObjectsOf(@Param("type") String type);

	@Select("select * "
			+ "from ALL_OBJECTS where OBJECT_TYPE = 'TABLE' order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getGDbTables();

	@Select("select * "
			+ "from ALL_OBJECTS where OBJECT_TYPE = 'VIEW' order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getGDbViews();

	@Select("select * "
			+ "from ALL_OBJECTS where OBJECT_TYPE = 'PACKAGE' order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getGDbPackages();

	@Select("select * "
			+ "from ALL_OBJECTS where OBJECT_TYPE = 'PACKAGE BODY' order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getGDbPackageBodies();

	@Select("select * "
			+ "from ALL_OBJECTS where OBJECT_TYPE = 'SEQUENCE' order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getGDbSequences();

	@Select("select * "
			+ "from ALL_OBJECTS where OBJECT_TYPE = 'SYNONYM' order by LAST_DDL_TIME")
	List<OracleSqlObjectInfo> getGDbSynonyms();

	@Select("select * "
			+ "from ALL_OBJECT_SIZE order by TYPE, NAME")
	List<OracleSqlObjectSizeInfo> getGDbObjectSizes();

	@Select("select * "
			+ "from ALL_OBJECT_SIZE where NAME = #{name}")
	List<OracleSqlObjectSizeInfo> getGDbObjectSizeOf(@Param("name") String name);

	@Select("select SUM(ERROR_SIZE) "
			+ "from ALL_OBJECT_SIZE where ERROR_SIZE > 0")
	Integer getGDbErrorCount();

	@Select("select * "
			+ "from ALL_OBJECT_SIZE where ERROR_SIZE > 0 order by TYPE, NAME")
	List<OracleSqlObjectSizeInfo> getGDbErrorObjects();

	@Select("select * "
			+ "from ALL_TAB_COLS order by TABLE_NAME, COLUMN_ID")
	List<OracleSqlColumnInfo> getGColumns();

	@Select("select * "
			+ "from ALL_TAB_COLS where TABLE_NAME = #{name} order by TABLE_NAME, COLUMN_ID")
	List<OracleSqlColumnInfo> getGColumnsOf(@Param("name") String name);

	@Select("select * "
			+ "from ALL_ARGUMENTS where ARGUMENT_NAME is not null and (IN_OUT = 'IN' or IN_OUT = 'IN/OUT') order by PACKAGE_NAME, OBJECT_NAME, POSITION")
	List<OracleSqlArgumentInfo> getGParameters();

	@Select("select * "
			+ "from ALL_ARGUMENTS where ARGUMENT_NAME is not null and (IN_OUT = 'IN' or IN_OUT = 'IN/OUT') and OBJECT_NAME = #{name} order by PACKAGE_NAME, OBJECT_NAME, POSITION")
	List<OracleSqlArgumentInfo> getGParametersOf(@Param("name") String name);

	@Select("select * "
			+ "from ALL_ARGUMENTS where ARGUMENT_NAME is not null and IN_OUT = 'OUT' order by PACKAGE_NAME, OBJECT_NAME, POSITION")
	List<OracleSqlArgumentInfo> getGArgs();

	@Select("select * "
			+ "from ALL_ARGUMENTS where ARGUMENT_NAME is not null and IN_OUT = 'OUT' and OBJECT_NAME = #{name} order by PACKAGE_NAME, OBJECT_NAME, POSITION")
	List<OracleSqlArgumentInfo> getGArgsOf(@Param("name") String name);

	@Select("select * "
			+ "from ALL_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE <> 'PL/SQL RECORD' and DATA_TYPE <> 'TABLE' and OBJECT_NAME = #{name}")
	List<OracleSqlArgumentInfo> checkGArg(@Param("name") String name);

	@Select("select * "
			+ "from ALL_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'TABLE' order by PACKAGE_NAME, OBJECT_NAME, POSITION")
	List<OracleSqlArgumentInfo> getGTableArgs();

	@Select("select * "
			+ "from ALL_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'TABLE' and TYPE_SUBNAME = #{name}")
	List<OracleSqlArgumentInfo> getGTableArgsOf(@Param("name") String name);

	@Select("select * "
			+ "from ALL_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'PL/SQL RECORD' order by PACKAGE_NAME, OBJECT_NAME, POSITION")
	List<OracleSqlArgumentInfo> getGRecordArgs();

	@Select("select * "
			+ "from ALL_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'PL/SQL RECORD' and TYPE_SUBNAME = #{name}")
	List<OracleSqlArgumentInfo> getGRecordArgsOf(@Param("name") String name);

	@Select("select distinct TYPE_SUBNAME "
			+ "from ALL_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'TABLE' order by TYPE_SUBNAME")
	List<String> getGTables();

	@Select("select distinct TYPE_SUBNAME "
			+ "from ALL_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'TABLE' and PACKAGE_NAME = #{name}")
	List<String> getGTableOf(@Param("name") String name);

	@Select("select distinct TYPE_SUBNAME "
			+ "from ALL_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'PL/SQL RECORD' order by TYPE_SUBNAME")
	List<String> getGRecords();

	@Select("select distinct TYPE_SUBNAME "
			+ "from ALL_ARGUMENTS where ARGUMENT_NAME is null and IN_OUT = 'OUT' and DATA_TYPE = 'PL/SQL RECORD' and PACKAGE_NAME = #{name}")
	List<String> getGRecordOf(@Param("name") String name);
}
