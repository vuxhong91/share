package autocode.jass.oracle.models;

import lombok.Data;

@Data
public class OracleSqlObjectInfo {

	private String OBJECT_NAME;

	private String SUBOBJECT_NAME;

	private String OBJECT_ID;

	private String DATA_OBJECT_ID;

	private String OBJECT_TYPE;

	private String CREATED;

	private String LAST_DDL_TIME;

	private String TIMESTAMP;

	private String STATUS;

	private String TEMPORARY;

	private String GENERATED;

	private String SECONDARY;

	private String NAMESPACE;

	private String EDITION_NAME;

	private String SHARING;

	private String EDITIONABLE;

	private String ORACLE_MAINTAINED;

	private String APPLICATION;

	private String DEFAULT_COLLATION;

	private String DUPLICATED;

	private String SHARDED;

	private String CREATED_APPID;

	private String CREATED_VSNID;

	private String MODIFIED_APPID;

	private String MODIFIED_VSNID;

}
