package autocode.generators;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import autocode.jass.oracle.JOracleProvider;

@Component
public class MapperGen {

	@Autowired
	private JOracleProvider provider;

}
