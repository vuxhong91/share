package autocode.bases;

import autocode.AcCommon;
import autocode.bases.models.AcObject;
import autocode.bases.models.AcParams;
import autocode.bases.models.AcResult;
import lombok.Getter;

public enum AcModelEnums {
	OBJECT("object"),
	PARAMS("params"),
	RESULT("result");

	@Getter
	private final String value;

	private AcModelEnums(final String value) {
		this.value = value;
	}

	public Class<?> getClassBase() {
		switch (this) {
		case OBJECT:
			return AcObject.class;
		case PARAMS:
			return AcParams.class;
		case RESULT:
			return AcResult.class;
		}
		return null;
	}

	public String getModelPackage() {
		return String.format("%s.%s", AcCommon.CMD_CONFIG_PACKAGEPREFIX, value);
	}

	public String getModelPackage(String group) {
		return String.format("%s.%s.%s", AcCommon.CMD_CONFIG_PACKAGEPREFIX, group, value);
	}
}
