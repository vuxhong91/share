package autocode.configs;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
@Configuration
@ComponentScan({
	"jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib",
	"jp.gunma.pref.police.gpwan.g9common.s01com.f90svtest"
	})
public class SpringBootConfig {
}
