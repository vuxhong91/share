package autocode.bases;

public interface AcBaseIndex {
}
