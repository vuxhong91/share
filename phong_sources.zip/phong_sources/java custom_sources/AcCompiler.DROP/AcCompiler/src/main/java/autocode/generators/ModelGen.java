package autocode.generators;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import autocode.AcCommon;
import autocode.bases.AcModelEnums;
import autocode.bases.AcSqlEnums;
import autocode.jass.oracle.JOracleParser;
import autocode.jass.oracle.JOracleProvider;
import autocode.jass.oracle.models.OracleSqlObjectInfo;
import lombok.SneakyThrows;
import lombok.val;

@Component
public class ModelGen {

	@Autowired
	private JOracleProvider provider;

	public void genTables() {
		val list = provider.getDbTables().stream()
				.filter(x -> AcCommon.IGNORED_LIST.stream()
						.noneMatch(y -> (Objects.equals(y.getSqlType(), null)
								|| Objects.equals(y.getSqlType(), AcSqlEnums.TABLE))
								&& !Pattern.matches(y.getIgnoredRegex(), x.getOBJECT_NAME())))
				.collect(Collectors.toList());
		if (list.isEmpty()) {
			return;
		}
		genModelFile(AcSqlEnums.TABLE, list);
	}

	public void genViews() {
		val list = provider.getDbViews().stream()
				.filter(x -> AcCommon.IGNORED_LIST.stream()
						.noneMatch(y -> (Objects.equals(y.getSqlType(), null)
								|| Objects.equals(y.getSqlType(), AcSqlEnums.VIEW))
								&& !Pattern.matches(y.getIgnoredRegex(), x.getOBJECT_NAME())))
				.collect(Collectors.toList());
		if (list.isEmpty()) {
			return;
		}
		genModelFile(AcSqlEnums.VIEW, list);
	}

	@SneakyThrows
	private void genModelFile(AcSqlEnums sqlType, List<OracleSqlObjectInfo> objs) {
		try (val resource = this.getClass().getResourceAsStream("/templates/AcModelTemp")) {
			try (val stream = new InputStreamReader(resource)) {
				try (val buffer = new BufferedReader(stream)) {
					String contentTemp = buffer.lines().collect(Collectors.joining());
					val modelType = AcModelEnums.OBJECT;
					val pPACKAGE = modelType.getModelPackage(sqlType.getValue());
					val pCLASSBASE = modelType.getClassBase().getSimpleName();
					contentTemp = contentTemp.replace("#{PACKAGE}", pPACKAGE);
					contentTemp = contentTemp.replace("#{CLASSBASE}", pCLASSBASE);
					for (val item : objs) {
						val pCLASSNAME = item.getOBJECT_NAME();
						val pSOURCE = genProperties(item);
						contentTemp = contentTemp.replace("#{CLASSNAME}", pCLASSNAME);
						contentTemp = contentTemp.replace("#{SOURCE}", pSOURCE);
						val javaFile = new File(
								String.format("%s/%s.java", AcCommon.convertPkg2Folder(pPACKAGE), pCLASSNAME));
						FileUtils.forceMkdirParent(javaFile);
						javaFile.deleteOnExit();
						FileUtils.writeStringToFile(javaFile, contentTemp, AcCommon.CHARSET);
					}
				}
			}
		}
	}

	private String genProperties(OracleSqlObjectInfo obj) {
		val buffer = new StringBuilder();
		for (val col : provider.getColumnsOf(obj.getOBJECT_NAME())) {
			buffer.append(String.format("private %s %s;%s", JOracleParser.getJavaType(col).getSimpleName(),
					StringUtils.capitalize(col.getCOLUMN_NAME()), AcCommon.NEWLINE));
		}
		return buffer.toString();
	}

}
