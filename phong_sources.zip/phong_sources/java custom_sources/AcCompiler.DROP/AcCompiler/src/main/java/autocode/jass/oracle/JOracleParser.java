package autocode.jass.oracle;

import java.util.Date;
import java.util.Objects;

import autocode.jass.oracle.models.OracleSqlColumnInfo;
import lombok.val;
import lombok.experimental.UtilityClass;

@UtilityClass
public class JOracleParser {

	public static Class<?> getJavaType(String oracleType) {
		if (oracleType.startsWith("CHAR") || oracleType.startsWith("VARCHAR")) {
			return String.class;
		}
		if (oracleType.startsWith("NUMERIC")) {
			return Double.class;
		}
		if (oracleType.startsWith("TIMESTAMP")) {
			return Date.class;
		}
		return Object.class;
	}

	public static Class<?> getJavaType(OracleSqlColumnInfo columnInfo) {
		val type = getJavaType(columnInfo.getCOLUMN_NAME());
		return Objects.equals(type, Double.class) && (Objects.isNull(columnInfo.getDATA_SCALE()) || Objects.equals(columnInfo.getDATA_SCALE(), 0)) ? Integer.class : type;
	}

}
