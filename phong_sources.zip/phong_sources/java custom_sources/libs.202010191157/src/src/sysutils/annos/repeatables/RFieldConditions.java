package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.repeatables;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.FieldConditions;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface RFieldConditions {
	FieldConditions[] value();
}