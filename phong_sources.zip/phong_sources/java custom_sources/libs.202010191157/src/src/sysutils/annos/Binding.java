package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.repeatables.RBinding;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(RBinding.class)
public @interface Binding {
	String bindTo();
	Class<?> ofClass() default Binding.class;
	String ofKey() default "";
}