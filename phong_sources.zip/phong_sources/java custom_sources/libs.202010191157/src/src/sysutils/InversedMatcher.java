//package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils;
//
//import java.util.HashMap;
//import java.util.Map;
//import java.util.regex.MatchResult;
//import java.util.regex.Matcher;
//
//public class InversedMatcher implements MatchResult {
//	private Matcher matcher;
//	private Map<String, Object> matches;
//	private int findIndex = -1;
//
//	public InversedMatcher(Matcher matcher) {
//		this.matcher = matcher;
//		init();
//	}
//
//	private void init() {
//		int matchCount = 0;
//		matches = new HashMap<String, Object>();
//		while (matcher.find()) {
//			matches.put(String.format("%d", matchCount), matcher.group(0));
//			matches.put(String.format("%d_start", matchCount), matcher.start());
//			matches.put(String.format("%d_end", matchCount), matcher.end());
//			matches.put(String.format("%d_groupCount", matchCount), matcher.groupCount());
//			for (int groupCount = 0; groupCount <= matcher.groupCount(); groupCount++) {
//				matches.put(String.format("%d_%d", matchCount, groupCount), matcher.group(groupCount));
//				matches.put(String.format("%d_%d_start", matchCount, groupCount), matcher.start(groupCount));
//				matches.put(String.format("%d_%d_end", matchCount, groupCount), matcher.end(groupCount));
//			}
//			matchCount++;
//		}
//		matches.put("size", matchCount);
//		findIndex = matchCount;
//	}
//
//	public boolean find() {
//		findIndex--;
//		return findIndex >= 0 && findIndex < (Integer)matches.get("size");
//	}
//
//	@Override
//	public int start() {
//		return (Integer)matches.get(String.format("%d_start", findIndex));
//	}
//
//	@Override
//	public int start(int group) {
//		return (Integer)matches.get(String.format("%d_%d_start", findIndex, group));
//	}
//
//	@Override
//	public int end() {
//		return (Integer)matches.get(String.format("%d_end", findIndex));
//	}
//
//	@Override
//	public int end(int group) {
//		return (Integer)matches.get(String.format("%d_%d_end", findIndex, group));
//	}
//
//	@Override
//	public String group() {
//		return (String)matches.get(String.format("%d", findIndex));
//	}
//
//	@Override
//	public String group(int group) {
//		return (String)matches.get(String.format("%d_%d", findIndex, group));
//	}
//
//	@Override
//	public int groupCount() {
//		return (Integer)matches.get(String.format("%d_groupCount", findIndex));
//	}
//}
