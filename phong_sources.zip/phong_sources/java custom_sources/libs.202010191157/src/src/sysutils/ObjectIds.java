//package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils;
//
//import java.util.HashMap;
//import java.util.Map;
//import java.util.regex.Pattern;
//
//import com.google.common.base.Objects;
//
//import lombok.val;
//
//public class ObjectIds {
//
//	/**
//	 * Common
//	 */
//	public static final ObjectIds COMMON_IDS = new ObjectIds();
//
//	/**
//	 * Properties
//	 */
//	private boolean isOneWay = true;
//	private boolean isCommon = false;
//	private final Map<Object, Object> hash = new HashMap<>();
//	private Long counter = 0L;
//
//	/**
//	 * Constructors
//	 */
//	public ObjectIds() {
//	}
//
//	public ObjectIds(boolean setOneWay, boolean setCommon) {
//		this.isOneWay = setOneWay;
//		this.isCommon = setCommon;
//	}
//
//	/**
//	 * Methods
//	 */
//	public static String parseKey(Long value) {
//		return String.format("$%d$", value);
//	}
//
//	public static boolean isObjectId(String id) {
//		return Pattern.matches("\\$(\\d+)\\$", id);
//	}
//
//	public String add(Object obj) {
//		val key = parseKey(this.counter++);
//		this.hash.put(key, obj);
//		if (!this.isOneWay) {
//			this.hash.put(obj, key);
//		}
//		if (this.isCommon && !Objects.equal(this, COMMON_IDS)) {
//			COMMON_IDS.add(obj);
//		}
//		return key;
//	}
//
//	public Object get(Object keyORobj) {
//		return this.hash.containsKey(keyORobj) ? this.hash.get(keyORobj) : keyORobj;
//	}
//
//	public Object remove(Object keyORobj) {
//		val result = this.hash.remove(keyORobj);
//		if (!this.isOneWay) {
//			this.hash.remove(result);
//		}
//		if (this.isCommon && !Objects.equal(this, COMMON_IDS)) {
//			COMMON_IDS.remove(keyORobj);
//		}
//		return result;
//	}
//
//	public void clear() {
//		if (this.isCommon) {
//			this.hash.forEach((key, value) -> {
//				COMMON_IDS.remove(key);
//			});
//		}
//		this.hash.clear();
//	}
//}
