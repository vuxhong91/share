package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

import org.apache.ibatis.javassist.NotFoundException;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.support.AopUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.AutoBindingMark;
import lombok.Getter;
import lombok.Setter;
import lombok.SneakyThrows;
import lombok.val;

@Component
@Scope("prototype")
@SuppressWarnings("deprecation")
@AutoBindingMark
public abstract class BindingObject {

	public static final List<BindingInfo> BINDING_LIST = new ArrayList<>();

	@SneakyThrows
	public static void createBinding(String declare, BindingObject source, BindingObject dest) {
		if (SysUtils.isEmpty(declare) || Objects.isNull(source) || Objects.isNull(dest))
			throw new NullPointerException();
		if (AopUtils.isAopProxy(source))
			source = (BindingObject)((Advised)source).getTargetSource().getTarget();
		if (AopUtils.isAopProxy(dest))
			dest = (BindingObject)((Advised)dest).getTargetSource().getTarget();
		val regex = "^#\\{\\s*(\\w+)=(\\w+)\\s*(,\\s*mode\\s*=\\s*(\\w+)\\s*)*\\}$";
		val pattern = Pattern.compile(regex, Pattern.UNICODE_CHARACTER_CLASS);
		val matcher = pattern.matcher(declare);
		if (matcher.matches()) {
			val fieldName1 = matcher.group(1);
			val fieldName2 = matcher.group(2);
			val fieldFounder1 = new FieldFounder(AopUtils.getTargetClass(source)) {
				{
					setFieldName(fieldName1);
				}
			};
			val fieldFounder2 = new FieldFounder(AopUtils.getTargetClass(dest)) {
				{
					setFieldName(fieldName2);
				}
			};
			if (fieldFounder1.has() && fieldFounder2.has()) {
				val obj1 = source;
				val obj2 = dest;
				val bindingInfo = new BindingInfo() {
					{
						setMode(BindingMode.valueOf(BindingMode.class, matcher.group(4)));
						setField1(fieldFounder1);
						setField2(fieldFounder2);
						setObject1(obj1);
						setObject2(obj2);
					}
				};
				BINDING_LIST.removeIf(x -> x.toString().equals(bindingInfo.toString()));
				BINDING_LIST.add(bindingInfo);
			} else {
				throw new NotFoundException("Field's name was wrong!");
			}
		}
	}

	@SneakyThrows
	public void createBinding(String declare, BindingObject dest) {
		createBinding(declare, this, dest);
	}

}

@Getter
@Setter
class BindingInfo {
	private BindingMode mode;
	private FieldFounder field1;
	private FieldFounder field2;
	private BindingObject object1;
	private BindingObject object2;

	@Override
	public String toString() {
		return String.format("%d:%s=%d:%s", object1.hashCode(), field1.find().getName(), object2.hashCode(), field2.find().getName());
	}
}

enum BindingMode {
	TWO_WAY,
	ONE_WAY_TO_DEST,
	ONE_WAY_TO_SOURCE;
}