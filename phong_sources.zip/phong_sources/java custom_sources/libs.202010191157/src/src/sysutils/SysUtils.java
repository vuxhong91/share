package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.regex.Pattern;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

import org.apache.commons.lang3.ClassUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.core.convert.support.DefaultConversionService;

import com.fasterxml.jackson.core.JsonParser.Feature;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.Binding;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.BindingOptions;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.ByteField;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.ExcelColField;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.FieldConditions;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.FieldReader;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseModel;
import lombok.SneakyThrows;
import lombok.val;
import lombok.experimental.UtilityClass;

@UtilityClass
public final class SysUtils {
	public static final String EMPTY = "";
	public static final String SEPARATOR = File.separator;
	public static final String CHARSET = "UTF-8";
	public static final DefaultConversionService VALUE_CONVERTER = new DefaultConversionService();
	public static final ScriptEngine SCRIPT_ENGINE = new ScriptEngineManager().getEngineByName("nashorn");
	public static final ObjectMapper JSON_PARSER = new ObjectMapper().configure(Feature.IGNORE_UNDEFINED, true);

	/**
     * Returns an array containing {@code Method} objects reflecting all the
     * declared methods of the class or interface represented by this {@code
     * Class} object, including public, protected, default (package)
     * access, and private methods.
	 */
	public static List<Method> getAllMethods(Class<?> clazz) {
		val result = new ArrayList<Method>();
		do {
			result.addAll(Arrays.asList(clazz.getDeclaredMethods()));
		} while (Objects.nonNull(clazz = clazz.getSuperclass()));
		return result;
	}

	/**
     * Returns an array of {@code Field} objects reflecting all the fields
     * declared by the class or interface represented by this
     * {@code Class} object. This includes public, protected, default
     * (package) access, and private fields.
	 */
	public static List<Field> getAllFields(Class<?> clazz) {
		val result = new ArrayList<Field>();
		do {
			result.addAll(Arrays.asList(clazz.getDeclaredFields()));
		} while (Objects.nonNull(clazz = clazz.getSuperclass()));
		return result;
	}

	/**
	 * クラスパッケージでクラスを取得する
	 *
	 * @param String className
	 * @return Class<?>
	 */
	public static Class<?> getClass(String className) {
		try {
			return ClassUtils.class.getClassLoader().loadClass(className);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * プロパーティの定義名やパスでプロパーティ値を取得
	 */
	public static Object getValue(String script, Object models) {
		val params = new HashMap<String, Object>();
		params.put(null, models);
		return getScriptValue(String.format("#{%s}", script), params);
	}

	public static Object getScriptValue(String script, Object models) {
		val params = new HashMap<String, Object>();
		params.put(null, models);
		params.put("_0", models);
		return getScriptValue(script, params);
	}

	public static Object getScriptValue(String script, Object... models) {
		val params = new HashMap<String, Object>();
		for (val m : models) {
			params.put(String.format("_%s", params.size()), m);
		}
		return getScriptValue(script, params);
	}

	@SneakyThrows
	@SuppressWarnings("rawtypes")
	public static Object getScriptValue(String script, Map<String, Object> models) {
		if (StringUtils.isEmpty(script))
			return null;
		String result = script;
		try {
			val regex = "#\\{(([\\w\\.]+)\\.)*([\\w]+)(\\[([\\w\\d]+)\\])*(\\(([\\w,\" ]*)\\))*(::(xxx)(=([\\w]+))*)*\\}";
			val pattern = Pattern.compile(regex, Pattern.UNICODE_CHARACTER_CLASS);
			val matcher = pattern.matcher(script);
			while (matcher.find()) {
				Object value = null;
				val str = matcher.group();
				val obj = iif(matcher.group(2),
						t -> models.containsKey(t) ? models.get(t) : null,
						SysUtils::getClass);
				val isClass = Objects.nonNull(obj) && obj instanceof Class;
				val checkingProperty = matcher.group(3);
				if (Objects.isNull(obj)) {
					if (models.containsKey(checkingProperty))
						value = models.get(checkingProperty);
				} else {
					val isArray = !isEmpty(matcher.group(4));
					val arrayGetIndex = matcher.group(5);
					if (isArray && Objects.isNull(arrayGetIndex))
						throw new Exception();
					val isMethod = !isEmpty(matcher.group(6));
					val methodParams = matcher.group(7);
					if (isArray && isMethod)
						throw new Exception();
//					val option = matcher.group(9);
//					val optionParams = matcher.group(11);
					if (isMethod) {
						val params = getScriptValueMethodParams(methodParams, models);
						val founder = new MethodFounder(isClass ? (Class)obj : obj.getClass()) {
							{
								setMethodName(checkingProperty);
							}
						};
						if (isClass)
							value = founder.tryInvoke(null, params.toArray());
						else
							value = founder.tryInvoke(obj, params.toArray());
					} else {
						value = FieldUtils.readField(obj, checkingProperty, true);
						if (isArray) {
							if (List.class.isAssignableFrom(value.getClass())) {
								value = ((List) value).get(Integer.parseInt(arrayGetIndex));
							} else if (value.getClass().isArray()) {
								value = ((Object[]) value)[Integer.parseInt(arrayGetIndex)];
							} else if (Map.class.isAssignableFrom(value.getClass())) {
								value = ((Map) value).get(arrayGetIndex);
							}
						}
					}
				}
				if (isAvailableBasicType(value)) {
					if (String.class.isAssignableFrom(value.getClass()))
						result = result.replace(str, String.format("\"%s\"", String.valueOf(value)));
					else
						result = result.replace(str, String.valueOf(value));
				} else {
					val name = String.format("__%d", models.size());
					models.put(name, value);
					result = result.replace(str, name);
				}
			}
			if (models.containsKey(result))
				return models.get(result);
			return result.equals(script) ? SCRIPT_ENGINE.eval(result) : getScriptValue(result, models);
		} catch (Exception e) {
			if (Pattern.matches("^\"(?:((\\\\\")|((?![\"]).))*)\"$", result))
				return StringUtils.strip(result, "\"");
			return result;
		}
	}

	private static List<Object> getScriptValueMethodParams(String params, Map<String, Object> models) {
		val regex = Pattern.compile("(\"(?:((\\\\\")|((?![\"]).))*)\")|([0-9\\.]+)|(#\\{.+\\})|([a-zA-Z0-9_]+)");
		val matcher = regex.matcher(params);
		val result = new ArrayList<Object>();
		while (matcher.find()) {
			result.add(VALUE_CONVERTER.convert(getScriptValue(matcher.group(), models), Object.class));
		}
		return result;
	}

	/**
	 * iif
	 */
	@SafeVarargs
	public static <T extends Object> Object iif(T t, Function<T, Object>... logics) {
		for (val l : logics) {
			val value = l.apply(t);
			if (Objects.nonNull(value))
				return value;
		}
		return t;
	}

	/**
	 * データグループ
	 */
	@SuppressWarnings("unchecked")
	public static <T, U extends Comparable<? super U>> Map<String, List<T>> groupData(List<T> data,
			Function<T, U>... keys) {
		val result = new HashMap<String, List<T>>();
		for (val item : data) {
			val keyBuilder = new StringBuilder();
			for (val k : keys) {
				Objects.requireNonNull(k);
				keyBuilder.append(k.apply(item));
			}
			val key = keyBuilder.toString();
			if (!result.containsKey(key)) {
				result.put(key, new ArrayList<T>());
			}
			val list = result.get(key);
			list.add(item);
		}
		return result;
	}

	/**
	 * 基本タイプチェック
	 */
	public static boolean isAvailableBasicType(Object obj) {
		return Objects.nonNull(obj) && isAvailableBasicType(obj.getClass());
	}

	public static boolean isAvailableBasicType(Class<?> clazz) {
		return String.class.equals(clazz)
				|| Short.class.equals(clazz)
				|| Integer.class.equals(clazz)
				|| Long.class.equals(clazz)
				|| Float.class.equals(clazz)
				|| Double.class.equals(clazz)
				|| Boolean.class.equals(clazz)
				|| Byte.class.equals(clazz)
				|| "string,short,int,long,float,double,boolean,byte".indexOf(clazz.getSimpleName()) >= 0;
	}

	public static Class<?> getAvailableBasicType(String name) {
		switch (name) {
		case "string":
		case "str":
			return String.class;
		case "short":
			return Short.class;
		case "integer":
		case "int":
			return Integer.class;
		case "long":
			return Long.class;
		case "float":
			return Float.class;
		case "double":
		case "real":
			return Double.class;
		case "boolean":
		case "bool":
			return Boolean.class;
		case "byte":
			return Byte.class;
		default:
			return null;
		}
	}

	/**
	 * データが空白かチェックする。</br>
	 * 可能：List、Array、String
	 */
	@SuppressWarnings("rawtypes")
	public static boolean isEmpty(Object obj) {
		return Objects.isNull(obj)
				|| (List.class.isAssignableFrom(obj.getClass()) && ((List) obj).isEmpty())
				|| (obj.getClass().isArray() && ((Object[]) obj).length == 0)
				|| (String.class.equals(obj.getClass()) && "".equals(obj));
	}

	/**
	 * 整数かチェックする。(Integer)
	 */
	public static boolean isInteger(String value) {
		try {
			Integer.parseInt(value);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * 整数かチェックする。(Double)
	 */
	public static boolean isDouble(String value) {
		try {
			Double.parseDouble(value);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * 数かチェックする。(Integer, Double)
	 */
	public static boolean isReal(String value) {
		return isInteger(value) || Pattern.matches("^([-]{0,1})([0-9]+)\\.([0-9]+)$", value);
	}

	public static void bindModel(Object dest, Object target) {
		bindModel(dest, target, "");
	}

	@SneakyThrows
	public static void bindModel(Object dest, Object target, String key) {
		//init
		val binded = new ArrayList<String>();
		//options
		val options = target.getClass().getAnnotation(BindingOptions.class);
		val autoBindingSameName = Objects.isNull(options) ? Boolean.TRUE : options.autoBindingSameName();
		//binded by annotation
		val fields = FieldUtils.getAllFields(dest.getClass());
		for (val f : fields) {
			val annos = f.getAnnotationsByType(Binding.class);
			for (val anno : annos) {
				if (!StringUtils.isEmpty(anno.bindTo())
						&& (Binding.class.equals(anno.ofClass()) || anno.ofClass().equals(target.getClass()))
						&& (StringUtils.isEmpty(anno.ofKey()) || anno.ofKey().equals(key))) {
					val ff = FieldUtils.getField(target.getClass(), anno.bindTo(), true);
					if (!Objects.isNull(ff)) {
						FieldUtils.writeField(ff, target, FieldUtils.readField(f, dest, true), true);
						binded.add(ff.getName());
					}
				}
			}
		}
		if (autoBindingSameName) {
			for (val f : fields) {
				if (!binded.contains(f.getName())) {
					val ff = FieldUtils.getField(target.getClass(), f.getName(), true);
					if (!Objects.isNull(ff)) {
						FieldUtils.writeField(ff, target, FieldUtils.readField(f, dest, true), true);
						binded.add(ff.getName());
					}
				}
			}
		}
	}

	/**
	 * バイトからモデルにセット（UTF-8）
	 */
	@SneakyThrows
	public static void writeModel(BaseModel model, String data, String seperator) {
		val fields = FieldUtils.getFieldsListWithAnnotation(model.getClass(), FieldReader.class);
		val strs = data.split(seperator, -1);
		int counter = 0;
		for (val f : fields) {
			val reader = f.getAnnotation(FieldReader.class);
			Object formatedValue = null;
			if (counter < strs.length && (reader.ignore().length == 0
					|| Arrays.stream(reader.ignore()).noneMatch(x -> x.equals(model.getClass())))) {
				formatedValue = strs[counter++];
				if (StringUtils.isEmpty((String) formatedValue)) {
					formatedValue = reader.defaultValue();
				}
				if (!StringUtils.isEmpty(reader.format())) {
					formatedValue = SCRIPT_ENGINE.eval(String.format(reader.format(), formatedValue));
				}
			}
			FieldUtils.writeField(f, model, VALUE_CONVERTER.convert(formatedValue, f.getType()), true);
		}
	}

	/**
	 * バイトからモデルにセット（UTF-8）
	 */
	@SneakyThrows
	public static void writeModel(Object model, byte[] bytes) {
		val byteFields = FieldUtils.getFieldsListWithAnnotation(model.getClass(), ByteField.class);
		for (val f : byteFields) {
			val bReader = f.getAnnotation(ByteField.class);
			val endIndex = bReader.startIndex() + bReader.length();
			FieldUtils.writeField(f, model, VALUE_CONVERTER.convert(getStringOfBytes(bytes, bReader.startIndex(), endIndex), f.getType()), true);
		}
	}

	/**
	 * Bytes⇒String
	 */
	@SneakyThrows
	public static String getStringOfBytes(byte[] byteArr, int startIndex, int endIndex) {
		val value = new String(Arrays.copyOfRange(byteArr, startIndex, endIndex), CHARSET).trim();
		return StringUtils.isEmpty(value) ? null : value;
	}

	/**
	 * poi.lib
	 * データ行からモデルにセット
	 */
	@SneakyThrows
	public static void writeModel(Object model, Row row) {
		val excelFields = FieldUtils.getFieldsListWithAnnotation(model.getClass(), ExcelColField.class);
		for (val f : excelFields) {
			val excelCol = f.getAnnotation(ExcelColField.class);
			FieldUtils.writeField(f, model, VALUE_CONVERTER.convert(getCelValue(row, excelCol.colIndex()), f.getType()), true);
		}
	}

	/**
	 * poi.lib
	 * セル値をゲット
	 */
	public static String getCelValue(Row row, int cell) {
		if (cell < row.getLastCellNum()) {
			Cell c = row.getCell(cell);
			c.setCellType(CellType.STRING);
			return c.getStringCellValue();
		}
		return null;
	}

	/**
	 * JacksonでDeepCopyする。
	 */
	@SneakyThrows
	@SuppressWarnings("unchecked")
	public static <T> T clone(T model, Class<?> clazz) {
		return (T)JSON_PARSER.readValue(JSON_PARSER.writeValueAsString(model), clazz);
	}

	/**
	 * Fieldsチェック
	 */
	private static final List<String> lastCheckedResult = new ArrayList<>();
	@SneakyThrows
	public static boolean checkFieldConditions(Object model) {
		Boolean result = true;
		lastCheckedResult.clear();
		val founder = new FieldFounder(model.getClass()) {
			{
				setAnnotationTypes(FieldConditions.class);
			}
		};
		result = (Boolean) iif(founder.forEach(f -> {
			try {
				if (Objects.nonNull(f.get(model))) {
					val annos = f.getAnnotationsByType(FieldConditions.class);
					for (val anno : annos) {
						if (!(Boolean)getScriptValue(anno.value(), model)) {
							lastCheckedResult.add(getCheckingMessage(anno.msg()));
							return false;
						}
					}
				}
			} catch (Exception e) {
			}
			return null;
		}), Objects::isNull);
		return result;
	}

	@SneakyThrows
	private static String getCheckingMessage(String msg) {
		if (isEmpty(msg))
			return EMPTY;
		val clazz = getClass(msg);
		if (Objects.nonNull(clazz) && Exception.class.isAssignableFrom(clazz))
			return ((Exception)clazz.newInstance()).getMessage();
		return msg;
	}

	public static List<String> getLastCheckedResult() {
		return lastCheckedResult;
	}
}
