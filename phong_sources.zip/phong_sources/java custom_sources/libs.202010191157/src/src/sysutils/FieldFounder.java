package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.SneakyThrows;
import lombok.ToString;
import lombok.val;

@Setter(AccessLevel.PROTECTED)
@ToString
@EqualsAndHashCode
@RequiredArgsConstructor
public class FieldFounder {

	/**
	 * パラメーター
	 */
	@NonNull
	private Class<?> clazz;
	private boolean findDeclared = false;

	private String fieldName;
	private boolean findNameExactly = true;

	private Class<?>[] annotationTypes;
	private boolean findFullAnnotated = true;

	private Function<Field, Boolean> checkPredicate;

	private List<Field> fieldsList;

	/**
	 * コンストラクタ
	 */
	public FieldFounder(List<Field> fieldsList) {
		this.fieldsList = fieldsList;
	}

	/**
	 * セッター
	 */
	protected void setAnnotationTypes(Class<?>... values) {
		annotationTypes = values;
	}

	/**
	 * キャッシュ
	 */
	public static final Map<String, List<Field>> CACHE = new HashMap<>();

	/**
	 * メソッド
	 */
	@SuppressWarnings("all")
	public List<Field> getFields() {
		if (SysUtils.isEmpty(fieldsList)) {
			val key = this.toString();
			if (CACHE.containsKey(key)) {
				fieldsList = CACHE.get(key);
			} else {
				Stream<Field> fields = findDeclared ? Arrays.asList(clazz.getDeclaredFields()).stream() : SysUtils.getAllFields(clazz).stream();
				if (!SysUtils.isEmpty(fieldName))
					fields = findNameExactly ? fields.filter(x -> x.getName().equals(fieldName)) : fields.filter(x -> x.getName().toLowerCase().contains(fieldName.toLowerCase()));
				if (!SysUtils.isEmpty(annotationTypes))
					if (findFullAnnotated)
						fields = fields.filter(x -> Arrays.stream(annotationTypes).allMatch(y -> !SysUtils.isEmpty(x.getAnnotationsByType((Class)y))));
					else
						fields = fields.filter(x -> Arrays.stream(annotationTypes).anyMatch(y -> !SysUtils.isEmpty(x.getAnnotationsByType((Class)y))));
				if (Objects.nonNull(checkPredicate))
					fields = fields.filter(x -> checkPredicate.apply(x));
				fieldsList = fields.collect(Collectors.toList());
				CACHE.put(key, fieldsList);
			}
		}
		return fieldsList;
	}

	public Field find() {
		return has() ? getFields().get(0) : null;
	}

	public boolean has() {
		return !getFields().isEmpty();
	}

	@SneakyThrows
	public Object get(Object obj) {
		if (has()) {
			val f = find();
			f.setAccessible(true);
			return f.get(obj);
		}
		return null;
	}

	@SneakyThrows
	public boolean set(Object obj, Object value) {
		if (has()) {
			val f = find();
			f.setAccessible(true);
			f.set(obj, value);
			return true;
		}
		return false;
	}

	public Object forEach(Function<Field, Object> action) {
		try {
			for (val f : getFields()) {
				f.setAccessible(true);
				val r = action.apply(f);
				if (Objects.nonNull(r))
					return r;
			}
		} catch (Exception e) {
		}
		return null;
	}

}
