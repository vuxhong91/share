package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils;

import java.util.stream.Collectors;

import org.apache.commons.lang3.ClassUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.AutoCallable;
import lombok.SneakyThrows;
import lombok.val;

@Aspect
@Component
public class BindingAspect {

	@SneakyThrows
	@Around("within(@jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.AutoBindingMark *) && execution(* *(..)) && !within(BindingAspect)")
	private Object around(ProceedingJoinPoint joinPoint) {
		Object res = null;
        try {
            // Before
    		MethodFounder beforeFounder;
    		if (BindingObject.class.isAssignableFrom(joinPoint.getSignature().getDeclaringType())
    				&& (!(beforeFounder = new MethodFounder(joinPoint.getSignature().getDeclaringType()) {
    					{
    						setParamTypes(ClassUtils.toClass(joinPoint.getArgs()));
    						setAnnotationTypes(AutoCallable.class);
    						setReturnType(Boolean.class);
    						setCheckPredicate(m -> {
    							val a = m.getAnnotation(AutoCallable.class);
    							return a.caller().equals(AutoCallable.Caller.BEFORE) && a.method().equals(joinPoint.getSignature().getName());
    						});
    					}
    				}).has() || beforeFounder.tryAll(joinPoint.getTarget(), joinPoint.getArgs()).getResultsList().stream().allMatch(x -> (Boolean)x))) {
    			val beforeData = SysUtils.JSON_PARSER.writeValueAsString(joinPoint.getTarget());
	            res = joinPoint.proceed();
	            // AfterReturning
	            // ...log?
	            // Binding
	            val afterData = SysUtils.JSON_PARSER.writeValueAsString(joinPoint.getTarget());
	            if (!beforeData.equals(afterData)) {
	            	binding(joinPoint);
	            }
	            // After
	    		val afterFounder = new MethodFounder(joinPoint.getSignature().getDeclaringType()) {
	    			{
	    				setParamTypes();
						setAnnotationTypes(AutoCallable.class);
						setCheckPredicate(m -> {
							val a = m.getAnnotation(AutoCallable.class);
							return a.caller().equals(AutoCallable.Caller.AFTER) && m.getName().equals(a.method());
						});
	    			}
	    		};
	    		afterFounder.invoke(joinPoint.getTarget());
    		} else {
    			// ...before -> false
    		}
        } catch (Exception e) {
            // AfterThrowing
        	res = null;
        } finally {
        	// Finally
        }
    	return res;
	}

	private void binding(JoinPoint joinPoint) {
		val bindingObj = (BindingObject)joinPoint.getTarget();
		for (val info : BindingObject.BINDING_LIST.stream().filter(x -> x.getObject1().equals(bindingObj)).collect(Collectors.toList())) {
			if (info.getMode().equals(BindingMode.TWO_WAY) || info.getMode().equals(BindingMode.ONE_WAY_TO_DEST)) {
				info.getField2().set(info.getObject2(), info.getField1().get(info.getObject1()));
			}
		}
		for (val info : BindingObject.BINDING_LIST.stream().filter(x -> x.getObject2().equals(bindingObj)).collect(Collectors.toList())) {
			if (info.getMode().equals(BindingMode.TWO_WAY) || info.getMode().equals(BindingMode.ONE_WAY_TO_SOURCE)) {
				info.getField1().set(info.getObject1(), info.getField2().get(info.getObject2()));
			}
		}
	}
}
