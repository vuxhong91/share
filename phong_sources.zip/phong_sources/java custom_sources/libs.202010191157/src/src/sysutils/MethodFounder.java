package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.ArrayUtils;

import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.SneakyThrows;
import lombok.ToString;
import lombok.val;

@Setter(AccessLevel.PROTECTED)
@ToString
@EqualsAndHashCode
@RequiredArgsConstructor
public class MethodFounder {

	/**
	 * パラメーター
	 */
	@NonNull
	private Class<?> clazz;
	private boolean findDeclared = false;

	private String methodName;
	private boolean findNameExactly = true;

	private Class<?> returnType;

	private Class<?>[] paramTypes;
	private boolean findParamTypesExactly = true;

	private Class<?>[] annotationTypes;
	private boolean findFullAnnotated = true;

	private Function<Method, Boolean> checkPredicate;

	private List<Method> methodsList;
	@Getter private List<Object> resultsList = new ArrayList<>();

	/**
	 * コンストラクタ
	 */
	public MethodFounder(List<Method> methodsList) {
		this.methodsList = methodsList;
	}

	/**
	 * セッター
	 */
	protected void setParamTypes(Class<?>... values) {
		paramTypes = values;
	}
	protected void setAnnotationTypes(Class<?>... values) {
		annotationTypes = values;
	}

	/**
	 * キャッシュ
	 */
	public static final Map<String, List<Method>> CACHE = new HashMap<>();

	/**
	 * メソッド
	 */
	@SuppressWarnings("all")
	public List<Method> getMethods() {
		if (SysUtils.isEmpty(methodsList)) {
			val key = this.toString();
			if (CACHE.containsKey(key)) {
				methodsList = CACHE.get(key);
			} else {
				Stream<Method> methods = findDeclared ? Arrays.asList(clazz.getDeclaredMethods()).stream() : SysUtils.getAllMethods(clazz).stream();
				if (!SysUtils.isEmpty(methodName))
					methods = findNameExactly ? methods.filter(x -> x.getName().equals(methodName)) : methods.filter(x -> x.getName().toLowerCase().contains(methodName.toLowerCase()));
				if (Objects.nonNull(returnType))
					methods = methods.filter(x -> returnType.isAssignableFrom(x.getReturnType()));
				if (Objects.nonNull(paramTypes))
					methods = methods.filter(x -> x.getParameterCount() >= paramTypes.length && Objects.deepEquals(Arrays.copyOfRange(x.getParameterTypes(), 0, paramTypes.length), paramTypes));
				if (Objects.nonNull(annotationTypes))
					if (findFullAnnotated)
						methods = methods.filter(x -> Arrays.stream(annotationTypes).allMatch(y -> !SysUtils.isEmpty(x.getAnnotationsByType((Class)y))));
					else
						methods = methods.filter(x -> Arrays.stream(annotationTypes).anyMatch(y -> !SysUtils.isEmpty(x.getAnnotationsByType((Class)y))));
				if (Objects.nonNull(checkPredicate))
					methods = methods.filter(x -> checkPredicate.apply(x));
				methodsList = methods.collect(Collectors.toList());
				CACHE.put(key, methodsList);
			}
		}
		return methodsList;
	}

	public Method find() {
		return has() ? getMethods().get(0) : null;
	}

	public boolean has() {
		return !getMethods().isEmpty();
	}

	@SneakyThrows
	public Object invoke(Object obj, Object... params) {
		if (has()) {
			val m = find();
			m.setAccessible(true);
			return m.invoke(obj, params);
		}
		return null;
	}

	public Object tryInvoke(Object obj, Object... params) {
		for (val m : getMethods()) {
			try {
				if (Objects.nonNull(obj) || Modifier.isStatic(m.getModifiers())) {
					m.setAccessible(true);
					if (m.getParameterCount() > 0 && params.length >= m.getParameterCount()
							&& m.getParameterTypes()[m.getParameterCount() - 1].isArray()
							&& Arrays.stream(Arrays.copyOfRange(params, m.getParameterCount() - 1, params.length)).allMatch(x -> m.getParameterTypes()[m.getParameterCount() - 1].getComponentType().isAssignableFrom(x.getClass()))) {
						return m.invoke(obj, ArrayUtils.add(Arrays.copyOfRange(params, 0, m.getParameterCount() - 1), Arrays.copyOfRange(params, m.getParameterCount() - 1, params.length)));
					}
					return m.invoke(obj, params);
				}
			} catch(Exception e) {}
		}
		return null;
	}

	public MethodFounder tryAll(Object obj, Object... params) {
		resultsList.clear();
		for (val m : getMethods()) {
			try {
				m.setAccessible(true);
				resultsList.add(m.invoke(obj, params));
			} catch(Exception e) {
				resultsList.add(null);
			}
		}
		return this;
	}

	public Object forEach(Function<Method, Object> action) {
		try {
			for (val m : getMethods()) {
				m.setAccessible(true);
				val r = action.apply(m);
				if (Objects.nonNull(r))
					return r;
			}
		} catch (Exception e) {
		}
		return null;
	}

}
