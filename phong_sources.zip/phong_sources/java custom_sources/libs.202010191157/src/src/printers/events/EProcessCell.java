package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.events;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public interface EProcessCell {
	boolean process(Row row, Cell cell, int rowIndex, int cellIndex, int index) throws Exception;
}