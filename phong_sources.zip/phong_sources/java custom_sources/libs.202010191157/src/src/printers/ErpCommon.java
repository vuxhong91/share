package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers;

import java.io.File;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.MofReader;
import lombok.experimental.UtilityClass;

@UtilityClass
public final class ErpCommon {
	public static final MofReader MOF_READER = new MofReader();
	public static final String EXCEL_PRINTER_ERP_FILE = "erp";
	public static final String EXCEL_PRINTER_JSON_FILE = "json";
	public static final String EXCEL_FILE = ".xlsx";
	public static final String ZIP_FILE = ".zip";
	public static final String SEPARATOR = File.separator;
	public static final String DEFAULT_CHARSET = "UTF-8";
	public static final String EMPTY = "";
	public static final String ZENKAKU_SPACE = "　";
}
