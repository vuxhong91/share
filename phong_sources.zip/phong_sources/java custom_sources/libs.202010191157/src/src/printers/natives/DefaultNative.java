package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.natives;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.ErpPrinter;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.annos.ErpPosDefiner;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.annos.ErpWriterCondition;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpBaseDataSetter;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpDataSetter;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpPageSetup;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpProp;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpRef;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpSettings;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpSheet;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpSheetProc;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpWriter;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpWriterAction;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.states.ErpCopyStates;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.states.ErpDataSetterStates;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.MethodFounder;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.SysUtils;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseModel;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseParams;
import lombok.SneakyThrows;
import lombok.val;

public class DefaultNative<P extends BaseParams, D extends BaseModel> extends CommonNative<P, D> {
	@SneakyThrows
	public void setupNative(ErpPrinter<P, D> prt, ErpSettings settings) {
		this.printer = prt;
		this.wbSettings = settings;
		this.poiLib = this.printer.getPoiLib();
		this.fileLib = this.printer.getFileLib();
		this.zipLib = this.printer.getZipLib();
		this.bindingObjects.put(BINDING_PRINTER, this.printer);
		this.bindingObjects.put(BINDING_PARAMS, this.printer.getReportParams());
		this.bindingObjects.put(BINDING_DATA, this.printer.getReportData());
	}

	@SneakyThrows
	public void propsProcess(Workbook wb, Sheet sheet, List<ErpProp> props) {
		if (!SysUtils.isEmpty(props)) {
			for (val prop : props) {
				this.processCell(sheet, prop.getPos(), (row, cell, rowIndex, colIndex, index) -> {
					this.propProc(wb, sheet, row, cell, rowIndex, colIndex, index, prop);
					return true;
				});
			}
		}
	}

	@SneakyThrows
	public void propProc(Workbook wb, Sheet sheet, Row row, Cell cell, int rowIndex, int colIndex, int index,
			ErpProp prop) {
		this.setFont(cell, prop.getFont(), prop.getFontSize(), prop.getColor());
		if (Objects.nonNull(prop.getWidth())) {
			row.getSheet().setColumnWidth(cell.getColumnIndex(), prop.getWidth());
		}
		if (Objects.nonNull(prop.getHeight())) {
			row.setHeight(prop.getHeight());
		}
		if (!StringUtils.isEmpty(prop.getFormat())) {
			cell.setCellFormula(prop.getFormat());
		}
		this.setAlign(cell, prop.getAlignHorizontal(), prop.getAlignVertical(), prop.getWrap(), prop.getShrink());
	}

	@SneakyThrows
	public void refsProcess(Workbook wb, Sheet sheet, List<ErpRef> refs) {
		if (!SysUtils.isEmpty(refs)) {
			for (val ref : refs) {
				this.processCell(sheet, ref.getPos(), (row, cell, rowIndex, colIndex, index) -> {
					this.dsProc(wb, sheet, row, cell, rowIndex, colIndex, index, ref);
					return true;
				});
			}
		}
	}

	@SneakyThrows
	public void dsProc(Workbook wb, Sheet sheet, Row row, Cell cell, int rowIndex, int colIndex, int index,
			ErpBaseDataSetter ds) {
		Object value = SysUtils.getScriptValue(ds.getValue(), this.bindingObjects);
		if (!StringUtils.isEmpty(ds.getDefaultValue()) && Objects.isNull(value)) {
			value = SysUtils.getScriptValue(ds.getDefaultValue(), this.bindingObjects);
		}
		if (Objects.nonNull(value)) {
			val type = value.getClass();
			if (Objects.equals(Boolean.class, type)) {
				cell.setCellValue((Boolean) value);
			} else if (Objects.equals(Calendar.class, type)) {
				cell.setCellValue((Calendar) value);
			} else if (Objects.equals(Date.class, type) || Objects.equals(java.sql.Date.class, type)) {
				cell.setCellValue((Date) value);
			} else if (Objects.equals(Double.class, type)) {
				cell.setCellValue((Double) value);
			} else if (Objects.equals(RichTextString.class, type)) {
				cell.setCellValue((RichTextString) value);
			} else {
				cell.setCellValue(String.valueOf(value));
			}
		}
		if (!StringUtils.isEmpty(ds.getFormat())) {
			cell.setCellFormula(ds.getFormat());
		}
		if (Objects.nonNull(ds.getProp())) {
			this.propProc(wb, sheet, row, cell, rowIndex, colIndex, index, ds.getProp());
		}
	}

	public void pageSetup(Workbook wb, Sheet sheet, ErpPageSetup pageStt) throws Exception {
		if (Objects.nonNull(pageStt)) {
			val setup = sheet.getPrintSetup();
			if (Objects.nonNull(pageStt.getFitWidth())) {
				setup.setFitWidth(pageStt.getFitWidth());
			}
			if (Objects.nonNull(pageStt.getFitHeight())) {
				setup.setFitHeight(pageStt.getFitHeight());
			}
			if (Objects.nonNull(pageStt.getLandscape())) {
				setup.setLandscape(pageStt.getLandscape());
			}
			if (Objects.nonNull(pageStt.getRepeatCols())) {
				sheet.setRepeatingColumns(CellRangeAddress.valueOf(pageStt.getRepeatCols()));
			}
			if (Objects.nonNull(pageStt.getRepeatRows())) {
				sheet.setRepeatingRows(CellRangeAddress.valueOf(pageStt.getRepeatRows()));
			}
		}
	}

	public void layoutProcess(Workbook wb, Sheet sheet, ErpSheet sheetStt) throws Exception {
		val layoutStt = sheetStt.getLayoutSettings();
		val states = new ErpCopyStates(wb, sheet);
		this.bindingObjects.put(BINDING_COPY_STATES, states);
		for (int i = 0; this.printer.beforeLayoutProcess(states); ++i) {
			states.setPageIndex(i);
			val whichHeader = i == 0 && !SysUtils.isEmpty(layoutStt.getFirstHeader()) ? layoutStt.getFirstHeader()
					: layoutStt.getLoopHeader();
			val procHeader = this.getAvailableSheetProc(whichHeader, states);
			val procBody = this.getAvailableSheetProc(layoutStt.getLoopBody(), states);
			ErpSheetProc procFooter = this.getAvailableSheetProc(layoutStt.getLastFooter(), states);
			if (Objects.isNull(procFooter)) {
				procFooter = this.getAvailableSheetProc(layoutStt.getLoopFooter(), states);
			}
			if (Objects.isNull(procHeader) && Objects.isNull(procBody) && Objects.isNull(procFooter)) {
				break;
			}
			if (Objects.nonNull(procHeader)) {
				this.copySheet(wb, sheet, sheetStt, states, procHeader);
			}
			if (Objects.nonNull(procBody)) {
				this.copySheet(wb, sheet, sheetStt, states, procBody);
			}
			if (Objects.nonNull(procFooter)) {
				this.copySheet(wb, sheet, sheetStt, states, procFooter);
			}
			sheet.setRowBreak(sheet.getLastRowNum() - 1);
			this.printer.afterLayoutProcess(states);
		}
	}

	@SneakyThrows
	public void copySheet(Workbook wb, Sheet sheet, ErpSheet sheetStt, ErpCopyStates states, ErpSheetProc sheetProc) {
		int copyRowIndex = sheet.getLastRowNum();
		states.setCopyRowIndex(copyRowIndex);
		this.poiLib.copySheet(sheet, wb.getSheet(sheetProc.getSheetName()), copyRowIndex, 0, false);
		if (!StringUtils.isEmpty(sheetProc.getWriterName())) {
			this.writerProcess(wb, sheet, sheetStt, sheetProc, states, states.getHeaderDsStates());
		}
	}

	@SneakyThrows
	@SuppressWarnings("deprecation")
	public void writerProcess(Workbook wb, Sheet sheet, ErpSheet sheetStt, ErpSheetProc sheetProc, ErpCopyStates states,
			ErpDataSetterStates dsStates) {
		this.bindingObjects.put(BINDING_DS_STATES, dsStates);
		val writer = this.getAvailableWriter(sheetStt.getWriters(), sheetProc.getWriterName());
		MethodFounder writerMethod;
		if (Objects.nonNull(writer)
				&& (writerMethod = new MethodFounder(this.printer.getClass()) {
						{
							setMethodName(writer.getCondition());
							setParamTypes(ErpWriter.class, ErpCopyStates.class, ErpDataSetterStates.class);
							setAnnotationTypes(ErpWriterCondition.class);
						}
				}).has()
				&& (Boolean)writerMethod.invoke(this.printer, writer, states, dsStates)) {
			dsStates.incWriterIndex();
			dsStates.incWriterDetailsIndex(writer.getWriterName());
			this.loopData(wb, sheet, writer, writer.getActions(), states, dsStates);
		}
	}

	@SuppressWarnings("deprecation")
	@SneakyThrows
	public void loopData(Workbook wb, Sheet sheet, ErpWriter writer, List<ErpWriterAction> loop, ErpCopyStates states,
			ErpDataSetterStates dsStates) {
		for (val setter : loop) {
			MethodFounder setterMethod;
			if ((setterMethod = new MethodFounder(this.printer.getClass()) {
						{
							setMethodName(setter.getPosDef());
							setParamTypes(ErpWriter.class, ErpWriterAction.class, ErpCopyStates.class, ErpDataSetterStates.class);
							setAnnotationTypes(ErpPosDefiner.class);
						}
				}).has()) {
				val originPos = CellRangeAddress.valueOf(setter.getPos());
				originPos.setFirstRow(originPos.getFirstRow() + states.getCopyRowIndex());
				originPos.setLastRow(originPos.getLastRow() + states.getCopyRowIndex());
				dsStates.setOriginPos(originPos);
				dsStates.setCurrentPos(originPos);
				dsStates.resetSetterCurrentIndex();
				CellRangeAddress pos;
				while (Objects.nonNull(pos = (CellRangeAddress)setterMethod.invoke(this.printer, writer, setter, states, dsStates))) {
					dsStates.setCurrentPos(pos);
					dsStates.setBindingObject(SysUtils.getScriptValue(setter.getBinding(), this.bindingObjects));
					this.bindingObjects.put(BINDING_SETTER_OBJ, dsStates.getBindingObject());
					this.setData(wb, sheet, setter, dsStates);
					dsStates.incSetterCurrentIndex();
					dsStates.incSetterTotalIndex();
				}
			}
		}
	}

	@SneakyThrows
	public void setData(Workbook wb, Sheet sheet, ErpWriterAction s, ErpDataSetterStates dsStates) {
		this.processCell(sheet, dsStates.getCurrentPos(), (row, cell, rowIndex, colIndex, index) -> {
			if (index >= s.getSets().size()) {
				return false;
			}
			this.setterProc(wb, sheet, row, cell, rowIndex, colIndex, index, s.getSets().get(index), s, dsStates);
			return true;
		});
	}

	@SneakyThrows
	public void setterProc(Workbook wb, Sheet sheet, Row row, Cell cell, int rowIndex, int colIndex, int index,
			ErpDataSetter set, ErpWriterAction s, ErpDataSetterStates dsStates) {
		if (Objects.nonNull(set.getOffsetX()) || Objects.nonNull(set.getOffsetY())) {
			if (Objects.nonNull(set.getOffsetY())) {
				rowIndex = cell.getRowIndex() + set.getOffsetY();
			}
			if (Objects.nonNull(set.getOffsetX())) {
				colIndex = cell.getColumnIndex() + set.getOffsetX();
			}
			row = sheet.getRow(rowIndex);
			cell = row.getCell(colIndex);
		}
		this.dsProc(wb, sheet, row, cell, rowIndex, colIndex, index, set);
		if (!SysUtils.isEmpty(set.getSets())) {
			for (val x : set.getSets()) {
				this.setterProc(wb, sheet, row, cell, rowIndex, colIndex, index, x, s, dsStates);
			}
		}

	}

	@SneakyThrows
	public void lastProcess(Workbook wb, Sheet sheet, ErpSheet settings) {
		if (Boolean.TRUE.equals(settings.getRemove())) {
			wb.removeSheetAt(wb.getSheetIndex(settings.getSheetName()));
		} else if (Boolean.TRUE.equals(settings.getHidden())) {
			wb.setSheetHidden(wb.getSheetIndex(settings.getSheetName()), true);
		}
	}
}
