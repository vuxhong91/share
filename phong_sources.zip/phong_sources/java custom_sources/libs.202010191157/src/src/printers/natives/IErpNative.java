package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.natives;

import java.util.List;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.ErpPrinter;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpPageSetup;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpProp;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpRef;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpSettings;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpSheet;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpSheetProc;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.states.ErpCopyStates;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.states.ErpDataSetterStates;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseModel;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseParams;

public interface IErpNative<P extends BaseParams, D extends BaseModel> {
   void setupNative(ErpPrinter<P, D> var1, ErpSettings var2) throws Exception;

   void propsProcess(Workbook var1, Sheet var2, List<ErpProp> var3) throws Exception;

   void refsProcess(Workbook var1, Sheet var2, List<ErpRef> var3) throws Exception;

   void pageSetup(Workbook var1, Sheet var2, ErpPageSetup var3) throws Exception;

   void layoutProcess(Workbook var1, Sheet var2, ErpSheet var3) throws Exception;

   void writerProcess(Workbook var1, Sheet var2, ErpSheet var3, ErpSheetProc var4, ErpCopyStates var5, ErpDataSetterStates var6) throws Exception;

   void lastProcess(Workbook var1, Sheet var2, ErpSheet var3) throws Exception;
}