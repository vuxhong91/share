package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.natives;

import java.io.File;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.MethodUtils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.extensions.XSSFCellBorder.BorderSide;
import org.springframework.beans.factory.annotation.Autowired;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.ErpCommon;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.ErpPrinter;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.enums.ProcessCellResultEnum;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.events.EProcessCell;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpSettings;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpSheetProc;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpWriter;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.states.ErpCopyStates;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.SysUtils;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.enums.WarekiFormatEnum;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.libs.FileLib;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.libs.ZipLib;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseModel;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseParams;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.utils.DateUtils;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.utils.NumberUtils;
import jp.gunma.pref.police.gpwan.g9common.s01com.f10rptlib.libs.POILib;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.val;

public abstract class CommonNative<P extends BaseParams, D extends BaseModel> implements IErpNative<P, D> {

	@Getter
	@Autowired
	protected POILib poiLib;

	@Getter
	@Autowired
	protected FileLib fileLib;

	@Getter
	@Autowired
	protected ZipLib zipLib;

	@Getter
	@Autowired
	protected ErpPrinter<P, D> printer;

	@Getter
	@Autowired
	protected ErpSettings wbSettings;

	@Getter
	protected Map<String, Object> bindingObjects = new HashMap<>();
	protected static final String BINDING_PRINTER = "printer";
	protected static final String BINDING_PARAMS = "params";
	protected static final String BINDING_DATA = "data";
	protected static final String BINDING_COPY_STATES = "cpStates";
	protected static final String BINDING_DS_STATES = "dsStates";
	protected static final String BINDING_SETTER_OBJ = null;

	@SneakyThrows
	public ProcessCellResultEnum processCell(Sheet sheet, String area, EProcessCell processor) {
		return !StringUtils.isEmpty(area) ? this.processCell(sheet, CellRangeAddress.valueOf(area), processor)
				: ProcessCellResultEnum.FAIL;
	}

	@SneakyThrows
	public ProcessCellResultEnum processCell(Sheet sheet, CellRangeAddress area, EProcessCell processor) {
		if (Objects.nonNull(area)) {
			val minX = area.getFirstColumn();
			val minY = area.getFirstRow();
			val maxX = area.getLastColumn();
			val maxY = area.getLastRow();
			Integer i = 0;
			for (int c = minX; c <= maxX; ++c) {
				for (int r = minY; r <= maxY; ++r) {
					val row = sheet.getRow(r);
					val cell = row.getCell(c);
					if (!processor.process(row, cell, r, c, i)) {
						return ProcessCellResultEnum.BREAK;
					}
					i = i + 1;
				}
			}
			return ProcessCellResultEnum.SUCCESS;
		}
		return ProcessCellResultEnum.FAIL;
	}

	public void setBorder(Cell cell, BorderSide side, BorderStyle borderStyle) throws Exception {
		val souce = cell.getCellStyle();
		val style = cell.getRow().getSheet().getWorkbook().createCellStyle();
		style.cloneStyleFrom(souce);

		switch (side) {
		case TOP:
			style.setBorderTop(borderStyle);
			break;
		case RIGHT:
			style.setBorderRight(borderStyle);
			break;
		case BOTTOM:
			style.setBorderBottom(borderStyle);
			break;
		case LEFT:
			style.setBorderLeft(borderStyle);
			break;
		default:
			break;
		}

		cell.setCellStyle(style);
	}

	public void setFont(Cell cell, String fontName, Short fontHeight, Short color) {
		val wb = cell.getRow().getSheet().getWorkbook();
		val souce = cell.getCellStyle();
		val style = cell.getRow().getSheet().getWorkbook().createCellStyle();

		style.cloneStyleFrom(souce);
		val f = wb.createFont();
		if (!StringUtils.isEmpty(fontName)) {
			f.setFontName(fontName);
		}
		if (Objects.nonNull(fontHeight)) {
			f.setFontHeightInPoints(fontHeight);
		}
		if (Objects.nonNull(color)) {
			f.setColor(color);
		}

		style.setFont(f);
		cell.setCellStyle(style);
	}

	@SuppressWarnings("deprecation")
	@SneakyThrows
	public void setAlign(Cell cell, Short alignH, Short alignV, Boolean wrap, Boolean shrink) {
		val souce = cell.getCellStyle();
		val style = cell.getRow().getSheet().getWorkbook().createCellStyle();

		style.cloneStyleFrom(souce);
		if (Objects.nonNull(alignH)) {
			style.setAlignment(alignH);
		}
		if (Objects.nonNull(alignV)) {
			style.setVerticalAlignment(alignV);
		}
		if (Boolean.TRUE.equals(wrap)) {
			style.setWrapText(true);
		}
		if (Boolean.TRUE.equals(wrap)) {
			style.setShrinkToFit(true);
		}

		cell.setCellStyle(style);
	}

	/**
	 * 和暦フォーマット
	 * gg → 元号YY年
	 * gx → 元号
	 * gy → 和暦年
	 * sgy → fixed 和暦年 ("02" → " 2")
	 * ngy → fixed 和暦年 ("02" → "2")
	 * sMM → fixed Month  ("01" → " 1")
	 * sdd → fixed Day    ("01" → " 1")
	 * M, MM → Month
	 * d, dd → Day
	 * H, HH → Hour (24h)
	 * h, hh → Hour (12h)
	 * m, mm → Minute
	 * s, ss → Second
	 * a → 午前・午後
	 * cccc → X曜日
	 */
	@SneakyThrows
	public String formatDateWareki(String format, String value) {
		if (StringUtils.isEmpty(value) || value.length() < 8 || value.length() % 2 == 1 || !NumberUtils.isNumber(value))
			return ErpCommon.EMPTY;
		val tmp = DateUtils.convertWareki(value, WarekiFormatEnum.正式年号年に変換);
		// New formatter
		if (format.contains("gg")) { // 元号XX年
			format = format.replace("gg", tmp);
		}
		if (format.contains("gx")) { // 元号
			format = format.replace("gx", tmp.substring(0, 2));
		}
		if (format.contains("gy")) { // （年）
			val yy = tmp.substring(2, tmp.indexOf("年"));
			if (NumberUtils.isNumber(yy)) {
				val year = String.valueOf(Integer.valueOf(yy));
				if (format.contains("sgy")) {
					format = format.replace("sgy", "  ".substring(year.length()) + year);
				} else if (format.contains("ngy")) {
					format = format.replace("ngy", year);
				}
			}
			format = format.replaceAll("(sgy|ngy|gy)", yy);
		}
		val month = String.valueOf(Integer.valueOf(value.substring(4, 6)));
		val day = String.valueOf(Integer.valueOf(value.substring(6, 8)));
		if (format.contains("sMM")) {
			format = format.replace("sMM", "  ".substring(month.length()) + month); // （月）
		}
		if (format.contains("sdd")) {
			format = format.replace("sdd", "  ".substring(day.length()) + day); // （日）
		}
		// Java formatter
		value += "00000000000000".substring(value.length());
		val zonedDateTime = LocalDateTime.parse(value, DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))
				.atZone(ZoneId.of("Asia/Tokyo"));
		val jpFormatter = DateTimeFormatter.ofPattern(format, Locale.JAPAN);
		return zonedDateTime.format(jpFormatter);
	}

	/**
	 * マージシート
	 */
	@SneakyThrows
	public File mergeSheets(List<File> files) {
		if (SysUtils.isEmpty(files))
			return null;
		if (files.size() == 1)
			return files.get(0);
		val first = files.get(0);
		try (val wbMain = this.poiLib.importExcelWorkbook(first)) {
			for (int i = 1; i < files.size(); i++) {
				try (val wb = this.poiLib.importExcelWorkbook(files.get(i))) {
					for (int j = 0; j < wbMain.getNumberOfSheets(); j++) {
						val a = wbMain.getSheetAt(j);
						val b = wb.getSheetAt(j);
						a.setRowBreak(a.getLastRowNum());
						this.poiLib.getCell(a, a.getLastRowNum() + 1, 1).setCellValue("　");
						this.poiLib.copySheet(a, b, a.getLastRowNum(), 0, false);
						a.removeRow(a.getRow(a.getLastRowNum()));
					}
				}
			}
			this.poiLib.saveExcelWorkbook(wbMain, first, true);
		}
		return first;
	}

	@SneakyThrows
	public <T extends ErpSheetProc> T getAvailableSheetProc(List<T> list, ErpCopyStates states) {
		if (SysUtils.isEmpty(list)) {
			return null;
		}
		val tmp = list.stream().filter((x) -> {
			if (StringUtils.isEmpty(x.getCondition())) {
				return true;
			}
			try {
				return (Boolean)MethodUtils.invokeMethod(this.printer, true, x.getCondition(), states);
			} catch (Exception e) {
				return false;
			}
		}).findFirst();
		return tmp.isPresent() ? tmp.get() : null;
	}

	@SneakyThrows
	public <T extends ErpWriter> T getAvailableWriter(List<T> list, String writerName) {
		val tmp = list.stream().filter(x -> Objects.equals(writerName, x.getWriterName())).findFirst();
		return tmp.isPresent() ? tmp.get() : null;
	}
}
