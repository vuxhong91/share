package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers;

import java.io.File;
import java.util.Collections;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.io.Files;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.MofReader;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpJsonDeclare;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpSettings;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.SysUtils;

public final class ErpReader extends MofReader {
	public static List<ErpSettings> read(File file) throws Exception {
		if (file.exists() && file.isFile()) {
			if (Files.getFileExtension(file.getPath()).equals(ErpCommon.EXCEL_PRINTER_ERP_FILE)) {
				return ErpCommon.MOF_READER.read(ErpSettings.class, file);
			}
			if (Files.getFileExtension(file.getPath()).equals(ErpCommon.EXCEL_PRINTER_JSON_FILE)) {
				return SysUtils.JSON_PARSER.readValue(file, ErpJsonDeclare.class).getDeclare();
			}
		}
		return Collections.emptyList();
	}

	public static String parseERPtoJSON(File erp) throws JsonProcessingException, Exception {
		return SysUtils.JSON_PARSER.writeValueAsString(read(erp));
	}
}
