package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.reflect.FieldUtils;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.annos.ErpMethodNameField;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.annos.ErpRequiredField;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.SysUtils;
import lombok.val;
import lombok.experimental.UtilityClass;

@UtilityClass
public final class ErpChecker {
	@SuppressWarnings("rawtypes")
	public static void checkErpData(Object caller, Object obj, String... msg) throws Exception {
		if (Objects.nonNull(obj)) {
			val newMsg = (String[]) Arrays.copyOf(msg, msg.length + 1);
			newMsg[newMsg.length - 1] = obj.getClass().getSimpleName();
			if (List.class.isAssignableFrom(obj.getClass())) {
				for (val item : (List) obj) {
					checkErpData(caller, item, newMsg);
				}
			} else if (obj.getClass().isArray()) {
				for (val item : (Object[]) obj) {
					checkErpData(caller, item, newMsg);
				}
			} else {
				val fields = obj.getClass().getDeclaredFields();
				for (val f : fields) {
					val value = FieldUtils.readField(f, obj, true);

					val required = f.getAnnotation(ErpRequiredField.class);
					if (Objects.nonNull(required) && Objects.isNull(value)) {
						throw new Exception(String.format("%s: フィールド<%s>NULLが出来ません。", String.join(".", newMsg), f.getName()));
					}
					val isMethod = f.getAnnotation(ErpMethodNameField.class);
					if (Objects.nonNull(isMethod) && Objects.nonNull(value)
							&& Objects.isNull(Arrays.stream(caller.getClass().getMethods()).anyMatch(x -> x.getName().equals(String.valueOf(value))))) {
						throw new Exception(String.format("%s: メソッド<%s>が存在しません。", String.join(".", newMsg), value));
					}
					if (Objects.nonNull(value) && !SysUtils.isAvailableBasicType(f.getType())) {
						checkErpData(caller, value, newMsg);
					}
				}
			}
		}
	}
}
