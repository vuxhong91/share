package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.annos.MofClass;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@EqualsAndHashCode(callSuper=true)
@Accessors(chain=true)
@NoArgsConstructor
@JsonInclude(Include.NON_EMPTY)
@MofClass(name = "loopFooter")
public class ErpLoopFooter extends ErpSheetProc {
}
