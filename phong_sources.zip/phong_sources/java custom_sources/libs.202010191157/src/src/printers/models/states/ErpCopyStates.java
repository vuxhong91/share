package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.states;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import lombok.Data;

@Data
public final class ErpCopyStates {
	private Integer pageIndex = 0;
	private Workbook workbook;
	private Sheet sheet;
	private Integer copyRowIndex;
	private ErpDataSetterStates headerDsStates;
	private ErpDataSetterStates bodyDsStates;
	private ErpDataSetterStates footerDsStates;

	public ErpCopyStates(Workbook wb, Sheet st) {
		this.workbook = wb;
		this.sheet = st;
		this.headerDsStates = new ErpDataSetterStates();
		this.bodyDsStates = new ErpDataSetterStates();
		this.footerDsStates = new ErpDataSetterStates();
	}
}
