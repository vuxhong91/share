package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.annos.MofClass;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.annos.MofField;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.FieldIndex;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_EMPTY)
@MofClass(name = "custom")
public final class ErpCustom {
	@MofField(index = 1, name = "value")
	@FieldIndex(index = 10)
	private String value;
	@MofField
	@FieldIndex(index = 20)
	private List<ErpCustom> custom;
}
