package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.states;

import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.util.CellRangeAddress;

import lombok.Data;

@Data
public final class ErpDataSetterStates {
	private Integer writerIndex = 0;
	private Map<String, Integer> writerDetailsIndex = new HashMap<>();
	private Integer setterTotalIndex = 0;
	private Integer setterCurrentIndex = 0;
	private CellRangeAddress originPos = null;
	private CellRangeAddress currentPos = null;
	private Object bindingObject = null;

	@Deprecated
	public void incWriterIndex() {
		this.writerIndex = this.writerIndex + 1;
	}

	@Deprecated
	public void incWriterDetailsIndex(String writerName) {
		if (!this.writerDetailsIndex.containsKey(writerName)) {
			this.writerDetailsIndex.put(writerName, new Integer(0));
		}
		Integer value = (Integer) this.writerDetailsIndex.get(writerName);
		this.writerDetailsIndex.put(writerName, value + 1);
	}

	public Integer getWriterDetailsIndex(String writerName) {
		if (!this.writerDetailsIndex.containsKey(writerName)) {
			this.writerDetailsIndex.put(writerName, new Integer(0));
		}
		return (Integer) this.writerDetailsIndex.get(writerName);
	}

	@Deprecated
	public void incSetterTotalIndex() {
		this.setterTotalIndex = this.setterTotalIndex + 1;
	}

	@Deprecated
	public void incSetterCurrentIndex() {
		this.setterCurrentIndex = this.setterCurrentIndex + 1;
	}

	@Deprecated
	public void resetSetterCurrentIndex() {
		this.setterCurrentIndex = 0;
	}

	public CellRangeAddress moveCurrentPos(int rowStep, int colStep) {
		CellRangeAddress pos = CellRangeAddress.valueOf(this.currentPos.formatAsString());
		if (rowStep != 0) {
			pos.setFirstRow(pos.getFirstRow() + rowStep);
			pos.setLastRow(pos.getLastRow() + rowStep);
		}
		if (colStep != 0) {
			pos.setFirstColumn(pos.getFirstColumn() + colStep);
			pos.setLastColumn(pos.getLastColumn() + colStep);
		}
		return pos;
	}
}
