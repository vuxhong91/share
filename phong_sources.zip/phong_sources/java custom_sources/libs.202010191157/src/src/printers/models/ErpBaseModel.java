package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.annos.MofField;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.FieldIndex;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_EMPTY)
public abstract class ErpBaseModel {
	@MofField
	@FieldIndex(index = 9999)
	private List<ErpCustom> custom;
}
