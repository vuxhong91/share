package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.annos.MofClass;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.annos.MofField;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.annos.ErpRequiredField;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.FieldIndex;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@EqualsAndHashCode(callSuper=true)
@Accessors(chain=true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_EMPTY)
@MofClass(name = "sheet")
public class ErpSheet extends ErpBaseModel {
	@ErpRequiredField
	@MofField(index = 1, name = "sName")
	@FieldIndex(index = 10)
	private String sheetName;
	@MofField
	@FieldIndex(index = 20)
	private List<ErpProp> props;
	@MofField
	@FieldIndex(index = 30)
	private List<ErpRef> refs;
	@MofField
	@FieldIndex(index = 40)
	private ErpPageSetup pageSetup;
	@MofField
	@FieldIndex(index = 60)
	private ErpLayout layoutSettings;
	@MofField
	@FieldIndex(index = 80)
	private List<ErpWriter> writers;
	@MofField(name = "wRemove")
	@FieldIndex(index = 100)
	private Boolean remove;
	@MofField(name = "wHide")
	@FieldIndex(index = 110)
	private Boolean hidden;
	@MofField(name = "rename")
	@FieldIndex(index = 999)
	private String rename;
}
