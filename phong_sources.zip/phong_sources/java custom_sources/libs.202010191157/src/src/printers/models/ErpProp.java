package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.annos.MofClass;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.annos.MofField;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.annos.ErpRequiredField;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.FieldIndex;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@EqualsAndHashCode(callSuper=true)
@Accessors(chain=true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_EMPTY)
@MofClass(name = "prop")
public class ErpProp extends ErpBaseModel {
	@ErpRequiredField
	@MofField(index = 1, name = "pos")
	@FieldIndex(index = 10)
	private String pos;
	@MofField(name = "font")
	@FieldIndex(index = 20)
	private String font;
	@MofField(name = "fsize")
	@FieldIndex(index = 30)
	private Short fontSize;
	@MofField(name = "color")
	@FieldIndex(index = 40)
	private Short color;
	@MofField(name = "width")
	@FieldIndex(index = 100)
	private Integer width;
	@MofField(name = "height")
	@FieldIndex(index = 110)
	private Short height;
	@MofField(name = "format")
	@FieldIndex(index = 200)
	private String format;
	@MofField(name = "alignH")
	@FieldIndex(index = 210)
	private Short alignHorizontal;
	@MofField(name = "alignV")
	@FieldIndex(index = 220)
	private Short alignVertical;
	@MofField(name = "wrap")
	@FieldIndex(index = 230)
	private Boolean wrap;
	@MofField(name = "shrink")
	@FieldIndex(index = 240)
	private Boolean shrink;
}
