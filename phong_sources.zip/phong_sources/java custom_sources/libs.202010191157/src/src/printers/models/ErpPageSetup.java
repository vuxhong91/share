package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.annos.MofClass;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.annos.MofField;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.FieldIndex;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@EqualsAndHashCode(callSuper=true)
@Accessors(chain=true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_EMPTY)
@MofClass(name = "pageSetup")
public class ErpPageSetup extends ErpBaseModel {
	@MofField(index = 1, name = "fitWidth")
	@FieldIndex(index = 10)
	private Short fitWidth;
	@MofField(index = 2, name = "fitHeight")
	@FieldIndex(index = 20)
	private Short fitHeight;
	@MofField(index = 3, name = "landscape")
	@FieldIndex(index = 30)
	private Boolean landscape;
	@MofField(name = "repeatCols")
	@FieldIndex(index = 40)
	private String repeatCols;
	@MofField(name = "repeatRows")
	@FieldIndex(index = 50)
	private String repeatRows;
}
