package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.annos.MofField;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.annos.ErpRequiredField;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.FieldIndex;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@EqualsAndHashCode(callSuper=true)
@Accessors(chain=true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_EMPTY)
public abstract class ErpBaseDataSetter extends ErpBaseModel {
	@ErpRequiredField
	@MofField(index = 1, name = "value")
	@FieldIndex(index = 100)
	private String value;
	@MofField(index = 2, name = "default")
	@FieldIndex(index = 110)
	private String defaultValue;
	@MofField(name = "format")
	@FieldIndex(index = 120)
	private String format;
	@MofField(name = "prop")
	@FieldIndex(index = 888)
	private ErpProp prop;
}
