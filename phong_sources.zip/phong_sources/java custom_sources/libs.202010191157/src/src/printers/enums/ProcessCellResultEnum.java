package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.enums;

import lombok.Getter;

public enum ProcessCellResultEnum {
	BREAK("-1"),
	FAIL("0"),
	SUCCESS("1");

	@Getter
	private final String value;

	private ProcessCellResultEnum(String value) {
		this.value = value;
	}
}