package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.google.common.io.Files;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpDebugSettings;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpSettings;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpSheet;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.states.ErpCopyStates;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.natives.DefaultNative;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.natives.IErpNative;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.MethodFounder;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.SysUtils;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.configs.G9CommonConfig;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.libs.FileLib;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.libs.IdGeneratorLib;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.libs.ZipLib;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseModel;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseParams;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.ChohyoFileId;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.Context;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.IchijiFileId;
import jp.gunma.pref.police.gpwan.g9common.s01com.f10rptlib.libs.POILib;
import lombok.Getter;
import lombok.Setter;
import lombok.SneakyThrows;
import lombok.val;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Primary
@Component
public abstract class ErpPrinter<P extends BaseParams, D extends BaseModel> {

	/**
	 * Libs
	 */
	@Getter
	@Autowired
	protected POILib poiLib;

	@Getter
	@Autowired
	protected FileLib fileLib;

	@Getter
	@Autowired
	protected ZipLib zipLib;

	@Getter
	@Autowired
	protected G9CommonConfig g9CommonConfig;

	@Getter
	@Autowired
	protected IdGeneratorLib idGeneratorLib;

	/**
	 * Messages
	 */
	public static final String PRINT_START = "{}<{}, {}>：開始。";
	public static final String PRINT_END = "{}<{}, {}>：終了。";
	public static final String PRINT_INVALID = "{}<{}, {}>：帳票の印刷が許可されなかったです。処理終了。";
	public static final String EXPORT_EMPTY = "帳票なし。";
	public static final String EXPORT_SUCCESS = "帳票エクスポートが成功しました。（ファイル数：{}　―　ファイル名：{}）";

	/**
	 * Cache
	 */
	@Getter
	private Context context;

	@Getter
	@Setter
	private P reportParams;

	@Getter
	@Setter
	private D reportData;

	@Getter
	@Setter
	private IErpNative<P, D> erpNative = new DefaultNative<>();

	@Getter
	@Setter
	private List<ErpSettings> reportSettings;

	@Getter
	private Long lastModified;

	public String getSettingsFile() throws Exception {
		return null;
	}

	public ErpDebugSettings isDebugMode() throws Exception {
		return null;
	}

	public String getZipName() throws Exception {
		return null;
	}

	public boolean beforePrint() throws Exception {
		return true;
	}

	public boolean beforeCreateReport(ErpSettings settings) throws Exception {
		return true;
	}

	public boolean beforeCreateReport(Pair<String, String> settings) throws Exception {
		return true;
	}

	public void onCreate(Workbook wb, File savedFile) throws Exception {
	}

	public void afterCreateReport(ErpSettings settings) throws Exception {
	}

	public void afterCreateReport(Pair<String, String> settings) throws Exception {
	}

	public void afterPrint() throws Exception {
	}

	public boolean beforeBasicProcess(Workbook wb, ErpSettings settings) throws Exception {
		return true;
	}

	public void afterBasicProcess(Workbook wb, ErpSettings settings) throws Exception {
	}

	public boolean beforeMainProcess(Workbook wb, ErpSettings settings) throws Exception {
		return true;
	}

	public void afterMainProcess(Workbook wb, ErpSettings settings) throws Exception {
	}

	public boolean beforeLastProcess(Workbook wb, ErpSettings settings) throws Exception {
		return true;
	}

	public void afterLastProcess(Workbook wb, ErpSettings settings) throws Exception {
	}

	public boolean beforeBasicProcessSheet(Workbook wb, ErpSettings settings, Sheet sheet, ErpSheet sheetStt)
			throws Exception {
		return true;
	}

	public void afterBasicProcessSheet(Workbook wb, ErpSettings settings, Sheet sheet, ErpSheet sheetStt)
			throws Exception {
	}

	public boolean beforeMainProcessSheet(Workbook wb, ErpSettings settings, Sheet sheet, ErpSheet sheetStt)
			throws Exception {
		this.poiLib.getCell(sheet, 0, 0).setCellValue("　");
		return true;
	}

	public void afterMainProcessSheet(Workbook wb, ErpSettings settings, Sheet sheet, ErpSheet sheetStt)
			throws Exception {
		sheet.removeRow(sheet.getRow(sheet.getLastRowNum()));
	}

	public boolean beforeLastProcessSheet(Workbook wb, ErpSettings settings, Sheet sheet, ErpSheet sheetStt)
			throws Exception {
		return true;
	}

	public void afterLastProcessSheet(Workbook wb, ErpSettings settings, Sheet sheet, ErpSheet sheetStt)
			throws Exception {
	}

	public boolean beforeLayoutProcess(ErpCopyStates states) throws Exception {
		return true;
	}

	public void afterLayoutProcess(ErpCopyStates states) throws Exception {
	}

	@SneakyThrows
	public List<File> print(P params, D data, ErpSettings... customSettings) {
		val debugStt = this.isDebugMode();
		this.context = params.getContext();
		this.reportParams = params;
		this.reportData = data;

		if (SysUtils.isEmpty(customSettings)) {
			val filepath = this.getSettingsFile();
			if (Objects.isNull(filepath)) {
				return Collections.emptyList();
			}
			val fileErp = new File(filepath);
			if (Objects.isNull(this.reportSettings) || fileErp.lastModified() > this.lastModified) {
				this.lastModified = fileErp.lastModified();
				this.reportSettings = ErpReader.read(fileErp);
			}
		} else {
			this.reportSettings = Arrays.asList(customSettings);
		}

		if (this.reportSettings.isEmpty()) {
			return Collections.emptyList();
		}
		ErpChecker.checkErpData(this, this.reportSettings);

		val files = new ArrayList<File>();
		if (this.beforePrint()) {
			log.info(PRINT_START, logClassName(this), logClassName(this.reportParams), logClassName(this.reportData));
			for (val stt : this.reportSettings) {
				if (this.beforeCreateReport(stt)) {
					File file;
					if (Objects.nonNull(debugStt) && !StringUtils.isEmpty(debugStt.getTemplatePath())) {
						file = this.loadDebugTemplate(debugStt.getTemplatePath(), stt.getName());
					} else {
						file = this.loadTemplate(stt.getName(), stt.getId());
					}
					try (val wb = this.poiLib.importExcelWorkbook(file)) {
						if (new MethodFounder(this.getClass()) {
							{
								setMethodName("onCreate");
								setParamTypes(Workbook.class, File.class);
								setFindDeclared(true);
							}
						}.has()) {
							this.onCreate(wb, file);
						} else {
							this.createReport(wb, stt);
						}
						this.poiLib.saveExcelWorkbook(wb, file);
						if (!StringUtils.isEmpty(stt.getRename())) {
							file.renameTo(new File(file.getParent(),
									String.valueOf(SysUtils.getScriptValue(stt.getRename(), this))));
						}
						files.add(file);
					}
					this.afterCreateReport(stt);
				}
			}
			this.afterPrint();
			log.info(PRINT_END, logClassName(this), logClassName(this.reportParams), logClassName(this.reportData));
		} else {
			log.info(PRINT_INVALID, logClassName(this), logClassName(this.reportParams), logClassName(this.reportData));
		}
		return files;
	}

	@SuppressWarnings("unchecked")
	public List<File> printJava(P params, D data, Pair<String, String>... reportIds) throws Exception {
		val debugStt = this.isDebugMode();
		this.context = params.getContext();
		this.reportParams = params;
		this.reportData = data;
		val files = new ArrayList<File>();
		if (this.beforePrint()) {
			log.info(PRINT_START, logClassName(this), logClassName(this.reportParams), logClassName(this.reportData));
			for (val id : reportIds) {
				if (this.beforeCreateReport(id)) {
					File file;
					if (Objects.nonNull(debugStt) && !StringUtils.isEmpty(debugStt.getTemplatePath())) {
						file = this.loadDebugTemplate(debugStt.getTemplatePath(), id.getRight());
					} else {
						file = this.loadTemplate(id.getRight(), id.getLeft());
					}
					try (val wb = this.poiLib.importExcelWorkbook(file)) {
						this.onCreate(wb, file);
						this.poiLib.saveExcelWorkbook(wb, file);
						files.add(file);
					}
					this.afterCreateReport(id);
				}
			}
			this.afterPrint();
			log.info(PRINT_END, logClassName(this), logClassName(this.reportParams), logClassName(this.reportData));
		} else {
			log.info(PRINT_INVALID, logClassName(this), logClassName(this.reportParams), logClassName(this.reportData));
		}
		return files;
	}

	@SneakyThrows
	public IchijiFileId export(List<File> files) {
		if (files.isEmpty()) {
			log.info(EXPORT_EMPTY);
			return null;
		}
		val debugStt = this.isDebugMode();
		File file;
		if (files.size() > 1) {
			file = this.createZip(files,
					StringUtils.isEmpty(this.getZipName())
							? Files.getNameWithoutExtension(files.get(0).getPath())
							: this.getZipName());
		} else {
			file = files.get(0);
		}
		val id = this.fileLib.upload(this.context.getSessionInfo().getSessionId(), file);
		if (Objects.isNull(debugStt)) {
			FileUtils.deleteDirectory(file.getParentFile());
			for (val f : files) {
				FileUtils.deleteDirectory(f.getParentFile());
			}
		}
		log.info(EXPORT_SUCCESS, files.size(), Files.getNameWithoutExtension(file.getPath()));
		return id;
	}

	@SneakyThrows
	public File createZip(List<File> listFiles, String fileName) {
		val files = new HashMap<String, File>();
		for (val file : listFiles) {
			files.put(file.getName(), file);
		}
		return this.zipLib.createZip(files, fileName + ".zip");
	}

	public File loadTemplate(String reportName, String reportID) {
		val chohyoFileId = new ChohyoFileId();
		chohyoFileId.set帳票テンプレート名称(reportName);
		chohyoFileId.set帳票ID(reportID);
		val file = this.fileLib.chohyoFileDownload(chohyoFileId);
		val renameFile = new File(file.getParent(), reportName + ".xlsx");
		if (!renameFile.exists()) {
			file.renameTo(renameFile);
		}
		return renameFile;
	}

	@SneakyThrows
	private File loadDebugTemplate(String templatePath, String rename) {
		val oriFile = new File(templatePath);
		val tempPath = this.g9CommonConfig.getTempDir() + this.idGeneratorLib.generateUUID() + File.separator;
		val newDir = new File(tempPath);
		if (!newDir.exists()) {
			newDir.mkdir();
		}
		val tempFile = new File(tempPath, rename + ".xlsx");
		Files.copy(oriFile, tempFile);
		return tempFile;
	}

	private String logClassName(Object obj) {
		try {
			return obj.getClass().getSimpleName();
		} catch (Exception e) {
			return null;
		}
	}

	@SneakyThrows
	protected void createReport(Workbook wb, ErpSettings settings) {
		Integer counter = 0;
		this.erpNative.setupNative(this, settings);
		if (this.beforeBasicProcess(wb, settings)) {
			for (val sheetStt : settings.getSheets()) {
				val sheet = wb.getSheet(sheetStt.getSheetName());
				if (this.beforeBasicProcessSheet(wb, settings, sheet, sheetStt)) {
					this.erpNative.propsProcess(wb, sheet, sheetStt.getProps());
					this.erpNative.refsProcess(wb, sheet, sheetStt.getRefs());
					this.afterBasicProcessSheet(wb, settings, sheet, sheetStt);
				}
			}
			this.afterBasicProcess(wb, settings);
		}
		if (this.beforeMainProcess(wb, settings)) {
			for (val sheetStt : settings.getSheets()) {
				if (Objects.nonNull(sheetStt) && Objects.nonNull(sheetStt.getLayoutSettings())
						&& !SysUtils.isEmpty(Objects.nonNull(sheetStt.getLayoutSettings().getLoopBody()))) {
					val sheet = wb.cloneSheet(wb.getSheetIndex(sheetStt.getSheetName()));
					wb.setSheetName(wb.getSheetIndex(sheet), String.format("%s%d", sheetStt.getSheetName(), counter++));
					if (this.beforeMainProcessSheet(wb, settings, sheet, sheetStt)) {
						this.erpNative.layoutProcess(wb, sheet, sheetStt);
						this.afterMainProcessSheet(wb, settings, sheet, sheetStt);
						wb.setSheetName(wb.getSheetIndex(sheet), String.valueOf(SysUtils.getScriptValue(sheetStt.getRename(), this)));
					} else {
						wb.removeSheetAt(wb.getSheetIndex(sheet));
					}
				}
			}
			this.afterMainProcess(wb, settings);
		}
		if (this.beforeLastProcess(wb, settings)) {
			for (val sheetStt : settings.getSheets()) {
				val sheet = wb.getSheet(sheetStt.getSheetName());
				if (this.beforeLastProcessSheet(wb, settings, sheet, sheetStt)) {
					this.erpNative.pageSetup(wb, sheet, sheetStt.getPageSetup());
					this.erpNative.lastProcess(wb, sheet, sheetStt);
					this.afterLastProcessSheet(wb, settings, sheet, sheetStt);
				}
			}
			this.afterLastProcess(wb, settings);
		}
	}
}
