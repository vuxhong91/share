package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho;

public class TestFieldConditionsException extends Exception {
	@Override
	public String getMessage() {
		return "value > 100";
	}
}
