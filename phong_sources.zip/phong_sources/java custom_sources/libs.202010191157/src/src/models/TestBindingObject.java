package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.models;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.BindingObject;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.AutoCallable;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.annos.AutoCallable.Caller;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Component
@Scope("prototype")
@Data
@EqualsAndHashCode(callSuper=false)
public class TestBindingObject extends BindingObject {
	private String a;
	private String b;

	public void changeA() {
		a = "xxx";
	}

	// Be hooked by setB
	@AutoCallable(caller=Caller.BEFORE, method="setB")
	private Boolean onSetBBefore1(String newB) {
		System.out.println("TestBindingObject: set b before");
		return true;
	}
	@AutoCallable(caller=Caller.BEFORE, method="setB")
	private Boolean onSetBBefore2(String newB) {
		return false; // false -> stop method
	}

	// Be hooked by setB
	@AutoCallable(caller=Caller.AFTER, method="setB")
	private void onSetBAfter() {
		System.out.println("TestBindingObject: set b after");
	}
}
