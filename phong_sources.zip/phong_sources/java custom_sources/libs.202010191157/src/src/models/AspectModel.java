package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.models;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.AspectTestingAnnotation;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseParams;
import lombok.Getter;
import lombok.Setter;
import lombok.SneakyThrows;

@Getter
@Setter
@Component
@Scope("prototype")
public class AspectModel extends BaseParams {
	private String a;
	private String b;

	@AspectTestingAnnotation(key=true)
	public void testAnno() {}
	@AspectTestingAnnotation(key=false)
	public void testAnno2() {}

	@SneakyThrows
	public void error() {
		throw new Exception();
	}
}
