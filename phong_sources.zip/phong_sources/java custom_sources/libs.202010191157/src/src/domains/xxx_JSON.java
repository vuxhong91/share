package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.domains;

import org.springframework.stereotype.Component;

@Component
public class HyoshoDaichoPrint_JSON extends HyoshoDaichoPrint2 {
	@Override
	public String getSettingsFile() throws Exception {
		return "./src/main/resources/reports/G1HYOSHO_R0010L.json";
	}
}
