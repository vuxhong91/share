package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.domains;

import java.util.Date;

import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.models.HyoshoDaichoYoInsatsuParams;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.ErpPrinter;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.annos.ErpCopyCondition;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.annos.ErpPosDefiner;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.annos.ErpWriterCondition;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpDebugSettings;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpWriter;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpWriterAction;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.states.ErpCopyStates;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.states.ErpDataSetterStates;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseModel;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.utils.DateUtils;

@Primary
@Component
public class HyoshoDaichoPrint2 extends ErpPrinter<HyoshoDaichoYoInsatsuParams, BaseModel> {
	@Override
	public String getSettingsFile() throws Exception {
		return "./src/main/resources/reports/G1HYOSHO_R0010L.erp";
	}

	@Override
	public ErpDebugSettings isDebugMode() throws Exception {
		return new ErpDebugSettings("./src/main/resources/reports/G1HYOSHO_R0010L.xlsx");
	}

	@ErpCopyCondition
	private Boolean bodyCond(ErpCopyStates states) {
		return states.getPageIndex() <= Math.max(this.getReportParams().get表彰台帳用リスト().size() - 1, 0) / 20;
	}

	@ErpWriterCondition
	private Boolean bodyWriterCond(ErpWriter writer, ErpCopyStates states, ErpDataSetterStates dsStates) {
		return dsStates.getSetterTotalIndex() < this.getReportParams().get表彰台帳用リスト().size();
	}

	@ErpPosDefiner
	private CellRangeAddress bodyPosDef(ErpWriter writer, ErpWriterAction setter, ErpCopyStates states, ErpDataSetterStates dsStates) {
		if (this.bodyWriterCond(writer, states, dsStates) && dsStates.getSetterCurrentIndex() < 20) {
			return dsStates.getSetterCurrentIndex().equals(0) ? dsStates.getCurrentPos() : dsStates.moveCurrentPos(2, 0);
		}
		return null;
	}

	@SuppressWarnings("unused")
	private Date convertDate(String value) {
		return DateUtils.convertDate(value);
	}
}
