package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.domains;

import java.util.ArrayList;
import java.util.Arrays;

import org.springframework.stereotype.Component;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpDataSetter;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpFirstHeader;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpLayout;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpLoopBody;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpPageSetup;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpSettings;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpSheet;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpWriter;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpWriterAction;
import lombok.val;

@Component
public class HyoshoDaichoPrint_JavaConfigs extends HyoshoDaichoPrint2 {
	public ErpSettings[] getTestSettings() {
		val settings = new ArrayList<ErpSettings>();

		val report1 = new ErpSettings();
		report1.setId("G1HYOSHO_R0010L").setName("表彰台帳").setSheets(new ArrayList<>());
		settings.add(report1);

		val sheet1 = new ErpSheet();
		sheet1.setSheetName("表彰台帳");
		val pageSetup11 = new ErpPageSetup();
		pageSetup11.setRepeatRows("$1:$6")
				.setFitWidth(Short.valueOf((short) 1))
				.setFitHeight(Short.valueOf((short) 0))
				.setLandscape(true);
		sheet1.setPageSetup(pageSetup11);

		val sheet2 = new ErpSheet();
		sheet2.setSheetName("_MAIN");
		sheet2.setRename("表彰台帳");
		sheet2.setRemove(true);
		val layout21 = new ErpLayout();
		val firstHeader21 = new ErpFirstHeader();
		firstHeader21.setSheetName("_PAGE_HEADER");
		layout21.setFirstHeader(new ArrayList<>()).getFirstHeader().add(firstHeader21);

		val loopBody21 = new ErpLoopBody();
		loopBody21.setSheetName("_PAGE_BODY").setCondition("bodyCond").setWriterName("mainWriter");

		layout21.setLoopBody(new ArrayList<>()).getLoopBody().add(loopBody21);

		sheet2.setLayoutSettings(layout21);
		ErpWriter writer21 = new ErpWriter();
		writer21.setWriterName("mainWriter").setCondition("bodyWriterCond");

		val wAction21 = new ErpWriterAction();
		wAction21.setPos("A1:J1").setPosDef("bodyPosDef").setBinding("#{params.表彰台帳用リスト[#{dsStates.setterTotalIndex}]}");

		val waSet21 = new ErpDataSetter();
		waSet21.setValue("#{事案番号}");
		val waSet22 = new ErpDataSetter();
		waSet22.setValue("#{表彰種別名称}");
		val waSet23 = new ErpDataSetter();
		waSet23.setValue("#{printer.convertDate(#{表彰YMD})}");
		val waSet24 = new ErpDataSetter();
		waSet24.setValue("#{所属名称}");
		val waSet25 = new ErpDataSetter();
		waSet25.setValue("#{係別}");
		val waSet26 = new ErpDataSetter();
		waSet26.setValue("#{階級}");
		val waSet27 = new ErpDataSetter();
		waSet27.setValue("#{氏名}");
		val waSet28 = new ErpDataSetter();
		waSet28.setValue("#{副賞}");
		val waSet281 = new ErpDataSetter();
		waSet281.setOffsetY(1).setValue("#{年齢}");
		waSet28.setSets(new ArrayList<>()).getSets().add(waSet281);
		val waSet29 = new ErpDataSetter();
		waSet29.setValue("#{功労概要}");
		val waSet210 = new ErpDataSetter();
		waSet210.setValue("#{printer.convertDate(#{交付YMD})}");
		wAction21.setSets(new ArrayList<>())
				.getSets().addAll(Arrays.asList(waSet21, waSet22, waSet23, waSet24, waSet25,
						waSet26, waSet27, waSet28, waSet29, waSet210));
		writer21.setActions(new ArrayList<>()).getActions().add(wAction21);
		sheet2.setWriters(new ArrayList<>()).getWriters().add(writer21);

		val sheet3 = new ErpSheet().setSheetName("_PAGE_HEADER").setRemove(true);
		val sheet4 = new ErpSheet().setSheetName("_PAGE_BODY").setRemove(true);

		report1.getSheets().addAll(Arrays.asList(sheet4, sheet3, sheet2, sheet1));
		val array = new ErpSettings[settings.size()];
		return (ErpSettings[]) settings.toArray(array);
	}
}
