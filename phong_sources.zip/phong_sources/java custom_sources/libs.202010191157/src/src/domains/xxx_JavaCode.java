package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.domains;

import java.io.File;
import java.util.List;
import java.util.Objects;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.models.HyoshoDaichoYoInsatsuParams;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.models.HyoshoDaichoYoShutokuGaiyo;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.ErpPrinter;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.printers.models.ErpDebugSettings;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseModel;
import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.utils.StringUtils;
import lombok.val;

@Component
public class HyoshoDaichoPrint_JavaCode extends ErpPrinter<HyoshoDaichoYoInsatsuParams, BaseModel> {
	private static final String SHEET_NAME_MAIN = "表彰台帳";
	protected static final String SHEET_BODY = "_PAGE_BODY";
	protected static final String CELL_START = "〓開始位置〓";

	@Override
	public ErpDebugSettings isDebugMode() throws Exception {
		return new ErpDebugSettings();
	}

	@Override
	public void onCreate(Workbook wb, File savedFile) throws Exception {
		val mainSt = wb.getSheet(SHEET_NAME_MAIN);
		val bodySt = wb.getSheet(SHEET_BODY);
		this.createDataReport(wb, mainSt, bodySt, this.getReportParams().get表彰台帳用リスト());
		wb.removeSheetAt(wb.getSheetIndex(SHEET_BODY));
	}

	private void createDataReport(Workbook wb, Sheet mainSt, Sheet bodySt, List<HyoshoDaichoYoShutokuGaiyo> gaiyoList)
			throws Exception {
		Cell targetCell = this.poiLib.getCell(wb, mainSt, CELL_START);
		int startColIndex = targetCell.getColumnIndex();
		int startRowIndex = targetCell.getRowIndex();
		val pageMaxRowIndex = bodySt.getLastRowNum();
		val pageTotal = gaiyoList.size() / (pageMaxRowIndex / 2 + 1) + 1;
		for (int i = 0; i < pageTotal; ++i) {
			this.poiLib.copySheet(mainSt, bodySt, targetCell.getRowIndex(), 0, false);
		}
		targetCell = this.poiLib.getCell(mainSt, startRowIndex, startColIndex);
		for (val gaiyo : gaiyoList) {
			this.setData(mainSt, targetCell, gaiyo);
			targetCell = this.poiLib.getCell_NextRow(mainSt, targetCell);
		}
	}

	private void setData(Sheet mainSt, Cell cell, HyoshoDaichoYoShutokuGaiyo gaiyo) throws Exception {
		cell = this.poiLib.setCellNumber(mainSt, cell, Integer.valueOf(gaiyo.get事案番号()), true);
		cell = this.poiLib.setCell(mainSt, cell, StringUtils.trim(gaiyo.get表彰種別名称()), true);
		cell = this.poiLib.setCellDate(mainSt, cell, gaiyo.get表彰YMD(), true);
		cell = this.poiLib.setCell(mainSt, cell, StringUtils.trim(gaiyo.get所属名称()), true);
		cell = this.poiLib.setCell(mainSt, cell, StringUtils.trim(gaiyo.get係別()), true);
		cell = this.poiLib.setCell(mainSt, cell, StringUtils.trim(gaiyo.get階級()), true);
		cell = this.poiLib.setCell(mainSt, cell, StringUtils.trim(gaiyo.get氏名()), true);
		cell = this.poiLib.setCell(mainSt, cell, gaiyo.get副賞(), false);
		Cell tempcell = this.poiLib.getCell_NextColumn(mainSt, cell);
		cell = poiLib.getCell_NextRow(mainSt, cell);
		if (Objects.nonNull(gaiyo.get年齢()))
			this.poiLib.setCellNumber(mainSt, cell, gaiyo.get年齢(), true);
		else
			this.poiLib.setCell(mainSt, cell, "", true);
		cell = this.poiLib.setCell(mainSt, tempcell, StringUtils.trim(gaiyo.get功労概要()), true);
		this.poiLib.setCellDate(mainSt, cell, gaiyo.get交付YMD(), false);
	}
}
