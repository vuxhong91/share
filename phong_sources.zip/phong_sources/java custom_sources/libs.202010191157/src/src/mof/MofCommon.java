package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof;

import lombok.experimental.UtilityClass;

@UtilityClass
public class MofCommon {
	public static final String DECLARE_NULL = "-";
	public static final String DEFAULT_CHARSET = "UTF-8";
	public static final String EMPTY = "";
	public static final String CMD_SPLITCHAR = " ";
	public static final String CMD_GROUP = "\"";
	public static final String CMD_SCOPEDEFINE = "\t";
	public static final String CMD_COMMENT = "//";
	public static final String CMD_DEF = ":";
}
