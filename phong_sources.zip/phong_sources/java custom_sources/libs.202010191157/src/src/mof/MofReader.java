package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof;

import java.io.File;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.commons.lang3.tuple.Pair;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.annos.MofClass;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.mof.annos.MofField;
import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.sysutils.SysUtils;
import lombok.SneakyThrows;
import lombok.val;

public class MofReader {
	@SneakyThrows
	public <T> List<T> read(Class<T> clazz, File file) {
		if (file.exists() && file.isFile()) {
			List<String> lines = FileUtils.readLines(file, Charset.forName(MofCommon.DEFAULT_CHARSET));
			val result = new ArrayList<T>();
			val cmds = lines.stream().map(x -> processCmd(x.split(MofCommon.CMD_SPLITCHAR)))
					.collect(Collectors.toList());
			List<Pair<Integer, List<String>>> t;
			Integer k = 0;
			while (Objects.nonNull(t = getCmdLinesOfClass(clazz, cmds, -1, k++)) && !t.isEmpty()) {
				result.add(createObj(clazz, t));
			}
			return result;
		}
		return Collections.emptyList();
	}

	protected Pair<Integer, List<String>> processCmd(String... strs) {
		val cmds = new ArrayList<String>();
		String currentGroup = null;
		for (val s : strs) {
			if (!s.trim().startsWith(MofCommon.CMD_COMMENT)) {
				if (currentGroup == null) {
					if (s.startsWith(MofCommon.CMD_GROUP) && !s.endsWith(MofCommon.CMD_GROUP)) {
						currentGroup = s;
					} else if (s.startsWith(MofCommon.CMD_GROUP) && s.endsWith(MofCommon.CMD_GROUP)) {
						cmds.add(s.substring(1, s.length() - 1));
					} else {
						cmds.add(s);
					}
				} else {
					currentGroup += " " + s;
					if (s.endsWith(MofCommon.CMD_GROUP)) {
						currentGroup = currentGroup.substring(1, currentGroup.length() - 1);
						cmds.add(currentGroup);
						currentGroup = null;
					}
				}
			}
		}
		Integer scopeLvl = 0;
		if (cmds.size() > 0) {
			for (String first = cmds.get(0); MofCommon.CMD_SCOPEDEFINE
					.equals(String.valueOf(first.charAt(scopeLvl))); scopeLvl++)
				;
			cmds.set(0, cmds.get(0).replace(MofCommon.CMD_SCOPEDEFINE, MofCommon.EMPTY));
		}
		return Pair.of(scopeLvl, cmds);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@SneakyThrows
	protected <T> T createObj(Class<T> resultClass, List<Pair<Integer, List<String>>> cmds) {
		if (SysUtils.isEmpty(cmds))
			return null;
		T result = resultClass.newInstance();
		val classDef = resultClass.getAnnotation(MofClass.class);
		if (Objects.isNull(classDef)) {
			return null;
		}
		val scopeLvl = cmds.get(0).getLeft();
		val fields = FieldUtils.getFieldsWithAnnotation(resultClass, MofField.class);
		for (val f : fields) {
			val anno = f.getAnnotation(MofField.class);
			if (Objects.nonNull(anno)) {
				if (SysUtils.isAvailableBasicType(f.getType())) {
					FieldUtils.writeField(f, result, this.getBasicValue(f.getType(), classDef, cmds, anno), true);
				} else if (List.class.isAssignableFrom(f.getType())) {
					List list = (List)FieldUtils.readField(f, result, true);
					if (Objects.isNull(list)) {
						list = new ArrayList<>();
						FieldUtils.writeField(f, result, list, true);
					}
					val genericTypes = (Type[]) SysUtils.getValue("actualTypeArguments", f.getGenericType());
					if (Objects.nonNull(genericTypes) && genericTypes.length > 0) {
						val genericType = (Class) genericTypes[0];
						Integer k = 0;
						List t;
						while (!SysUtils.isEmpty(t = this.getCmdLinesOfClass(genericType, cmds.subList(1, cmds.size()), scopeLvl + 1, k++))) {
							list.add(this.createObj(genericType, t));
						}
					}
				} else if (Object.class.isAssignableFrom(f.getType())) {
					FieldUtils.writeField(f, result, this.createObj(f.getType(), this.getCmdLinesOfClass(f.getType(), cmds.subList(1, cmds.size()), scopeLvl + 1, 0)), true);
				}
			}
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	protected <T> T getBasicValue(Class<T> resultClass, MofClass classDef, List<Pair<Integer, List<String>>> cmds,
			MofField annoInfo) {
		if (cmds.isEmpty()) {
			return null;
		}
		val scopeLvl = cmds.get(0).getLeft();
		for (int i = 0; i < cmds.size(); ++i) {
			val line = cmds.get(i);
			if (i <= 0 || line.getLeft() == scopeLvl + 1) {
				val contents = line.getRight();
				if (i == 0 && this.compareCmd(contents.get(0), classDef.name()) && annoInfo.index() > 0
						&& contents.size() > annoInfo.index()) {
					return SysUtils.VALUE_CONVERTER.convert(this.getValue(contents, annoInfo.index()), resultClass);
				}
				if (i > 0 && !StringUtils.isEmpty(annoInfo.name()) && contents.size() > 1
						&& this.compareCmd((String) contents.get(0), annoInfo.name())) {
					return SysUtils.VALUE_CONVERTER.convert(this.getValue(contents, 1), resultClass);
				}
				if (i > 0 && !StringUtils.isEmpty(annoInfo.name()) && contents.size() == 1
						&& this.compareCmd((String) contents.get(0), annoInfo.name())) {
					return (T) this.getDefaultValue(resultClass);
				}
			}
		}
		return null;
	}

	protected boolean compareCmd(String a, String b) {
		return Objects.equals(a, b + MofCommon.CMD_DEF) || Objects.equals(a, b);
	}

	protected <T> List<Pair<Integer, List<String>>> getCmdLinesOfClass(Class<T> clazz,
			List<Pair<Integer, List<String>>> cmds, Integer compareScopeLvl, Integer skip) {
		val classDef = clazz.getAnnotation(MofClass.class);
		return Objects.isNull(classDef) ? Collections.emptyList()
				: this.getCmdLinesOfClass(classDef, cmds, compareScopeLvl, skip);
	}

	protected List<Pair<Integer, List<String>>> getCmdLinesOfClass(MofClass classDef,
			List<Pair<Integer, List<String>>> cmds, Integer compareScopeLvl, Integer skip) {
		return this.getCmdLinesOfClass(classDef.name(), cmds, compareScopeLvl, skip);
	}

	protected List<Pair<Integer, List<String>>> getCmdLinesOfClass(String classDef,
			List<Pair<Integer, List<String>>> cmds, Integer compareScopeLvl, Integer skip) {
		if (Objects.isNull(cmds) || cmds.isEmpty())
			return Collections.emptyList();
		classDef += MofCommon.CMD_DEF;
		Integer startLine = null;
		Integer scopeLvl = null;
		Integer i = 0;
		for (val c : cmds) {
			if (Objects.isNull(startLine) && classDef.equals(c.getRight().get(0))
					&& (compareScopeLvl < 0 || c.getLeft().equals(compareScopeLvl)) && skip-- <= 0) {
				startLine = i;
				scopeLvl = c.getLeft();
			} else if (startLine != null && c.getLeft() <= scopeLvl) {
				return cmds.subList(startLine, i);
			}
			i++;
		}
		if (startLine != null) {
			return cmds.subList(startLine, i);
		}
		return Collections.emptyList();
	}

	protected Object getDefaultValue(Class<?> clazz) {
		return Boolean.class.equals(clazz) ? Boolean.TRUE : null;
	}

	protected String getValue(List<String> lineCmds, int index) {
		if (index >= lineCmds.size()) {
			return null;
		}
		val result = lineCmds.get(index);
		return MofCommon.DECLARE_NULL.equals(result) ? null : result;
	}
}
