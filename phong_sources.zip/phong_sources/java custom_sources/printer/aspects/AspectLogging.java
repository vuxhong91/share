package jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.aspects;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.AspectTestingAnnotation;

@Aspect
@Component
public class AspectLogging {
//	@Pointcut("within(jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.models.*)")
	@Pointcut("execution(public * jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.models.*.*(..))")
	private void configModelLogging() {}

	@Before("configModelLogging()")
	private void beforeAdvice() {
		System.out.println("before");
	}

	@Before("execution(public * jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.models.*.set*(..)) && args(param,..)")
	private void beforeSetterAdvice(Object param) {
		System.out.println("before setter: " + String.valueOf(param));
	}

	@After("configModelLogging()")
	private void afterAdvice() {
		System.out.println("after");
	}

	@AfterReturning(pointcut="execution(public * jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.models.*.get*(..))", returning="res")
	private void afterResAdvice(Object res) {
		System.out.println("after returning: " + String.valueOf(res));
	}

	@AfterThrowing(pointcut="execution(public * jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.models.*.*(..))", throwing="ex")
	private void afterThrAdvice(Exception ex) throws Exception {
		System.out.println("after throwing: " + ex.getMessage());
	}

//	// 「@Around = @Before + After」です。
//	@Around("configModelLogging()")
//	private void aroundAdvice() {
//		System.out.println("around");
//	}

	@Before("@annotation(anno)")
	private void aroundAnnoAdvice(AspectTestingAnnotation anno) {
		System.out.println("before annotated: " + anno.key());
	}
}
