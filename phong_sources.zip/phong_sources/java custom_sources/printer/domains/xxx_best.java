@Primary
@Component
public class HyoshoDaichoPrint2 extends ErpPrinter<HyoshoDaichoYoInsatsuParams, BaseModel> {
	@Override
	public String getSettingsFile() throws Exception {
		return "xxx.erp";
	}

	@Override
	public ErpDebugSettings isDebugMode() throws Exception {
		return new ErpDebugSettings("xxx.xlsx");
	}

	@ErpCopyCondition
	private Boolean bodyCond(ErpCopyStates states) {
		return states.getPageIndex() <= Math.max(this.getReportParams().get表彰台帳用リスト().size() - 1, 0) / 20;
	}

	@ErpWriterCondition
	private Boolean bodyWriterCond(ErpWriter writer, ErpCopyStates states, ErpDataSetterStates dsStates) {
		return dsStates.getSetterTotalIndex() < this.getReportParams().get表彰台帳用リスト().size();
	}

	@ErpPosDefiner
	private CellRangeAddress bodyPosDef(ErpWriter writer, ErpWriterAction setter, ErpCopyStates states, ErpDataSetterStates dsStates) {
		if (this.bodyWriterCond(writer, states, dsStates) && dsStates.getSetterCurrentIndex() < 20) {
			return dsStates.getSetterCurrentIndex().equals(0) ? dsStates.getCurrentPos() : dsStates.moveCurrentPos(2, 0);
		}
		return null;
	}

	@SuppressWarnings("unused")
	private Date convertDate(String value) {
		return DateUtils.convertDate(value);
	}
}
