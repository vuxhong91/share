@Component
public class HyoshoDaichoPrint_JSON extends HyoshoDaichoPrint2 {
	@Override
	public String getSettingsFile() throws Exception {
		return "xxx.json";
	}
}
