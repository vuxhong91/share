package autocode.processors.genfile.gennodes.analyzers;

import java.util.ArrayList;
import java.util.List;

import autocode.utils.RegexUtils;
import lombok.Data;
import lombok.val;

@Data
public class Option {
	private String key;
	private String value1;
	private String value2;
	private String value3;
	private String value4;
	private OptionType type;

	public static Option addOption(String k, String v1) {
		val op = new Option();
		op.setKey(k);
		op.setValue1(v1);
		op.setType(OptionType.Option);
		return op;
	}

	public static Option addProperty(String v1, String v2, String v3) {
		val op = new Option();
		op.setValue1(v1);
		op.setValue2(v2);
		op.setValue3(v3);
		op.setType(OptionType.AddingProperty);
		return op;
	}

	public static Option addMapperParam(String v1, String v2) {
		val op = new Option();
		op.setValue1(v1);
		op.setValue2(v2);
		op.setType(OptionType.MapperParam);
		return op;
	}

	public static List<Option> addParamsInput(String v1, String v2, String v3) {
		val rs = new ArrayList<Option>();
		RegexUtils.find(v3, "(\\S+)\\s*:\\s*(%name)", 0, m -> {
			val op = new Option();
			op.setValue1(v1);
			op.setValue2(v2);
			op.setValue3(m.group(1));
			op.setValue4(m.group(2));
			op.setType(OptionType.ParamsInput);
			rs.add(op);
		});
		return rs;
	}
}