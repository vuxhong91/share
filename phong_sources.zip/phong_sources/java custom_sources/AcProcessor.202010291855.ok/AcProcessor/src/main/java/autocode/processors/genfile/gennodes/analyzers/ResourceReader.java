package autocode.processors.genfile.gennodes.analyzers;

/**
 * Autocode
 * 分析クラス
 */
public abstract class ResourceReader {
	public abstract String type();
}
