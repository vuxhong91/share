package autocode.processors.genfile.gennodes;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;

import autocode.annotations.AutoGenerate;
import autocode.managers.SourceManager;
import autocode.processors.genfile.AcGenFileByResourceProcessor;
import autocode.processors.genfile.gennodes.analyzers.Option;
import autocode.processors.genfile.gennodes.analyzers.OptionType;
import autocode.processors.genfile.gennodes.analyzers.Property;
import autocode.processors.genfile.gennodes.analyzers.ResourcePreparer;
import autocode.processors.genfile.gennodes.analyzers.SqlAnalyzedResult;
import autocode.processors.genfile.gennodes.analyzers.SqlProcedureReader;
import autocode.processors.genfile.gennodes.analyzers.SqlRecordReader;
import autocode.processors.genfile.gennodes.analyzers.SqlTypeReader;
import autocode.processors.genfile.gennodes.analyzers.SqlViewReader;
import autocode.utils.PathUtils;
import autocode.utils.RegexUtils;
import autocode.utils.StringUtils;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.val;

/**
 * Autocode
 * モデル発生処理
 */
@SupportedAnnotationTypes({
		"autocode.annotations.AutoGenerate",
})
@SupportedSourceVersion(SourceVersion.RELEASE_8)
public class AutoGenerateProcessor extends AcGenFileByResourceProcessor<AutoGenerate> {

	/**
	 * ソース設定
	 */
	public static final String KW_OPTION_IGNORE_FILE = "IGNORE_FILE"; // #{IGNORE_FILE}

	/**
	 * Analyzers（分析クラス）
	 */
	protected ResourcePreparer preparer = new ResourcePreparer();
	protected SqlRecordReader recordReader = new SqlRecordReader();
	protected SqlTypeReader typeReader = new SqlTypeReader();
	protected SqlProcedureReader procedureReader = new SqlProcedureReader();
	protected SqlViewReader viewReader = new SqlViewReader();

	/**
	 * Results（バックアップ結果）
	 */
	protected List<SqlAnalyzedResult> recordResults = new ArrayList<>();
	protected List<SqlAnalyzedResult> typeResults = new ArrayList<>();
	protected List<SqlAnalyzedResult> procedureResults = new ArrayList<>();
	protected List<SqlAnalyzedResult> viewResults = new ArrayList<>();

	/**
	 * AnalyzedSource
	 */
	@Getter protected Map<String, String> modelSource = new HashMap<>();

	/**
	 * 資料フォルダー取得
	 */
	@Override
	protected String[] getSearchingPaths() {
		val anno = (AutoGenerate)processingAnnotations.get(0);
		return anno.paths();
	}

	/**
	 * 資料ファイル分析
	 */
	@Override
	protected void processFile(File file) {
		if (file.getName().toLowerCase().endsWith(".sql")) {
			preparer.read(file);
			val options = preparer.getOptions(0, 99999, OptionType.Option, null, null);
			if (options.stream().noneMatch(x -> x.getKey().equalsIgnoreCase(KW_OPTION_IGNORE_FILE))) {
				if (recordReader.run(preparer)) {
					recordResults.addAll(recordReader.getResults());
				}
				if (typeReader.run(preparer)) {
					typeResults.addAll(typeReader.getResults());
				}
				if (procedureReader.run(preparer)) {
					procedureResults.addAll(procedureReader.getResults());
				}
				if (viewReader.run(preparer)) {
					viewResults.addAll(viewReader.getResults());
				}
			}
		}
	}

	/**
	 * ファイル発生
	 */
	@Override
	protected void afterAction() {
		//create models
		writeModel();

		//create mappers
		if (((AutoGenerate)getProcessingAnnotation()).genMapper()) {
			writeMapper();
		}
	}

	/**
	 * モデル
	 */
	public void writeModel() {
		SourceManager.clear();
		val tmp = new ArrayList<SqlAnalyzedResult>();
		tmp.addAll(recordResults);
		tmp.addAll(procedureResults);
		tmp.addAll(viewResults);
		for (val r : tmp) {
			if (!r.isIgnore()) {
				for (val p : r.getProperties()) {
					genFields(r, p);
				}
				for (val p : r.getAddingProperties()) {
					genFields(r, p);
				}
				genModelGroup(r);
			}
		}
		writeModelFile();
		for (val r : typeResults) {
			if (!r.isIgnore()) {
				genTypeTableOf(r);
			}
		}
	}

	public void genFields(SqlAnalyzedResult r, Property p) {
		val fieldName = p.getName();
		if (!RegexUtils.has(StringUtils.nvl(modelSource.get(r.getModelRename()), ""),
				"private\\s+(%name)((\\[\\])|(<([#jw]+)>))*\\s+" + fieldName + ";", Pattern.UNICODE_CHARACTER_CLASS)) {
			val f = String.format("private %s %s;", p.getType(), fieldName);
			val ff = String.format("	%s%s%s%n",
					StringUtils.nvl2(p.getPrefix(), "", "%s "),
					StringUtils.nvl2(p.getAnno(), "", "%s "),
					f);
			SourceManager.addSource(r.getSqlElementName()+r.getFile().getPath(), ff);
		}
	}

	@SneakyThrows
	public void genModelGroup(SqlAnalyzedResult r) {
		String src = StringUtils.nvl(SourceManager.loadSource(r.getSqlElementName()+r.getFile().getPath()), "");
		src = StringUtils.nvl(modelSource.get(r.getModelRename()), "") + String.format("	//From: %s【%s】（行%d）\r\n", r.getFile().getPath(), r.getSqlElementName(), r.getPos()) + src;
		modelSource.put(r.getModelRename(), src);
	}

	private void writeModelFile() {
		val packageName = PathUtils.getPackageParent(getProcessingPackage().getQualifiedName().toString()) + ".models";
		for (val entry : modelSource.entrySet()) {
			if (Files.exists(Paths.get(String.format("%ssrc\\main\\java\\%s\\%s.java", getProjectPath(), PathUtils.convertPkg2Path(packageName), entry.getKey()))))
				continue;
			String src =
					"package #{PACKAGE};\r\n" +
					(RegexUtils.has(entry.getValue(), "@ClientField", 0) ?
							"import autocode.annotations.ClientField;\r\n" : "") +
					"@lombok.Data\r\n" +
					"@lombok.EqualsAndHashCode(callSuper=false)\r\n" +
					"public class #{CLASS_NAME} extends jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.BaseModel {\r\n" +
					"#{FIELDS}\r\n" +
					"}";
			src = src.replace("#{PACKAGE}", packageName);
			src = src.replace("#{CLASS_NAME}", entry.getKey());
			src = src.replace("#{FIELDS}", entry.getValue());
			writeSourceFile(packageName, entry.getKey(), src);
		}
	}

	@SneakyThrows
	public void genTypeTableOf(SqlAnalyzedResult r) {
		val packageName = PathUtils.getPackageParent(getProcessingPackage().getQualifiedName().toString()) + ".models";
		if (Files.exists(Paths.get(String.format("%ssrc\\main\\java\\%s\\%s.java", getProjectPath(), PathUtils.convertPkg2Path(packageName), r.getModelRename()))))
			return;
		val baseModel = recordResults.stream().filter(x -> x.getSqlElementName().equalsIgnoreCase(r.getBaseOf())).findFirst();
		if (!baseModel.isPresent())
			return;
		val builder = new StringBuilder();
		for (val p : r.getAddingProperties()) {
			if (!RegexUtils.has(StringUtils.nvl(modelSource.get(baseModel.get().getModelRename()), ""),
					"private\\s+(%name)((\\[\\])|(<([#jw]+)>))*\\s+" + p.getName() + ";", Pattern.UNICODE_CHARACTER_CLASS)) {
				val f = String.format("private %s %s;", p.getType(), p.getName());
				val ff = String.format("	%s%s%s%n",
						StringUtils.nvl2(p.getPrefix(), "", "%s "),
						StringUtils.nvl2(p.getAnno(), "", "%s "),
						f);
				builder.append(ff);
			}
		}
		String src =
				"package #{PACKAGE};\r\n" +
				(RegexUtils.has(builder.toString(), "@ClientField", 0) ?
						"import autocode.annotations.ClientField;\r\n" : "") +
				"@lombok.Data\r\n" +
				"@lombok.EqualsAndHashCode(callSuper=false)\r\n" +
				"public class #{CLASS_NAME} extends #{BASEOF} {\r\n" +
				"#{NOTE}\r\n" +
				"#{FIELDS}\r\n" +
				"}";
		src = src.replace("#{PACKAGE}", packageName);
		src = src.replace("#{CLASS_NAME}", r.getModelRename());
		src = src.replace("#{BASEOF}", String.format("%s.%s", packageName, baseModel.get().getModelRename()));
		src = src.replace("#{NOTE}", String.format("	//From: %s【%s】（行%d）\r\n", r.getFile().getPath(), r.getSqlElementName(), r.getPos()));
		src = src.replace("#{FIELDS}", builder.toString());
		writeSourceFile(packageName, r.getModelRename(), src);
	}

	/**
	 * マッパー
	 */
	private void writeMapper() {
		SourceManager.clear();
		for (val r : viewResults) {
			if (!r.isIgnore()) {
				mapperSelectAll(r, null);
				mapperCheckExists(r);
			}
		}
		for (val r : procedureResults) {
			if (!r.isIgnore()) {
				if ("FUNCTION".equals(r.getProcedureType()) && "PIPELINED".equals(r.getPipelined())) {
					val resultModel = typeResults.stream().filter(x -> x.getSqlElementName().equalsIgnoreCase(r.getResultSet())).findFirst();
					if (!resultModel.isPresent())
						continue;
					mapperSelectAll(r, resultModel.get());
					mapperCheckExists(r);
				} else if ("PROCEDURE".equals(r.getProcedureType())) {
					mapperExecute(r);
				}
			}
		}
		writeMapperFile();
	}

	private void mapperSelectAll(SqlAnalyzedResult r, SqlAnalyzedResult rtn) {
		val modelPack = PathUtils.getPackageParent(getProcessingPackage().getQualifiedName().toString()) + ".models";
		val fileName = String.format("%sMapper", r.getModelRename());
		String src =
				"	@Select(\"select * from #{PACKAGE}#{NAME}#{PARAMS_INPUT}\")\r\n" +
				"	List<#{RESULT}> #{NAME}(#{PARAMS});\r\n";
		src = src.replace("#{PACKAGE}", StringUtils.nvl2(r.getProcedureName(), "", "%s."));
		src = src.replace("#{NAME}", "selectAll" + StringUtils.nvl(r.getMapperRename(), r.getSqlElementName()));
		src = src.replace("#{RESULT}", String.format("%s.%s", modelPack, StringUtils.isEmpty(r.getProcedureType()) ? r.getModelRename() : rtn.getModelRename()));
		if (StringUtils.isEmpty(r.getProcedureType())) {
			src = src.replace("#{PARAMS_INPUT}", "");
			src = src.replace("#{PARAMS}", "");
		} else {
			src = src.replace("#{PARAMS_INPUT}", writeParamsInputs(r));
			src = src.replace("#{PARAMS}", writeMapperParams(r));
		}
		SourceManager.addSource(fileName, src);
	}

	private void mapperCheckExists(SqlAnalyzedResult r) {
		val fileName = String.format("%sMapper", r.getModelRename());
		String src =
				"	@Select(\"select 1 from #{PACKAGE}#{NAME}#{PARAMS_INPUT} where rownum = 1\")\r\n" +
				"	String #{NAME}(#{PARAMS});\r\n";
		src = src.replace("#{PACKAGE}", StringUtils.nvl2(r.getProcedureName(), "", "%s."));
		src = src.replace("#{NAME}", "checkExists" + StringUtils.nvl(r.getMapperRename(), r.getSqlElementName()));
		if (StringUtils.isEmpty(r.getProcedureType())) {
			src = src.replace("#{PARAMS_INPUT}", "");
			src = src.replace("#{PARAMS}", "");
		} else {
			src = src.replace("#{PARAMS_INPUT}", writeParamsInputs(r));
			src = src.replace("#{PARAMS}", writeMapperParams(r));
		}
		SourceManager.addSource(fileName, src);
	}

	private void mapperExecute(SqlAnalyzedResult r) {
		val fileName = String.format("%sMapper", r.getModelRename());
		String src =
				"	@Select(\"{Call #{PACKAGE}#{NAME}#{PARAMS_INPUT}}\")\r\n" +
				"	@Options(statementType = StatementType.CALLABLE)\r\n" +
				"	void #{NAME}(#{PARAMS});\r\n";
		src = src.replace("#{PACKAGE}", StringUtils.nvl2(r.getProcedureName(), "", "%s."));
		src = src.replace("#{NAME}", "call" + StringUtils.nvl(r.getMapperRename(), r.getSqlElementName()));
		src = src.replace("#{PARAMS_INPUT}", writeParamsInputs(r));
		src = src.replace("#{PARAMS}", writeMapperParams(r));
		SourceManager.addSource(fileName, src);
	}

	private String writeParamsInputs(SqlAnalyzedResult r) {
		return r.getProperties().isEmpty() ? ""
				: String.format("(%s)", String.join(",", r.getProperties().stream().map(
						x -> String.format("#{%s, jdbcType=%s%s}",
								StringUtils.nvl(getParamsInput(r.getParamsInputs(), x.getName()), String.format("params.%s", x.getName())),
								convertJdbcType(x.getType()),
								StringUtils.isEmpty(x.getInout()) || x.getInout().equalsIgnoreCase("IN") ? ""
										: ", mode=" + convertMode(x.getInout())))
						.collect(Collectors.toList())));
	}

	private String getParamsInput(List<Option> paramsInputs, String name) {
		val y = paramsInputs.stream().filter(y -> RegexUtils.matches(name, y.getValue3(), Pattern.CASE_INSENSITIVE)).findFirst();
		if (y.isPresent())
			return String.format("%s.%s", y.get().getValue2(), y.get().getValue4());
		return null;
	}

	private String writeMapperParams(SqlAnalyzedResult r) {
		val modelPack = PathUtils.getPackageParent(getProcessingPackage().getQualifiedName().toString()) + ".models";
		return r.getProperties().isEmpty() ? "" : String.format("@Param(\"params\") %s.%s params", modelPack, r.getModelRename()) +
				StringUtils.nvl2(getMapperParams(r.getMapperParams()), "", ",%s");
	}

	private String getMapperParams(List<Option> mapperParams) {
		if (mapperParams.isEmpty())
			return null;
		return String.join(",", mapperParams.stream().map(
				x -> String.format("@Param(\"%1$s\") %2$s %1$s", x.getValue2(), x.getValue1()))
				.collect(Collectors.toList()));
	}

	private String convertJdbcType(String input) {
		switch (input) {
		case "char":
		case "Char":
		case "String":
			return "VARCHAR";
		case "Integer":
		case "Long":
		case "Double":
		case "Float":
		case "int":
		case "long":
		case "double":
		case "float":
			return "NUMBER";
		default:
			return "VARCHAR";
		}
	}

	private String convertMode(String input) {
		switch (input) {
		case "INOUT":
		case "IN OUT":
			return "INOUT";
		case "OUT":
			return "OUT";
		default:
			return "IN";
		}
	}

	private void writeMapperFile() {
		val packageName = PathUtils.getPackageParent(getProcessingPackage().getQualifiedName().toString()) + ".mappers";
		for (val entry : SourceManager.getCachedSource().entrySet()) {
			if (Files.exists(Paths.get(String.format("%ssrc\\main\\java\\%s\\%s.java", getProjectPath(), PathUtils.convertPkg2Path(packageName), entry.getKey()))))
				continue;
			String src =
					"package #{PACKAGE};\r\n" +
					"import java.util.List;\r\n" +
					"import org.apache.ibatis.annotations.Options;\r\n" +
					"import org.apache.ibatis.mapping.StatementType;\r\n" +
					"import org.apache.ibatis.annotations.Param;\r\n" +
					"import org.apache.ibatis.annotations.Select;\r\n" +
					"@org.apache.ibatis.annotations.Mapper\r\n" +
//					"#{NOTE}\r\n" +
					"public interface #{CLASS_NAME} {\r\n" +
					"#{METHODS}\r\n" +
					"}";
			src = src.replace("#{PACKAGE}", packageName);
			src = src.replace("#{CLASS_NAME}", entry.getKey());
//			src = src.replace("#{NOTE}", String.format("	//From: %s【%s】（行%d）\r\n", r.getSqlFile().getPath(), r.getName(), r.getPos()));
			src = src.replace("#{METHODS}", entry.getValue());
			writeSourceFile(packageName, entry.getKey(), src);
		}
	}

}
