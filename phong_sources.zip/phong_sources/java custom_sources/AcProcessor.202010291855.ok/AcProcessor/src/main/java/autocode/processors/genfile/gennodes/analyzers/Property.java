package autocode.processors.genfile.gennodes.analyzers;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Property {
	private String sqlName;
	private String name;
	private String type;
	private String anno;
	private String prefix;
	private String postfix;
	private String inout;
}
