package autocode.processors.genfile;

import java.io.File;
import java.lang.annotation.Annotation;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.lang.model.element.Element;

import autocode.processors.AcBaseProcessor;
import autocode.utils.RegexUtils;
import lombok.val;

public abstract class AcGenFileByResourceProcessor<T extends Annotation> extends AcBaseProcessor {
	@SuppressWarnings("unchecked")
	protected Class<T> annotationClass = (Class<T>)((ParameterizedType)this.getClass().getGenericSuperclass()).getActualTypeArguments()[0];

	/**
	 * Annotationの申し込み
	 */
	@Override
	public List<Class<? extends Annotation>> processableAnnotations() throws Exception {
		return Arrays.asList(annotationClass);
	}

	/**
	 * 一度処理を行う
	 */
	@Override
	public List<Element> filter(Set<? extends Element> elements) throws Exception {
		val first = elements.stream().findFirst();
		return first.isPresent() ? Arrays.asList(first.get()) : new ArrayList<>();
	}

	/**
	 * 処理
	 */
	public String getPath(String shortPath) {
		return RegexUtils.has(shortPath, "^(?i)inproject(?-i):", 0) ? (getProjectPath() + shortPath.replaceFirst("^(?i)inproject(?-i):", "")) : shortPath;
	}

	protected abstract String[] getSearchingPaths();

	protected boolean beforeAction() {
		return true;
	}

	protected void afterAction() {
	}

	@Override
	public void action() throws Exception {
		if (beforeAction()) {
			for (val p : getSearchingPaths()) {
				val f = new File(getPath(p));
				if (f.exists()) {
					if (f.isDirectory()) {
						processFolder(f);
					} else {
						processFile(f);
					}
				}
			}
			afterAction();
		}
	}

	protected void processFolder(File folder) {
		for (val f : folder.listFiles()) {
			if (f.isDirectory()) {
				processFolder(f);
			} else {
				processFile(f);
			}
		}
	}

	protected abstract void processFile(File file);

}
