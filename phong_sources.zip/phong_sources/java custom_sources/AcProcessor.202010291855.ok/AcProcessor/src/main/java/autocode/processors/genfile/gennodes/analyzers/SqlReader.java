package autocode.processors.genfile.gennodes.analyzers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.stream.Collectors;

import autocode.utils.ListUtils;
import autocode.utils.StringUtils;
import lombok.Getter;
import lombok.val;

/**
 * Autocode
 * SQL分析
 */
public abstract class SqlReader extends ResourceReader {

	/**
	 * オプション
	 */
	public static final String KW_OPTION_IGNORE_THIS = "IGNORE_THIS"; // #{IGNORE_THIS}
	public static final String KW_MODEL_NAME = "MODEL_NAME"; // #{MODEL_NAME:XXX}
	public static final String KW_MAPPER_NAME = "MAPPER_NAME"; // #{MAPPER_NAME:XXX}
	public static final String KW_FIELD_NAME = "_NAME"; // #{COLNAME_NAME:XXX}
	public static final String KW_FIELD_TYPE = "_TYPE"; // #{COLNAME_TYPE:Integer}
	public static final String KW_FIELD_ANNO = "_ANNO"; // #{COLNAME_ANNO:@NonNull}
	public static final String KW_FIELD_IGNORE = "_IGNORE"; // #{COLNAME_IGNORE}
	public static final String KW_FIELD_NAME_REPLACE = "NAME_REPLACE"; // #{NAME_REPLACE:^p_} #{NAME_REPLACE:^p_,X}
	public static final String KW_FIELD_CLIENT_IGNORE = "_NONCL"; // #{COLNAME_NONCL}
	public static final String KW_FIELD_CLIENT_OPTIONS = "_CL"; // #{COLNAME_CL:a,b,c}
	public static final String KW_FILE_FORMAT = "FILE_FORMAT"; // #{FILE_FORMAT:_FROM,開始}

	/**
	 * 変数
	 */
	@Getter protected ResourcePreparer resrc;
	@Getter protected Integer groupStart;
	@Getter protected Integer groupEnd;
	@Getter protected final List<SqlAnalyzedResult> results = new ArrayList<>();

	/**
	 * 初期設定
	 */
	public boolean run(ResourcePreparer _resrc) {
		resrc = _resrc;
		groupStart = 0;
		groupEnd = 0;
		results.clear();
		return process();
	}

	/**
	 * 処理
	 */
	protected abstract boolean process();

	/**
	 * Regex後の初期設定
	 */
	public void initInnerProcess(String content, Matcher m) {
		val prefix = content.substring(0, m.start());
		groupEnd = Math.max(1, prefix.split("\n", -1).length);
		groupStart = Math.max(1, prefix.substring(0, Math.max(0, prefix.lastIndexOf(';'))).split("\n", -1).length);
	}

	/**
	 * 分析結果作成
	 */
	public SqlAnalyzedResult addResult(String name, List<Property> fields) {
		val _result = new SqlAnalyzedResult();
		_result.setResrc(resrc);
		_result.setFile(resrc.getSourceFile());
		_result.setId(name);
		_result.setSqlElementName(name);
		_result.setOptions(resrc.getOptions(groupStart, groupEnd, OptionType.Option, this, _result));
		_result.setModelRename(StringUtils.nvl(ListUtils.lookup(_result.getOptions(), "key", KW_MODEL_NAME, "value1"), name));
		_result.setMapperRename(ListUtils.lookup(_result.getOptions(), "key", KW_MAPPER_NAME, "value1"));
		_result.setPos(groupEnd);
		_result.setIgnore(_result.getOptions().stream().anyMatch(x -> x.getKey().equalsIgnoreCase(SqlReader.KW_OPTION_IGNORE_THIS)));
		_result.setMapperParams(resrc.getOptions(groupStart, groupEnd, OptionType.MapperParam, this, _result));
		_result.setParamsInputs(resrc.getOptions(groupStart, groupEnd, OptionType.ParamsInput, this, _result));
		_result.setAddingProperties(resrc.getOptions(groupStart, groupEnd, OptionType.AddingProperty, this, _result).stream()
				.map(x -> new Property(null, x.getValue1(), StringUtils.nvl(x.getValue2(), "String"), StringUtils.nvl(x.getValue3(), ""), "@ClientField", null, null))
				.collect(Collectors.toList()));
		_result.setSqlProperties(fields);
		_result.setProperties(fields.stream().map(x -> {
			val sqlname = x.getSqlName();
			val fname = StringUtils.nvl(ListUtils.lookup(_result.getOptions(), "key", (sqlname + KW_FIELD_NAME).toUpperCase(), "value1"), sqlname);
			if (ListUtils.has(_result.getOptions(), "key", (sqlname + KW_FIELD_IGNORE).toUpperCase()))
				return null;
			val name_replace = StringUtils
					.nvl(ListUtils.lookup(_result.getOptions(), "key", KW_FIELD_NAME_REMOVE, "value1"), "");
			val field_type = StringUtils
					.nvl(ListUtils.lookup(_result.getOptions(), "key", (sqlname + KW_FIELD_TYPE).toUpperCase(), "value1"), "String");
			return new Property(
					sqlname,
					this instanceof SqlProcedureReader ? fname.replaceAll(name_replace, "") : fname,
					field_type, //default
					StringUtils.nvl(ListUtils.lookup(_result.getOptions(), "key", (sqlname + KW_FIELD_ANNO).toUpperCase(), "value1"), ""), //default
					StringUtils.nvl(
							ListUtils.lookup(_result.getOptions(), "key", (sqlname + KW_FIELD_CLIENT_IGNORE).toUpperCase(), "value1"),
							String.format("@ClientField%s",
									StringUtils.nvl2(
											ListUtils.lookup(_result.getOptions(), "key", (sqlname + KW_FIELD_CLIENT_OPTIONS).toUpperCase(), "value1"),
											"", "(\"%s\")")),
							""),
					null,
					x.getInout());
		}).collect(Collectors.toList()));
		_result.getProperties().removeAll(Collections.singletonList(null));
		results.add(_result);
		return _result;
	}

}
