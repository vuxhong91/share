package autocode.processors.genfile.gennodes.analyzers;

import java.io.File;

import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;

@Getter
@Setter
public abstract class ResourceAnalyzedResult {
	@NonNull private ResourcePreparer resrc;
	@NonNull private File file;
	@NonNull private String id;
	private boolean ignore = false;
}
