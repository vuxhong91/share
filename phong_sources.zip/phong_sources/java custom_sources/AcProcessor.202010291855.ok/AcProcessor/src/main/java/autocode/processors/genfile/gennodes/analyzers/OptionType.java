package autocode.processors.genfile.gennodes.analyzers;

public enum OptionType {
	Option,
	AddingProperty,
	MapperParam,
	ParamsInput
}