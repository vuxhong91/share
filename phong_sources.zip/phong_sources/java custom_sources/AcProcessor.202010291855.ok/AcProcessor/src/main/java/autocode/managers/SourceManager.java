package autocode.managers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.lang.model.element.Element;

import lombok.val;
import lombok.experimental.UtilityClass;

@UtilityClass
public class SourceManager {

	/**
	 * Caches
	 */
	private final Map<String, String> CACHE_SOURCE = new HashMap<>();
	public static Map<String, String> getCachedSource() {
		return CACHE_SOURCE;
	}

	/**
	 * Methods
	 */
	public String cacheSource(Element e, String key, String source) {
		val k = String.format("%s_%s", key, e.getSimpleName());
		CACHE_SOURCE.put(k, source);
		return k;
	}

	public String addSource(Element e, String key, String source) {
		val k = String.format("%s_%s", key, e.getSimpleName());
		val c = CACHE_SOURCE.containsKey(k) ? CACHE_SOURCE.get(k) : "";
		CACHE_SOURCE.put(k, c + source);
		return k;
	}

	public String addSource(String key, String source) {
		val c = CACHE_SOURCE.containsKey(key) ? CACHE_SOURCE.get(key) : "";
		CACHE_SOURCE.put(key, c + source);
		return key;
	}

	public List<String> loadSources(String key) {
		return CACHE_SOURCE.entrySet().stream().filter(x -> x.getKey().startsWith(key)).map(Entry::getValue).collect(Collectors.toList());
	}

	public String loadSource(String key) {
		return CACHE_SOURCE.containsKey(key) ? CACHE_SOURCE.get(key) : "";
	}

	public void clear() {
		CACHE_SOURCE.clear();
	}

	public boolean isEmpty(String key) {
		return !CACHE_SOURCE.containsKey(key);
	}

}
