package autocode.processors.genfile.gennodes.analyzers;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import autocode.utils.RegexUtils;
import autocode.utils.StringUtils;

/**
 * Autocode
 * View分析
 */
public class SqlViewReader extends SqlReader {
	@Override
	public String type() {
		return "VIEW";
	}

	/**
	 * 処理
	 */
	@Override
	public boolean process() {
		return RegexUtils.find(resrc.getFormatedContent(), "VIEW[#ss]+(%name)[#ss]*(\\((.+?)\\))*[#ss]+AS\\s+SELECT(.+?)FROM", Pattern.CASE_INSENSITIVE | Pattern.DOTALL, m -> {
			initInnerProcess(resrc.getFormatedContent(), m);
			addResult(m.group(1), getFields(m.group(3), m.group(4)));
		});
	}

	/**
	 * Field確定
	 */
	public List<Property> getFields(String aliases, String selectedCols) {
		List<Property> rs = null;
		if (StringUtils.isEmpty(aliases)) {
			rs = Arrays.stream(selectedCols.split(",")).map(x -> new Property(RegexUtils.getFirst(x.trim(), "(%name)(?:(?![\\r\\n])[^#jw])*$", 0), null, null, null, null, null, null)).collect(Collectors.toList());
		} else {
			rs = RegexUtils.getAll(aliases, "%name", 0, m -> m.group()).stream().map(x -> new Property(x, null, null, null, null, null, null)).collect(Collectors.toList());
		}
		rs.removeAll(Collections.singletonList(null));
		return rs;
	}

}
