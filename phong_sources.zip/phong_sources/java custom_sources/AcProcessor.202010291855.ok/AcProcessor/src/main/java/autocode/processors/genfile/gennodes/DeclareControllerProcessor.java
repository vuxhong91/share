package autocode.processors.genfile.gennodes;

import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.ExecutableElement;

import autocode.annotations.Mapping;
import autocode.annotations.ServiceKadoLog;
import autocode.managers.SourceManager;
import autocode.processors.AcBaseProcessor;
import autocode.utils.PathUtils;
import lombok.SneakyThrows;
import lombok.val;

/**
 * Autocode
 * コントローラーの発生処理
 */
@SupportedAnnotationTypes({
		"autocode.annotations.Mapping", // マインAnnotation
		"autocode.annotations.ServiceKadoLog" // 稼働ログの定義Annotation
})
@SupportedSourceVersion(SourceVersion.RELEASE_8)
public class DeclareControllerProcessor extends AcBaseProcessor {

	/**
	 * Mappingしか処理しない
	 * 他のAnnotationなら中止する
	 */
	@Override
	public List<Class<? extends Annotation>> processableAnnotations() throws Exception {
		return Arrays.asList(Mapping.class);
	}

	/**
	 * クラスエレメントから処理する
	 */
	@Override
	public List<Element> filter(Set<? extends Element> elements) throws Exception {
		return elements.stream().filter(x -> ElementKind.CLASS.equals(x.getKind())).collect(Collectors.toList());
	}

	/**
	 * ソース発生
	 */
	@Override
	public void action() throws Exception {
		for (val e : processingElement.getEnclosedElements().stream().filter(x ->
			ElementKind.METHOD.equals(x.getKind()) && Objects.nonNull(x.getAnnotation(Mapping.class))
		).collect(Collectors.toList())) {
			genMethod(e);
		}
		genClass();
	}

	/**
	 * コントローラー（クラス）の発生処理
	 */
	@SneakyThrows
	private void genClass() {
//		messager.printMessage(Kind.NOTE, String.format("作成: %s", processingClass.getSimpleName()));
		val packageName = PathUtils.getPackageParent(processingPackage.getQualifiedName().toString()) + ".controllers";
		val controllerName = processingClass.getSimpleName() + "Controller";
		String src =
				"package #{PACKAGE};\r\n" +
				"import javax.validation.Valid;\r\n" +
				"import org.springframework.beans.factory.annotation.Autowired;\r\n" +
				"import org.springframework.validation.BindingResult;\r\n" +
				"import org.springframework.web.bind.annotation.CrossOrigin;\r\n" +
				"import org.springframework.web.bind.annotation.PostMapping;\r\n" +
				"import org.springframework.web.bind.annotation.RequestBody;\r\n" +
				"import org.springframework.web.bind.annotation.RequestHeader;\r\n" +
				"import org.springframework.web.bind.annotation.RequestMapping;\r\n" +
				"import org.springframework.web.bind.annotation.RestController;\r\n" +
				"import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.controllers.BaseController;\r\n" +
				"import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.enums.KadoLogShoriKbEnum;\r\n" +
				"import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.libs.SessionLib;\r\n" +
				"import jp.gunma.pref.police.gpwan.g9common.s01com.f02comlib.models.Result;\r\n" +
				"@CrossOrigin\r\n" +
				"@RestController\r\n" +
				"@RequestMapping(\"#{MAIN_MAPPING}\")\r\n" +
				"public class #{CLASS_NAME} extends BaseController {\r\n" +
				"	@Autowired #{SERVICE_NAME} service;\r\n" +
				"#{METHODS}\r\n" +
				"}";
		src = src.replace("#{PACKAGE}", packageName);
		src = src.replace("#{MAIN_MAPPING}", ((Mapping)getProcessingAnnotation()).value());
		src = src.replace("#{CLASS_NAME}", controllerName);
		src = src.replace("#{SERVICE_NAME}", processingClass.asType().toString());
		src = src.replace("#{METHODS}", SourceManager.loadSource(processingClass.asType().toString()));
		writeSourceFile(packageName, controllerName, src);
	}

	/**
	 * コントローラー（メソッド）の発生処理
	 */
	private void genMethod(Element e) {
		val executableElement = (ExecutableElement) e;
//		messager.printMessage(Kind.NOTE, String.format("作成: %s<%s>", processingClass.getSimpleName(), executableElement.getSimpleName()));
		val subMap = executableElement.getAnnotation(Mapping.class);
		val kadolog = executableElement.getAnnotation(ServiceKadoLog.class);
		String src =
				"	@PostMapping(\"#{SUB_MAPPING}\")\r\n" +
				"	public Result #{METHOD_NAME}(@RequestHeader(SessionLib.SESSION_ID) String sessionId, @Valid @RequestBody #{PARAMETER} params, BindingResult bindingResult) throws Exception {\r\n" +
				"		return exec(sessionId, params, bindingResult, #{KADOLOG} this.service::#{METHOD_NAME});\r\n" +
				"	}\r\n";
		src = src.replace("#{SUB_MAPPING}", subMap.value());
		src = src.replace("#{METHOD_NAME}", executableElement.getSimpleName());
		src = src.replace("#{PARAMETER}", executableElement.getParameters().get(0).asType().toString());
		src = src.replace("#{KADOLOG}", writeKadoLog(kadolog));
		SourceManager.addSource(processingClass.asType().toString(),  src);
	}

	/**
	 * 稼働ログの追加
	 */
	private String writeKadoLog(ServiceKadoLog anno) {
		if (Objects.isNull(anno))
			return "";
		return anno.value().toKadoLog() + ",";
	}

}
