package autocode.processors.genfile.gennodes.analyzers;

import java.util.List;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper=true)
public class SqlAnalyzedResult extends ResourceAnalyzedResult {
	private String sqlElementName;
	private String modelRename;
	private String mapperRename;
	private Integer pos;
	private String procedureName;
	private String procedureType;
	private String pipelined;
	private String resultSet;
	private String baseOf;
	private List<Option> options;
	private List<Option> mapperParams;
	private List<Option> paramsInputs;
	private List<Property> addingProperties;
	private List<Property> properties;
	private List<Property> sqlProperties;
}
