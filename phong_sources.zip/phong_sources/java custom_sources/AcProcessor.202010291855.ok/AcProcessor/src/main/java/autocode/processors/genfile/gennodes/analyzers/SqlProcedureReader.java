package autocode.processors.genfile.gennodes.analyzers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import autocode.utils.RegexUtils;
import autocode.utils.StringUtils;
import lombok.val;

/**
 * Autocode
 * Procedure分析
 */
public class SqlProcedureReader extends SqlReader {
	@Override
	public String type() {
		return "PROCEDURE";
	}

	private String _packageName;

	/**
	 * 処理
	 */
	@Override
	public boolean process() {
		if (!RegexUtils.findFirst(resrc.getFormatedContent(), "PACKAGE[#ss]+(%name)", Pattern.CASE_INSENSITIVE, m -> {
			_packageName = m.group(1);
		})) {
			return false;
		}
		return RegexUtils.find(resrc.getFormatedContent(), "(FUNCTION|PROCEDURE)[#ss]+(%name)[#ss]*(\\((.+?)\\))*([#ss]+RETURN[#ss]+(%name)[#ss]+PIPELINED)*", Pattern.CASE_INSENSITIVE | Pattern.DOTALL, m -> {
			initInnerProcess(resrc.getFormatedContent(), m);
			val res = addResult(m.group(2), getFields(m.group(4)));
			res.setProcedureName(_packageName);
			res.setProcedureType(m.group(1).toUpperCase());
			res.setPipelined(StringUtils.nvl2(m.group(5), "", "PIPELINED"));
			res.setResultSet(m.group(6));
		});
	}

	/**
	 * Field確定
	 */
	public List<Property> getFields(String params) {
		if (StringUtils.isEmpty(params))
			return new ArrayList<>();
		val rs = Arrays.stream(params.split(",")).map(x -> {
			val m = RegexUtils.compile(x.trim(), "^(%name)[#ss]+((in[#ss]+out)|(out)|(in))*[#ss]*(%name)", Pattern.CASE_INSENSITIVE);
			if (!m.find())
				return null;
			return new Property(m.group(1), null, m.group(6), null, null, null,
					StringUtils.isEmpty(m.group(2)) || "in".equalsIgnoreCase(m.group(2)) ? null : m.group(2).replace(" ", "").trim().toUpperCase());
		}).collect(Collectors.toList());
		rs.removeAll(Collections.singletonList(null));
		return rs;
	}

}
