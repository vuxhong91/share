package autocode.processors.genfile.gennodes.analyzers;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import autocode.consts.CommonConsts;
import autocode.utils.RegexUtils;
import autocode.utils.StringUtils;
import lombok.Getter;
import lombok.Setter;
import lombok.SneakyThrows;
import lombok.val;
import lombok.experimental.Accessors;

/**
 * Autocode
 * 資源分析
 */
public class ResourcePreparer {

	/**
	 * オプション
	 */
	public static final String OPTION_EXTEND = "EXT"; //#{EXT:XXX}

	/**
	 * 設定
	 */
	@Accessors(fluent=true)
	@Setter private boolean javaType = false; //default: sql

	/**
	 * 内容
	 */
	@Getter private File sourceFile;
	@Getter private String fullyContent;
	@Getter private String formatedContent;

	/**
	 * オプション
	 */
	@Getter protected Map<Integer, Option> options = new HashMap<>();
	@Getter protected Map<String, List<Option>> groupOptions = new HashMap<>();

	public List<Option> getOptions(int from, int to, OptionType type, ResourceReader reader, ResourceAnalyzedResult analyzingObj) {
		val op = getOptionsFromTo(from, to, type);
		if (Objects.nonNull(analyzingObj))
			op.addAll(getOptionGroup(analyzingObj.getId(), type));
		if (Objects.nonNull(reader))
			op.addAll(getOptionGroup("TYPE_"+reader.type(), type));
		op.addAll(getOptionGroup("THIS", type));
		op.addAll(getOptionGroup("DEFAULT", type));
		return op;
	}

	public List<Option> getOptionsFromTo(int from, int to, OptionType type) {
		val op = options.entrySet().stream().filter(x -> {
			val rowNo = x.getKey();
			return from <= rowNo && rowNo <= to && type.equals(x.getValue().getType());
		}).map(x -> x.getValue()).collect(Collectors.toList());
		for (val o : options.entrySet().stream().filter(x -> {
			val rowNo = x.getKey();
			return from <= rowNo && rowNo <= to && type.equals(OptionType.Option);
		}).map(x -> x.getValue()).collect(Collectors.toList())) {
			if (OPTION_EXTEND.equals(o.getKey()) && groupOptions.containsKey(o.getValue1())) {
				op.addAll(groupOptions.get(o.getValue1()).stream().filter(x -> type.equals(x.getType())).collect(Collectors.toList()));
			}
		}
		return op;
	}

	public List<Option> getOptionGroup(String groupName, OptionType type) {
		val rs = new ArrayList<Option>();
		if (groupOptions.containsKey(groupName)) {
			rs.addAll(groupOptions.get(groupName).stream().filter(x -> type.equals(x.getType())).collect(Collectors.toList()));
			for (val o : groupOptions.get(groupName).stream().filter(x -> OptionType.Option.equals(x.getType())).collect(Collectors.toList())) {
				if (OPTION_EXTEND.equals(o.getKey()) && groupOptions.containsKey(o.getValue1())) {
					rs.addAll(groupOptions.get(o.getValue1()).stream().filter(x -> type.equals(x.getType())).collect(Collectors.toList()));
				}
			}
		}
		return rs;
	}

	/**
	 * 処理
	 */
	@SneakyThrows
	public void read(File file) {
		sourceFile = file;
		fullyContent = new String(Files.readAllBytes(file.toPath()), CommonConsts.UTF8);
		formatedContent = formatFileContent(fullyContent);
	}

	/**
	 * ファイル内容調整
	 */
	protected String formatFileContent(String content) {
		options.clear();
		groupOptions.remove("THIS");
		// gen options
		val c = content;
		RegexUtils.find(content, "#\\{[#ss]*([#jw]+)[#ss]*(:(.+?))*\\}", 0, m -> {
			val key = m.group(1).toUpperCase();
			val value = StringUtils.trim(m.group(3));
			val rowNo = c.substring(0, m.start()).split("\n", -1).length;
			options.put(rowNo, Option.addOption(key, value));
		});
		if (!javaType) { //sql -> java
			RegexUtils.find(content, "#addProperty\\{[#ss]*([#jw]+)[#ss]*(,[#ss]*([#jw]+)[#ss]*(,[#ss]*(.+?)[#ss]*)*)*\\}", Pattern.CASE_INSENSITIVE, m -> {
				val fieldName = m.group(1);
				val fieldType = m.group(3);
				val fieldAnno = StringUtils.trim(m.group(5));
				val rowNo = c.substring(0, m.start()).split("\n", -1).length;
				options.put(rowNo, Option.addProperty(fieldName, fieldType, fieldAnno));
			});
			RegexUtils.find(content, "#addMapperParams\\{[#ss]*([\\.#jw]+)[#ss]*,[#ss]*([#jw]+)[#ss]*,[#ss]*\\{[#ss]*((.|[\\r\\n])+?)[#ss]*\\}[#ss]*\\}", Pattern.CASE_INSENSITIVE, m -> {
				val type = m.group(1);
				val name = m.group(2);
				val rowNo = c.substring(0, m.start()).split("\n", -1).length;
				options.put(rowNo, Option.addMapperParam(type, name));
				for (val o : Option.addParamsInput(type, name, StringUtils.trim(m.group(3)))) {
					options.put(rowNo, o);
				}
			});
		}
		RegexUtils.find(content, "@begin[#ss]*(<(%name)>)*((.|[\\r\\n])*?)@end", Pattern.CASE_INSENSITIVE, m -> {
			val groupName = StringUtils.nvl(m.group(2), "THIS").toUpperCase();
			val innerContent = m.group(3);
			val listOptions = new ArrayList<Option>();
			RegexUtils.find(innerContent, "([#jw]+)[#ss]*(:(.+?))*[#ss]*;", 0, m2 -> {
				val key = m2.group(1).toUpperCase();
				val value = StringUtils.trim(m2.group(3));
				listOptions.add(Option.addOption(key, value));
			});
			if (!javaType) { //sql -> java
				RegexUtils.find(innerContent, "addProperty\\([#ss]*([#jw]+)[#ss]*(,[#ss]*([#jw]+)[#ss]*(,[#ss]*(.+?)[#ss]*)*)*\\)[#ss]*;", Pattern.CASE_INSENSITIVE, m2 -> {
					val fieldName = m2.group(1);
					val fieldType = m2.group(3);
					val fieldAnno = StringUtils.trim(m2.group(5));
					listOptions.add(Option.addProperty(fieldName, fieldType, fieldAnno));
				});
				RegexUtils.find(innerContent, "addMapperParams\\([#ss]*([\\.#jw]+)[#ss]*,[#ss]*([#jw]+)[#ss]*,[#ss]*\\{[#ss]*((.|[\\r\\n])+?)[#ss]*\\}[#ss]*\\)[#ss]*;", Pattern.CASE_INSENSITIVE, m2 -> {
					val type = m2.group(1);
					val name = m2.group(2);
					listOptions.add(Option.addMapperParam(type, name));
					listOptions.addAll(Option.addParamsInput(type, name, StringUtils.trim(m2.group(3))));
				});
			}
			groupOptions.put(groupName, listOptions);
		});
		// remove comments
		if (javaType)
			content = content.replaceAll("//[^\r\n]*", "");
		else
			content = content.replaceAll("--[^\r\n]*", "");
		val p = Pattern.compile("/\\*((.|[\\r\\n])*?)\\*/");
		Matcher m;
		while ((m = p.matcher(content)).find()) {
			content = content.replace(m.group(),
					StringUtils.pad("", CommonConsts.NEW_LINE, m.group(1).split("\n", -1).length, false));
		}
		// remove "
		if (!javaType)
			content = content.replace("\"", "");
//		return content.trim();
		return content;
	}
}