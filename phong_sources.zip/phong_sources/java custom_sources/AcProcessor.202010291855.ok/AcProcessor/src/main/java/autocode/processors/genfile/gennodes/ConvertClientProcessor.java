package autocode.processors.genfile.gennodes;

import java.io.File;
import java.nio.file.Files;
import java.util.List;
import java.util.Objects;

import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;

import autocode.annotations.AutoConvertClient;
import autocode.managers.SourceManager;
import autocode.processors.genfile.AcGenFileByResourceProcessor;
import autocode.processors.genfile.gennodes.analyzers.Option;
import autocode.processors.genfile.gennodes.analyzers.OptionType;
import autocode.processors.genfile.gennodes.analyzers.ResourcePreparer;
import autocode.utils.PathUtils;
import autocode.utils.RegexUtils;
import autocode.utils.StringUtils;
import lombok.SneakyThrows;
import lombok.val;

/**
 * Autocode
 * モデル発生処理
 */
@SupportedAnnotationTypes({
	"autocode.annotations.AutoConvertClient",
	"autocode.annotations.ClientField",
})
@SupportedSourceVersion(SourceVersion.RELEASE_8)
public class ConvertClientProcessor extends AcGenFileByResourceProcessor<AutoConvertClient> {
	private List<Option> options;

	/**
	 * ソース設定
	 */
	public static final String KW_OPTION_IGNORE_FILE = "IGNORE_FILE"; // #{IGNORE_FILE}
	public static final String KW_FIELD_TYPE = "_TYPE"; // #{COLUMNNAME_TYPE:XXX<KEY, VALUE>}

	/**
	 * Analyzers（分析クラス）
	 */
	protected ResourcePreparer preparer = new ResourcePreparer().javaType(true);

	/**
	 * ソース発生
	 */
	@Override
	protected String[] getSearchingPaths() {
		val anno = (AutoConvertClient)processingAnnotations.get(0);
		return anno.svModelPaths();
	}

	protected String getCreatingModelsPath() {
		val anno = (AutoConvertClient)processingAnnotations.get(0);
		return anno.clModelPath();
	}

//	protected String getCreatingApiPath() {
//		val anno = (AutoConvertClient)processingAnnotations.get(0);
//		return anno.clApiPath();
//	}

	/**
	 * マイン処理
	 */
	@SneakyThrows
	@Override
	protected boolean beforeAction() {
		//clear existing files
		val f1 = new File(getPath(getCreatingModelsPath()));
		for (val f : f1.listFiles())
			Files.deleteIfExists(f.toPath());
//		val f2 = new File(getPath(getCreatingApisPath()));
//		for (val f : f2.listFiles())
//			Files.deleteIfExists(f.toPath());
		return true;
	}

	@Override
	protected void processFile(File file) {
		if (file.getName().toLowerCase().endsWith(".java")) {
			preparer.read(file);
			options = preparer.getOptions(0, 99999, OptionType.Option, null, null);
			if (options.stream().noneMatch(x -> x.getKey().equalsIgnoreCase(KW_OPTION_IGNORE_FILE))) {
				if (!StringUtils.isEmpty(getCreatingModelsPath())) {
					RegexUtils.find(preparer.getFullyContent(), "@ClientField(\\(\"([#jw, ]*)\"\\))*\\s+((private|public)\\s+)*(%name)((\\[\\])|(<([#jw, ]+)>))*\\s+(%name);", 0, m -> {
//						val cloptions = m.group(2);
//						val accessLevel = m.group(4);
						val fieldtype = m.group(5);
						val isArray = !StringUtils.isEmpty(m.group(7));
						val isGeneric = !StringUtils.isEmpty(m.group(8));
						val genericType = m.group(9);
						val fieldName = m.group(10);
						genField(file, fieldtype, isArray, isGeneric, genericType, fieldName);
					});
					genClass(file);
				}
//				} else if (!StringUtils.isEmpty(getCreatingApiPath())) {
//
//				}
			}
		}
	}

	/**
	 * Class発生
	 */
	public void genClass(File file) {
		val fileName = PathUtils.getFileName(file);
		String src =
				"#{IMPORTS}\r\n" +
				"//#{SOURCE}\r\n" +
				"export interface #{CLASS_NAME} {\r\n" +
				"#{FIELDS}\r\n" +
				"}";
		src = src.replace("#{IMPORTS}", SourceManager.loadSource("libraries"));
		src = src.replace("#{CLASS_NAME}", fileName);
		src = src.replace("#{FIELDS}", SourceManager.loadSource(fileName));
		src = src.replace("#{SOURCE}", file.getPath());
		writeSourceFile(new File(String.format("%s\\%s.ts", getPath(getCreatingModelsPath()), fileName)), src);
	}

	/**
	 * Field発生
	 */
	public void genField(File file, String fieldType, boolean isArray, boolean isGeneric, String genericType, String fieldName) {
		val customType = options.stream().filter(x -> x.getKey().equalsIgnoreCase(fieldName + KW_FIELD_TYPE)).findFirst();
		if (customType.isPresent())
			fieldType = customType.get().getValue1();
		else
			fieldType = convertJType2TsType(file, fieldType, isArray, isGeneric, genericType);
		val source = String.format("	%s?: %s;%n", fieldName, fieldType);
		SourceManager.addSource(PathUtils.getFileName(file), source);
	}

	private String convertJType2TsType(File file, String fieldType, boolean isArray, boolean isGeneric, String genericType) {
		String type = fieldType;
		boolean generic2Array = false;
		switch (fieldType) {
			case "List":
			case "ArrayList":
				type = genericType;
				generic2Array = true;
				break;
			case "Integer":
			case "int":
			case "Long":
			case "long":
			case "Double":
			case "double":
			case "Float":
			case "float":
				type = "number";
				break;
			case "String":
				type = "string";
				break;
			default:
				break;
		}
		if (isArray || generic2Array) {
			type += "[]";
		} else if (isGeneric) {
			type += String.format("<%s>", genericType);
		}
		if (isBasicType(fieldType) == 0)
			SourceManager.addSource("libraries", String.format("import { %1$s } from './%1$s';%n", fieldType));
		if (isBasicType(genericType) == 0)
			SourceManager.addSource("libraries", String.format("import { %1$s } from './%1$s';%n", genericType));
		return type;
	}

	private int isBasicType(String fieldType) {
		if (Objects.isNull(fieldType))
			return -2;
		switch (fieldType) {
			case "List":
			case "ArrayList":
				return -1;
			case "Integer":
			case "int":
			case "Long":
			case "long":
			case "Double":
			case "double":
			case "Float":
			case "float":
			case "String":
				return 1;
			default:
				return 0;
		}
	}

}