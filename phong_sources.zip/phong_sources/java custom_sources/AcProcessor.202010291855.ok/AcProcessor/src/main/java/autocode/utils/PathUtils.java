package autocode.utils;

import java.io.File;

import lombok.val;
import lombok.experimental.UtilityClass;

@UtilityClass
public class PathUtils {

	public String convertPkg2Path(String pkg) {
		return pkg.replace('.', '\\');
	}

	public String getPackageParent(String packageFullName) {
		val lastDot = packageFullName.lastIndexOf('.');
		return packageFullName.substring(0, lastDot);
	}

	public String getFileName(String path) {
		val lastSep = path.lastIndexOf('\\');
		val lastDot = path.lastIndexOf('.');
		return path.substring(lastSep + 1, lastDot);
	}

	public String getFileName(File file) {
		return getFileName(file.getPath());
	}

}
