package autocode.utils;

import java.util.List;
import java.util.Objects;

import lombok.SneakyThrows;
import lombok.val;
import lombok.experimental.UtilityClass;

@UtilityClass
public class ListUtils {

	@SneakyThrows
	public boolean has(List<?> list, String fieldname, Object value) {
		if (list.isEmpty())
			return false;
		val genericType = list.get(0).getClass();
		val field = genericType.getDeclaredField(fieldname);
		field.setAccessible(true);
		for (val x : list) {
			if (Objects.equals(field.get(x), value))
				return true;
		}
		return false;
	}

	@SneakyThrows
	@SuppressWarnings("unchecked")
	public <R> R lookup(List<?> list, String fieldname, Object value, String getfield) {
		if (list.isEmpty())
			return null;
		val genericType = list.get(0).getClass();
		val f1 = genericType.getDeclaredField(fieldname);
		val f2 = genericType.getDeclaredField(getfield);
		f1.setAccessible(true);
		f2.setAccessible(true);
		for (val x : list) {
			if (Objects.equals(f1.get(x), value))
				return (R)f2.get(x);
		}
		return null;
	}

}
