package autocode.processors.genfile.gennodes.analyzers;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import autocode.utils.RegexUtils;
import lombok.val;

/**
 * Autocode
 * Record分析
 */
public class SqlRecordReader extends SqlReader {
	@Override
	public String type() {
		return "RECORD";
	}

	private String _packageName;

	/**
	 * 処理
	 */
	@Override
	public boolean process() {
		if (!RegexUtils.findFirst(resrc.getFormatedContent(), "PACKAGE[#ss]+(%name)", Pattern.CASE_INSENSITIVE, m -> {
			_packageName = m.group(1);
		})) {
			return false;
		}
		return RegexUtils.find(resrc.getFormatedContent(), "TYPE[#ss]+(%name)[#ss]+IS[#ss]+RECORD[#ss]*(\\((.+?)\\))[#ss]*;", Pattern.CASE_INSENSITIVE | Pattern.DOTALL, m -> {
			initInnerProcess(resrc.getFormatedContent(), m);
			val res = addResult(m.group(1), getFields(m.group(3)));
			res.setProcedureName(_packageName);
			res.setProcedureType("RECORD");
		});
	}

	/**
	 * Field確定
	 */
	public List<Property> getFields(String declaredCols) {
		val rs = Arrays.stream(declaredCols.split(","))
				.map(x -> {
					val m = RegexUtils.compile(x.trim(), "^(%name)", Pattern.CASE_INSENSITIVE);
					if (!m.find())
						return null;
					return new Property(m.group(1), null, null, null, null, null, null);
				})
				.collect(Collectors.toList());
		rs.removeAll(Collections.singletonList(null));
		return rs;
	}

}
