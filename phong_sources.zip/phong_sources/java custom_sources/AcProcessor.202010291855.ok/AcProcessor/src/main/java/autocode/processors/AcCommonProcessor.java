package autocode.processors;

import java.io.File;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.Filer;
import javax.annotation.processing.Messager;
import javax.annotation.processing.ProcessingEnvironment;
import javax.lang.model.element.Element;
import javax.tools.JavaFileObject;
import javax.tools.StandardLocation;

import autocode.consts.CommonConsts;
import autocode.managers.SourceManager;
import autocode.utils.ElementUtils;
import autocode.utils.PathUtils;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.val;

public abstract class AcCommonProcessor extends AbstractProcessor {

	/**
	 * Declares
	 */
	@Getter protected Messager messager;
	@Getter protected Filer filer;

	/**
	 * Setup
	 */
	@Override
	public synchronized void init(ProcessingEnvironment processingEnv) {
		super.init(processingEnv);
		messager = processingEnv.getMessager();
		filer = processingEnv.getFiler();
		SourceManager.clear();
	}

	/**
	 * Methods
	 */
	@SneakyThrows
	public String getBinFolderPath() {
		return filer.getResource(StandardLocation.CLASS_OUTPUT, "", "").toUri().toString().replace("file:/", "").replace('/', '\\') + "\\";
	}

	@SneakyThrows
	public String getProjectPath() {
		return new File(getBinFolderPath()).getParent() + "\\";
	}

	public String getProjectName() {
		return new File(getProjectPath()).getParentFile().getName();
	}

	public File getDeclaringFile(Element e) {
		return new File(String.format("%ssrc\\main\\java\\%s\\%s.java",
				getProjectPath(),
				PathUtils.convertPkg2Path(ElementUtils.getPackageElement(e).getQualifiedName().toString()),
				ElementUtils.getTypeElement(e).getSimpleName().toString()));
	}

	public Long getSaveTime(Element e) {
		return getDeclaringFile(e).lastModified();
	}

	@SneakyThrows
	public String getDeclaringSource(Element e) {
		return new String(Files.readAllBytes(Paths.get(getDeclaringFile(e).getAbsolutePath())));
	}

	public String getWrittingFolder(String packageName) {
		return String.format("%sgenerated\\%s\\",
				getProjectPath(),
				PathUtils.convertPkg2Path(packageName));
	}

	public File getWrittingFile(String packageName, String fileName) {
		return new File(String.format("%s%s.java", getWrittingFolder(packageName), fileName));
	}

	@SneakyThrows
	public JavaFileObject writeSourceFile(String packageName, String fileName, String src) {
		val jfo = filer.createSourceFile(String.format("%s.%s", packageName, fileName));
		try (val writer = new PrintWriter(new OutputStreamWriter(jfo.openOutputStream(), StandardCharsets.UTF_8))) {
			writer.append(src);
		}
		return jfo;
	}

	@SneakyThrows
	public void writeSourceFile(File file, String src) {
		Files.deleteIfExists(file.toPath());
		Files.write(file.toPath(), src.getBytes(CommonConsts.UTF8), StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
	}

}
