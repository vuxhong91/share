package autocode.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import lombok.val;
import lombok.experimental.UtilityClass;

@UtilityClass
public class RegexUtils {
	/**
	 * Regex Formater
	 */
	public String fm(String regex) {
		regex = regex.replaceAll("#jw", "\\\\pL０-９\\\\w");
		regex = regex.replaceAll("#jd", "０-９");
		regex = regex.replaceAll("#ss", " 　\\\\s\\\\t\\\\r\\\\n");
		regex = regex.replaceAll("%name", "(?:(?![0-9０-９])[\\\\pLa-zA-Z_])[\\\\pL０-９\\\\w]+");
		return regex;
	}

	/**
	 * Events
	 */
	public interface OnFindEvent { void onFind(Matcher m); }
	public interface OnFormatEvent { String onFormat(Matcher m); }

	/**
	 * Methods
	 */
	public Matcher compile(String content, String regex, int flags) {
		val pattern = Pattern.compile(fm(regex), flags);
		return pattern.matcher(content);
	}

	public boolean find(String content, String regex, int flags, OnFindEvent event) {
		boolean rs = false;
		val m = compile(content, regex, flags);
		while (m.find()) {
			event.onFind(m);
			rs = true;
		}
		return rs;
	}

	public boolean findFirst(String content, String regex, int flags, OnFindEvent event) {
		val m = compile(content, regex, flags);
		while (m.find()) {
			event.onFind(m);
			return true;
		}
		return false;
	}

	public String getFirst(String content, String regex, int flags) {
		val m = compile(content, regex, flags);
		while (m.find()) {
			return m.group();
		}
		return null;
	}

	public boolean has(String content, String regex, int flags) {
		return compile(content, regex, flags).find();
	}

	public boolean matches(String content, String regex, int flags) {
		return compile(content, regex, flags).matches();
	}

	public List<String> getAll(String content, String regex, int flags) {
		val rs = new ArrayList<String>();
		val m = compile(content, regex, flags);
		while (m.find()) {
			rs.add(m.group());
		}
		return rs;
	}

	public List<String> getAll(String content, String regex, int flags, OnFormatEvent event) {
		val rs = new ArrayList<String>();
		val m = compile(content, regex, flags);
		while (m.find()) {
			rs.add(event.onFormat(m));
		}
		return rs;
	}

	public String replaceAllWithOptions(String content, String regex, int flags, String replacement) {
		return compile(content, regex, flags).replaceAll(replacement);
	}

}
