package autocode.utils;

import java.util.Objects;

import lombok.val;
import lombok.experimental.UtilityClass;

@UtilityClass
public class StringUtils {

	public String capitalize(String value) {
		if (value == null || value.length() == 0)
			return value;
		val firstChar = value.substring(0, 1);
		val fix = firstChar.toLowerCase();
		return fix + value.substring(1);
	}

	public String uncapitalize(String value) {
		if (value == null || value.length() == 0)
			return value;
		val firstChar = value.substring(0, 1);
		val fix = firstChar.toUpperCase();
		return fix + value.substring(1);
	}

	public boolean isEmpty(String value) {
		return Objects.isNull(value) || "".equals(value);
	}

	public String nvl(String v1, String v2) {
		return isEmpty(v1) ? v2 : v1;
	}

	public String nvl(String v1, String v2, String v3) {
		return isEmpty(v1) ? v2 : v3;
	}

	public String nvl2(String v1, String v2, String v3) {
		return isEmpty(v1) ? v2 : String.format(v3, v1);
	}

	public String trim(String v) {
		return isEmpty(v) ? "" : v.trim();
	}

	public String pad(String input, String addingStr, int len, boolean left) {
		val sb = new StringBuffer(input);
		while (sb.length() < len) {
			if (left)
				sb.insert(0, addingStr);
			else
				sb.append(addingStr);
		}
		return sb.toString();
	}

}
