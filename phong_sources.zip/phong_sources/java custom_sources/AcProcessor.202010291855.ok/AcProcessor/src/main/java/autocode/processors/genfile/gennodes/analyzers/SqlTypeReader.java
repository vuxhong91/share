package autocode.processors.genfile.gennodes.analyzers;

import java.util.ArrayList;
import java.util.regex.Pattern;

import autocode.utils.RegexUtils;
import lombok.val;

/**
 * Autocode
 * TypeTable分析
 */
public class SqlTypeReader extends SqlReader {
	@Override
	public String type() {
		return "TYPE";
	}

	private String _packageName;

	/**
	 * 処理
	 */
	@Override
	public boolean process() {
		if (!RegexUtils.findFirst(resrc.getFormatedContent(), "PACKAGE[#ss]+(%name)", Pattern.CASE_INSENSITIVE, m -> {
			_packageName = m.group(1);
		})) {
			return false;
		}
		return RegexUtils.find(resrc.getFormatedContent(), "TYPE[#ss]+(%name)[#ss]+IS[#ss]+TABLE[#ss]+OF[#ss]+(%name)[#ss]*;", Pattern.CASE_INSENSITIVE | Pattern.DOTALL, m -> {
			initInnerProcess(resrc.getFormatedContent(), m);
			val res = addResult(m.group(1), new ArrayList<>());
			res.setProcedureName(_packageName);
			res.setProcedureType("TYPE_TABLE");
			res.setBaseOf(m.group(2));
		});
	}

}
