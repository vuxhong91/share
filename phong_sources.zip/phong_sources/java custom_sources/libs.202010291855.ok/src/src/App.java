@SpringBootApplication
public class App implements CommandLineRunner {

	@Autowired
	HyoshoDaichoService service;

	@Autowired
	HyoshoDaichoPrint_ERP printERP;

	@Autowired
	HyoshoDaichoPrint_JSON printJSON;

	@Autowired
	HyoshoDaichoPrint_JavaCode printJCode;

	@Autowired
	HyoshoDaichoPrint_JavaConfigs printJConfigs;

	@Autowired
	HyoshoDaichoPrint printNormal;

	@Autowired
	ApplicationContext context;

	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}

	public void run(String... args) throws Exception {
//		testPrinter();
//		testSysUtils();
//		testBindModel();
//		testStackTrace();
//		testAspect();
//		testFieldConditions();
//		testBindingObject();
//		testCglibSimple();
//		System.exit(0);
	}

	@SuppressWarnings("unchecked")
	private void testPrinter() throws Exception {
		val log = new LogInfo();
		val app = new AppInfo();
		val session = new SessionInfo();
		val context = new Context();
		context.setLogInfo(log);
		context.setAppInfo(app);
		context.setSessionInfo(session);

		val shutokuParams = new HyoshoDaichoYoShutokuParams();
		shutokuParams.setContext(context);
		shutokuParams.set表彰YMD開始("20180101");
		shutokuParams.set表彰YMD終了("20190501");
		shutokuParams.set上申所属CD開始("0000");
		shutokuParams.set上申所属CD終了("9999");
		shutokuParams.set所属CD開始("0000");
		shutokuParams.set所属CD終了("9999");
		shutokuParams.set課係CD開始("0000");
		shutokuParams.set課係CD終了("9999");
		shutokuParams.set表彰種別CD開始("00");
		shutokuParams.set表彰種別CD終了("99");
		val shutokuResult = this.service.getHyoshoDaichoYoJoho(shutokuParams);

		val printParams = new HyoshoDaichoYoInsatsuParams();
		printParams.setContext(context);
		printParams.set表彰台帳用リスト(shutokuResult.get表彰台帳用リスト());

		Date start;
		Date end;

		start = new Date();
		this.printERP.print(printParams, null);
		end = new Date();
		System.out.println("ERP1");
		System.out.println(end.toString());
		System.out.println(end.getTime() - start.getTime());
		System.out.println();

		start = new Date();
		this.printERP.print(printParams, null);
		end = new Date();
		System.out.println("ERP2");
		System.out.println(end.toString());
		System.out.println(end.getTime() - start.getTime());
		System.out.println();

		start = new Date();
		this.printJSON.print(printParams, null);
		end = new Date();
		System.out.println("JSON1");
		System.out.println(end.toString());
		System.out.println(end.getTime() - start.getTime());
		System.out.println();

		start = new Date();
		this.printJSON.print(printParams, null);
		end = new Date();
		System.out.println("JSON2");
		System.out.println(end.toString());
		System.out.println(end.getTime() - start.getTime());
		System.out.println();

		start = new Date();
		this.printJCode.printJava(printParams, null, Pair.of("G1HYOSHO_R0010L", "表彰台帳"));
		end = new Date();
		System.out.println("JCode1");
		System.out.println(end.toString());
		System.out.println(end.getTime() - start.getTime());
		System.out.println();

		start = new Date();
		this.printJCode.printJava(printParams, null, Pair.of("G1HYOSHO_R0010L", "表彰台帳"));
		end = new Date();
		System.out.println("JCode2");
		System.out.println(end.toString());
		System.out.println(end.getTime() - start.getTime());
		System.out.println();

		start = new Date();
		this.printJConfigs.print(printParams, null, this.printJConfigs.getTestSettings());
		end = new Date();
		System.out.println("JConfigs1");
		System.out.println(end.toString());
		System.out.println(end.getTime() - start.getTime());
		System.out.println();

		start = new Date();
		this.printJConfigs.print(printParams, null, this.printJConfigs.getTestSettings());
		end = new Date();
		System.out.println("JConfigs2");
		System.out.println(end.toString());
		System.out.println(end.getTime() - start.getTime());
		System.out.println();

		start = new Date();
		this.printNormal.createHyoshoDaichoHyo(printParams);
		end = new Date();
		System.out.println("NonPrinter1");
		System.out.println(end.toString());
		System.out.println(end.getTime() - start.getTime());
		System.out.println();

		start = new Date();
		this.printNormal.createHyoshoDaichoHyo(printParams);
		end = new Date();
		System.out.println("NonPrinter2");
		System.out.println(end.toString());
		System.out.println(end.getTime() - start.getTime());
		System.out.println();
	}

	public class TestSysHooksClass {
		public TestSysHooksClass a;
		public String b;
		public int c;

		public TestSysHooksClass getA(String newB) {
			this.a.b = newB;
			return this.a;
		}

		public int test(TestSysHooksClass tmp) {
			return this.c + tmp.c;
		}
	}

	private void testSysUtils() throws Exception {
		Date start;
		Date end;

		val testObj = new TestSysHooksClass();
		testObj.a = new TestSysHooksClass();
		testObj.b = "123";
		testObj.c = -123;

		start = new Date();
		System.out.println();
		System.out.println(
				"\"1\" + -123 + \"123\" = " + SysUtils.getScriptValue("#{#{getA(\"1\")}.b} + #{c} + #{b}", testObj));
		System.out.println();
		end = new Date();
		System.out.println("-----↓");
		System.out.println(end.toString());
		System.out.println(end.getTime() - start.getTime());

		val testObj2 = new TestSysHooksClass();
		testObj2.a = new TestSysHooksClass();
		testObj2.b = "567";
		testObj2.c = -567;

		start = new Date();
		val map = new HashMap<String, Object>();
		map.put("1", testObj);
		map.put("2", testObj2);
		System.out.println();
		System.out.println("-123 + -567 = " + SysUtils.getScriptValue("#{1.test(#{2})}", map));
		System.out.println();
		end = new Date();
		System.out.println("-----↓");
		System.out.println(end.toString());
		System.out.println(end.getTime() - start.getTime());

		start = new Date();
		System.out.println();
		System.out.println("StringUtils.join(\"a\", \"1\") = " + SysUtils.getScriptValue("#{org.apache.commons.lang3.StringUtils.join(_0, _1)}", "a", ","));
		System.out.println();
		end = new Date();
		System.out.println("-----↓");
		System.out.println(end.toString());
		System.out.println(end.getTime() - start.getTime());
	}

	public class TestBindModelClassA {
		@Binding(bindTo="common", ofClass=TestBindModelClassB.class)
		public String common = "commonA";

		@Binding(bindTo="b1", ofKey="b")
		@Binding(bindTo="c1", ofKey="c")
		public String a1 = "a1";

		@Binding(bindTo="b2", ofKey="b")
		@Binding(bindTo="c2", ofKey="c")
		public String a2 = "a2";

		public String k = "kA";
	}

	@BindingOptions(autoBindingSameName=true)
	public class TestBindModelClassB {
		public String common = "commonB";

		public String b1 = "b1";

		public String b2 = "b2";

		public String k = "kB";
	}

	@BindingOptions(autoBindingSameName=false)
	public class TestBindModelClassC {
		public String common = "commonC";

		public String c1 = "c1";

		public String c2 = "c2";

		public String k = "kC";
	}

	@BindingOptions(autoBindingSameName=true)
	public class TestBindModelClassD {
		public String common = "commonD";

		public String d1 = "d1";

		public String d2 = "d2";

		public String k = "kD";
	}

	private void testBindModel() throws Exception {
		val a = new TestBindModelClassA();
		val b = new TestBindModelClassB();
		val c = new TestBindModelClassC();
		val d = new TestBindModelClassD();

		SysUtils.bindModel(a, b);

		System.out.println();
		System.out.println("a -> b:");
		System.out.println(b.common);
		System.out.println(b.b1);
		System.out.println(b.b2);
		System.out.println(b.k);
		System.out.println();

		SysUtils.bindModel(a, b, "b");

		System.out.println();
		System.out.println("a -> b(key = b):");
		System.out.println(b.common);
		System.out.println(b.b1);
		System.out.println(b.b2);
		System.out.println(b.k);
		System.out.println();

		SysUtils.bindModel(a, c, "c");

		System.out.println();
		System.out.println("a -> c(key = c):");
		System.out.println(c.common);
		System.out.println(c.c1);
		System.out.println(c.c2);
		System.out.println(c.k);
		System.out.println();

		SysUtils.bindModel(b, d);

		System.out.println();
		System.out.println("b -> d:");
		System.out.println(d.common);
		System.out.println(d.d1);
		System.out.println(d.d2);
		System.out.println(d.k);
		System.out.println();
	}

	private void testStackTrace() {
		System.out.println();
		val tracer = Thread.currentThread().getStackTrace();
		for (val item : tracer) {
			System.out.println(String.format("%s - %s - %s - %s", item.getClassName(), item.getFileName(), item.getLineNumber(), item.getMethodName()));
		}
		System.out.println();
	}

	private void testAspect() {
		val model = context.getBean(AspectModel.class); // 普通なBeanの定義
		model.setA("a");
		model.getA();
		model.testAnno();
		model.testAnno2();
		try {
			model.error(); // error
		} catch (Exception ex) {} // エラーにならないため、キャッチする
	}

	@Data
	public class TestFieldConditions {
		@FieldConditions("#{a} != null && #{a} > 0")
		private Integer a;
		@FieldConditions(value="#{b} > #{a}", msg="Error: a <= b")
		@FieldConditions(value="#{b} < 100", msg="jp.gunma.pref.police.gpwan.g1keimux.s01ssg.f14hyosho.TestFieldConditionsException")
		private Integer b;
	}

	private void testFieldConditions() {
		val model1 = new TestFieldConditions();
		model1.setA(1);
		System.out.println(SysUtils.checkFieldConditions(model1));
		testFieldConditions_PrintError();
		val model2 = new TestFieldConditions();
		model2.setA(0);
		System.out.println(SysUtils.checkFieldConditions(model2));
		testFieldConditions_PrintError();
		val model3 = new TestFieldConditions();
		model3.setA(5);
		model3.setB(4);
		System.out.println(SysUtils.checkFieldConditions(model3));
		testFieldConditions_PrintError();
		val model4 = new TestFieldConditions();
		model4.setA(5);
		model4.setB(101);
		System.out.println(SysUtils.checkFieldConditions(model4));
		testFieldConditions_PrintError();
	}

	private void testFieldConditions_PrintError() {
		for (val e : SysUtils.getLastCheckedResult()) {
			System.out.println(e);
		}
	}

	private void testBindingObject() {
		val obj1 = context.getBean(TestBindingObject.class);
		val obj2 = context.getBean(TestBindingObject.class);
		obj1.createBinding("#{a=b, mode=TWO_WAY}", obj2);
		obj1.changeA();
		System.out.println("Test: " + obj2.getB());
		obj2.setB("new B");
		System.out.println("Test: " + obj1.getA());
	}

	private void testCglibSimple() {
		val enhancer = new Enhancer();
		enhancer.setSuperclass(TestBindingObject.class);
		enhancer.setCallback((MethodInterceptor)(obj, method, args, proxy) -> {
			if (!method.getDeclaringClass().equals(Object.class) && method.getReturnType().equals(String.class))
				return "xxx";
			return proxy.invokeSuper(obj, args);
		});
		val proxy = (TestBindingObject)enhancer.create();
		System.out.println(proxy.getA());
	}
}
