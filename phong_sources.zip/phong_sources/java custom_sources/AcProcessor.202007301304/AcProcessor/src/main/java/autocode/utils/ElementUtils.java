package autocode.utils;

import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.PackageElement;
import javax.lang.model.element.TypeElement;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ElementUtils {

	public PackageElement getPackageElement(Element e) {
		while (!ElementKind.PACKAGE.equals(e.getKind())) {
			e = e.getEnclosingElement();
		}
		return (PackageElement)e;
	}

	public TypeElement getTypeElement(Element e) {
		while (!ElementKind.CLASS.equals(e.getKind())) {
			e = e.getEnclosingElement();
		}
		return (TypeElement)e;
	}

}
