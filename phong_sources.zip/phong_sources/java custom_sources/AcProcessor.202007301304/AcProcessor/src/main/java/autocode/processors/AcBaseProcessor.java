package autocode.processors;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.processing.RoundEnvironment;
import javax.lang.model.element.Element;
import javax.lang.model.element.PackageElement;
import javax.lang.model.element.TypeElement;
import javax.tools.Diagnostic.Kind;

import autocode.utils.ClassUtils;
import autocode.utils.ElementUtils;
import lombok.Getter;
import lombok.val;

public abstract class AcBaseProcessor extends AcCommonProcessor {

	/**
	 * Caches
	 */
	protected final List<String> processedPackages = new ArrayList<>();

	/**
	 * Declares
	 */
	@Getter protected RoundEnvironment roundEnvironment;
	@Getter protected Class<? extends Annotation> processingAnnotationType;
	@Getter protected List<Annotation> processingAnnotations;
	@Getter protected Element processingElement;
	@Getter protected TypeElement processingClass;
	@Getter protected PackageElement processingPackage;

	public Annotation getProcessingAnnotation() {
		return processingAnnotations.get(0);
	}

	/**
	 * Processor's Flow
	 */
	@SuppressWarnings("unchecked")
	public List<Class<? extends Annotation>> processableAnnotations() throws Exception {
		return getSupportedAnnotationTypes().stream().map(x -> (Class<? extends Annotation>)ClassUtils.loadClass(x)).collect(Collectors.toList());
	}

	public List<Element> filter(Set<? extends Element> elements) throws Exception {
		return elements.stream().collect(Collectors.toList());
	}

	public boolean condition() throws Exception {
//		val now = new Date().getTime();
//		val sessionFile = new File(".AcProcessor\\" + getProjectName());
//		if (!sessionFile.exists() || sessionFile.lastModified() + ProcessorConsts.SESSION_FILE_TIMEOUT > now) {
//			Files.createDirectories(sessionFile.getParentFile().toPath());
//			Files.write(sessionFile.toPath(), "".getBytes(), StandardOpenOption.CREATE);
//			return true;
//		}
//		val workingFileSaveTime = getSaveTime(processingElement);
//		if (workingFileSaveTime + ProcessorConsts.INSTANT_PROCESS_TIMEOUT > now) {
//			return true;
//		}
//		return false;
		return true;
	}

	public abstract void action() throws Exception;

	public void run() throws Exception {
		for (val annoType : processableAnnotations()) {
			processingAnnotationType = annoType;
			val elements = filter(roundEnvironment.getElementsAnnotatedWith(processingAnnotationType));
			for (val e : elements) {
				processingElement = e;
				processingAnnotations = Arrays.asList(e.getAnnotationsByType(processingAnnotationType));
				processingClass = ElementUtils.getTypeElement(e);
				processingPackage = ElementUtils.getPackageElement(e);
				if (condition()) {
					action();
				}
			}
		}
	}

	@Override
	public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
		try {
			roundEnvironment = roundEnv;
			run();
		} catch (Exception e1) {
			processingEnv.getMessager().printMessage(Kind.ERROR, e1.getMessage());
		}
		return true;
	}

}
