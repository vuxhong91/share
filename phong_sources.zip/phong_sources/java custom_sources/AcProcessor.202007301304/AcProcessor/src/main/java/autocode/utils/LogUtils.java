package autocode.utils;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Date;

import autocode.consts.CommonConsts;
import lombok.SneakyThrows;
import lombok.val;
import lombok.experimental.UtilityClass;

@UtilityClass
public class LogUtils {

	@SneakyThrows
	public void log(String logPath, String content) {
		if (StringUtils.isEmpty(content)) {
			return;
		}
		val path = Paths.get(logPath);
		val newContent = String.format("%s[%s]: %s", CommonConsts.NEW_LINE, new Date().toString(), content).getBytes();
		Files.write(path, newContent, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
	}

}
