package autocode;

public class AcApplication {

	public static void main(String[] args) {
	}

}
