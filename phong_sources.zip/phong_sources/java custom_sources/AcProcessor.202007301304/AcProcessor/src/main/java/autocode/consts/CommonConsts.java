package autocode.consts;

import lombok.experimental.UtilityClass;

@UtilityClass
public class CommonConsts {
	public static final String NEW_LINE = "\r\n";
}
