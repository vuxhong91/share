package autocode.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import autocode.enums.LogEnum;

/**
 * Autocode
 * コントローラーに稼働ログが追加されます。
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ServiceKadoLog {
	LogEnum value();
}