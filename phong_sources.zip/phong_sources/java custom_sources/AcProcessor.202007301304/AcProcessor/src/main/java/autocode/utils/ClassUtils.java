package autocode.utils;

import autocode.AcApplication;
import lombok.SneakyThrows;
import lombok.experimental.UtilityClass;

@UtilityClass
public class ClassUtils {

	@SneakyThrows
	public Class<?> loadClass(String className) {
		return AcApplication.class.getClassLoader().loadClass(className);
	}

}
