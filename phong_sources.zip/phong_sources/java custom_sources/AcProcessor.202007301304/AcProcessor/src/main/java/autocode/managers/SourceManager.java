package autocode.managers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.lang.model.element.Element;

import lombok.val;
import lombok.experimental.UtilityClass;

@UtilityClass
public class SourceManager {

	/**
	 * Caches
	 */
	private final Map<String, String> CACHE_SOURCE = new HashMap<>();

	/**
	 * Methods
	 */
	public void cacheSource(Element e, String key, String source) {
		CACHE_SOURCE.put(String.format("%s_%s", key, e.getSimpleName()), source);
	}

	public void addSource(String key, String source) {
		val c = CACHE_SOURCE.containsKey(key) ? CACHE_SOURCE.get(key) : "";
		CACHE_SOURCE.put(key, c + source);
	}

	public List<String> loadSources(String key) {
		return CACHE_SOURCE.entrySet().stream().filter(x -> x.getKey().startsWith(key)).map(Entry::getValue).collect(Collectors.toList());
	}

	public String loadSource(String key) {
		return CACHE_SOURCE.get(key);
	}

	public void clear() {
		CACHE_SOURCE.clear();
	}

}
