package autocode.plugins;

import java.util.Arrays;
import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;

import com.sun.source.tree.MethodTree;
import com.sun.source.tree.VariableTree;
import com.sun.source.util.JavacTask;
import com.sun.source.util.Plugin;
import com.sun.source.util.TaskEvent;
import com.sun.source.util.TaskListener;
import com.sun.source.util.TreeScanner;
import com.sun.tools.javac.api.BasicJavacTask;
import com.sun.tools.javac.code.TypeTag;
import com.sun.tools.javac.tree.JCTree;
import com.sun.tools.javac.tree.TreeMaker;
import com.sun.tools.javac.util.Context;
import com.sun.tools.javac.util.List;
import com.sun.tools.javac.util.Log;
import com.sun.tools.javac.util.Names;

import autocode.annotations.Positive;
import lombok.val;

public class TestPlugin implements Plugin {

	private static final Set<String> TARGET_TYPES = Arrays.asList(
			byte.class,
			short.class,
			char.class,
			int.class,
			long.class,
			float.class,
			double.class).stream().map(Class::getName).collect(Collectors.toSet());

	@Override
	public String getName() {
		return "MyPlugin";
	}

	@Override
	public void init(JavacTask task, String... args) {
		val context = ((BasicJavacTask) task).getContext();
		Log.instance(context).printRawLines(Log.WriterKind.NOTICE, "Hello from " + getName());
		TreeMaker.instance(context);
		task.addTaskListener(new TaskListener() {

			@Override
			public void started(TaskEvent e) {
			}

			@Override
			public void finished(TaskEvent e) {
				if (TaskEvent.Kind.PARSE != e.getKind()) {
					return;
				}
				e.getCompilationUnit().accept(new TreeScanner<Void, Void>() {
					@Override
					public Void visitMethod(MethodTree node, Void aVoid) {
						val paramsToInstrument = node.getParameters().stream()
								.filter(TestPlugin.this::shouldInstrument)
								.collect(Collectors.toList());
						if (!paramsToInstrument.isEmpty()) {
							Collections.reverse(paramsToInstrument);
							paramsToInstrument.forEach(x -> addCheck(node, x, context));
						}
						return super.visitMethod(node, aVoid);
					}
				}, null);
			}
		});
	}

	private boolean shouldInstrument(VariableTree param) {
		return TARGET_TYPES.contains(param.getType().toString()) &&
				param.getModifiers().getAnnotations().stream()
						.anyMatch(x -> Positive.class.getSimpleName().equals(x.getAnnotationType().toString()));
	}

	private void addCheck(MethodTree node, VariableTree param, Context context) {
		val check = createCheck(param, context);
		val body = (JCTree.JCBlock) node.getBody();
		body.stats = body.stats.prepend(check);
	}

	private static JCTree.JCIf createCheck(VariableTree param, Context context) {
		val factory = TreeMaker.instance(context);
		val symbolsTable = Names.instance(context);
		return factory.at(((JCTree) param).pos).If(factory.Parens(createIfCondition(factory, symbolsTable, param)),
				createIfBlock(factory, symbolsTable, param), null);
	}

	private static JCTree.JCBinary createIfCondition(TreeMaker factory, Names symbolsTable, VariableTree param) {
		val id = symbolsTable.fromString(param.getName().toString());
		return factory.Binary(JCTree.Tag.LE, factory.Ident(id), factory.Literal(TypeTag.INT, 0));
	}

	private static JCTree.JCBlock createIfBlock(TreeMaker factory, Names symbolsTable, VariableTree param) {
		val name = param.getName().toString();
		val id = symbolsTable.fromString(name);

		val errorMessagePrefix = String.format(
				"Argument '%s' of type %s is marked by @%s but got '",
				name, param.getType(), Positive.class.getSimpleName());
		val errorMessagePostfix = "' for it.";

		return factory.Block(0, List.of(
				factory.Throw(
						factory.NewClass(null, List.nil(),
								factory.Ident(symbolsTable.fromString(IllegalArgumentException.class.getSimpleName())),
								List.of(factory.Binary(JCTree.Tag.PLUS,
										factory.Binary(JCTree.Tag.PLUS,
												factory.Literal(TypeTag.CLASS, errorMessagePrefix), factory.Ident(id)),
										factory.Literal(TypeTag.CLASS, errorMessagePostfix))),
								null))));
	}

}
