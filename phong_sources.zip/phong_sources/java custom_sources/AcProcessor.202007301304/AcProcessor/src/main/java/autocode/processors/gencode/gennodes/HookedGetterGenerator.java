package autocode.processors.gencode.gennodes;

import java.util.Objects;

import autocode.processors.gencode.AcGenCodeCommonProcessor;
import autocode.processors.gencode.AcGenCodeInterface;
import lombok.Getter;

public class HookedGetterGenerator implements AcGenCodeInterface {

	@Override
	public String condition(AcGenCodeCommonProcessor common) {
		if (Objects.nonNull(common.getProcessingElement().getAnnotation(Getter.class))) {
			return "Not work with lombok.Getter!";
		}
		return null;
	}

	@Override
	public String genCode(AcGenCodeCommonProcessor common) {
		try {
//			val runtime = Runtime.getRuntime();
//			runtime.exec(String.format("C:\\gp\\jdk1.8.0_121\\bin\\javac.exe -cp %s -Xplugin:MyPlugin %s",
//					common.getBinFolderPath(),
//					common.getDeclaringFile(common.getProcessingElement()).getAbsolutePath()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
