package autocode.processors;

import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.Filer;
import javax.annotation.processing.Messager;
import javax.annotation.processing.ProcessingEnvironment;
import javax.lang.model.element.Element;
import javax.tools.JavaFileObject;
import javax.tools.StandardLocation;

import autocode.managers.SourceManager;
import autocode.utils.ElementUtils;
import autocode.utils.PathUtils;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.val;

public abstract class AcCommonProcessor extends AbstractProcessor {

	/**
	 * Declares
	 */
	@Getter protected Messager messager;
	@Getter protected Filer filer;

	/**
	 * Setup
	 */
	@Override
	public synchronized void init(ProcessingEnvironment processingEnv) {
		super.init(processingEnv);
		messager = processingEnv.getMessager();
		filer = processingEnv.getFiler();
		SourceManager.clear();
	}

	/**
	 * Methods
	 */
	@SneakyThrows
	public String getBinFolderPath() {
		return filer.getResource(StandardLocation.CLASS_OUTPUT, "", "").toUri().toString().replace("file:/", "").replace('/', '\\') + "\\";
	}

	@SneakyThrows
	public String getProjectPath() {
		return new File(getBinFolderPath()).getParent();
	}

	public String getProjectName() {
		return new File(getProjectPath()).getParentFile().getName();
	}

	public File getDeclaringFile(Element e) {
		return new File(String.format("%ssrc\\main\\java\\%s\\%s.java",
				getProjectPath(),
				PathUtils.convertPkg2Path(ElementUtils.getPackageElement(e).getQualifiedName().toString()),
				ElementUtils.getTypeElement(e).getSimpleName().toString()));
	}

	public Long getSaveTime(Element e) {
		return getDeclaringFile(e).lastModified();
	}

	@SneakyThrows
	public String getDeclaringSource(Element e) {
		return new String(Files.readAllBytes(Paths.get(getDeclaringFile(e).getAbsolutePath())));
	}

	@SneakyThrows
	public JavaFileObject writeSourceFile(String packageName, String fileName, String src) {
		val jfo = filer.createSourceFile(String.format("%s.%s", packageName, fileName));
		try (val writer = new PrintWriter(jfo.openWriter())) {
			writer.append(src);
		}
		return jfo;
	}

}
