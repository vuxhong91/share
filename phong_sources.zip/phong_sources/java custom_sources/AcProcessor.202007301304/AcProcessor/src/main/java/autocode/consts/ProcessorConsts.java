package autocode.consts;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ProcessorConsts {
	public static final Long INSTANT_PROCESS_TIMEOUT = 60000L;
	public static final Long SESSION_FILE_TIMEOUT = 10800000L;
}
