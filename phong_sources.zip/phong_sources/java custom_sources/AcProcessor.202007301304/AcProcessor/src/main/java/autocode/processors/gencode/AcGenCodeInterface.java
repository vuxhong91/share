package autocode.processors.gencode;

public interface AcGenCodeInterface {
	String condition(AcGenCodeCommonProcessor common);
	String genCode(AcGenCodeCommonProcessor common);
}
