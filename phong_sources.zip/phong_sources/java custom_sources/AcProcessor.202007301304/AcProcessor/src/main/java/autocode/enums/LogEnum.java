package autocode.enums;

import lombok.Getter;

/**
 * GPWANの稼働ログです。
 * g9commonに直接開発しないし、Processorが外ソースも使えません。
 * それで、Converterを利用します。
 */
public enum LogEnum {
    NONE("NA"),
    START("ST"),
    END("ED"),
    ADD("AD"),
    UPDATE("UP"),
    DELETE_P("DP"),
    DELETE_L("DL"),
    INQUIRY("IQ"),
    PRINT("PR"),
    EXPORT_FILE("EP"),
    IMPORT_FILE("IP"),
    BATCH("BT"),
    ETC("ET");

	@Getter
	private final String value;

	private LogEnum(String value) {
		this.value = value;
	}

	public String toKadoLog() {
		switch (this) {
		case NONE:
			return "KadoLogShoriKbEnum.NONE";
		case START:
			return "KadoLogShoriKbEnum.START";
		case END:
			return "KadoLogShoriKbEnum.END";
		case ADD:
			return "KadoLogShoriKbEnum.ADD";
		case UPDATE:
			return "KadoLogShoriKbEnum.UPDATE";
		case DELETE_P:
			return "KadoLogShoriKbEnum.DELETE_P";
		case DELETE_L:
			return "KadoLogShoriKbEnum.DELETE_L";
		case INQUIRY:
			return "KadoLogShoriKbEnum.INQUIRY";
		case PRINT:
			return "KadoLogShoriKbEnum.PRINT";
		case EXPORT_FILE:
			return "KadoLogShoriKbEnum.EXPORT_FILE";
		case IMPORT_FILE:
			return "KadoLogShoriKbEnum.IMPORT_FILE";
		case BATCH:
			return "KadoLogShoriKbEnum.BATCH";
		case ETC:
			return "KadoLogShoriKbEnum.ETC";
		default:
			return null;
		}
	}
}