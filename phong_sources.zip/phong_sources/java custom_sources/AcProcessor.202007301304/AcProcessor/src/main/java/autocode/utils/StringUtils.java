package autocode.utils;

import java.util.Objects;

import lombok.val;
import lombok.experimental.UtilityClass;

@UtilityClass
public class StringUtils {

	public String capitalize(String value) {
		if (value == null || value.length() == 0)
			return value;
		val firstChar = value.substring(0, 1);
		val fix = firstChar.toLowerCase();
		return fix + value.substring(1);
	}

	public String uncapitalize(String value) {
		if (value == null || value.length() == 0)
			return value;
		val firstChar = value.substring(0, 1);
		val fix = firstChar.toUpperCase();
		return fix + value.substring(1);
	}

	public boolean isEmpty(String value) {
		return Objects.isNull(value) || "".equals(value);
	}

}
