package autocode.plugins;

import autocode.annotations.Positive;

public class TestPlugin2 {

	public void test(@Positive int a) {

	}

	public void test2() {

	}

}
