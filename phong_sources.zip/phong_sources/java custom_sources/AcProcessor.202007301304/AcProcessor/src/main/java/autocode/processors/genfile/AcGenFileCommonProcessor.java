package autocode.processors.genfile;

import autocode.processors.AcBaseProcessor;

public abstract class AcGenFileCommonProcessor extends AcBaseProcessor {
}
