package autocode.processors.gencode;

import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.annotation.processing.ProcessingEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.tools.Diagnostic.Kind;

import autocode.annotations.HookedGetter;
import autocode.annotations.HookedSetter;
import autocode.processors.AcBaseProcessor;
import autocode.processors.gencode.gennodes.HookedGetterGenerator;
import lombok.Getter;
import lombok.val;

@SupportedAnnotationTypes({
		"autocode.annotations.HookedGetter",
		"autocode.annotations.HookedSetter"
})
@SupportedSourceVersion(SourceVersion.RELEASE_8)
public final class AcGenCodeCommonProcessor extends AcBaseProcessor {
	@Getter protected static final Map<Class<? extends Annotation>, AcGenCodeInterface> GENERATORS = new HashMap<>();

	@Override
	public synchronized void init(ProcessingEnvironment processingEnv) {
		super.init(processingEnv);
		GENERATORS.put(HookedGetter.class, new HookedGetterGenerator());
		GENERATORS.put(HookedSetter.class, null);
	}

	@Override
	public void run() throws Exception {
		super.run();
	}

	@Getter protected AcGenCodeInterface processingGenerator;

	@Override
	public boolean condition() throws Exception {
		processingGenerator = GENERATORS.get(processingAnnotationType);
		val error = processingGenerator.condition(this);
		if (Objects.nonNull(error)) {
			messager.printMessage(Kind.WARNING, error);
			return false;
		}
		return Objects.nonNull(processingGenerator);
	}

	@Override
	public void action() throws Exception {
		val source = processingGenerator.genCode(this);
		if (Objects.nonNull(source)) {
//			SourceManager.addSource(processingPackage, processingGenerator.genCode(this));
		}
	}
}
